# Verified facts (SA-MP Nezuko 1.0.3 TESTING APK)
- `libGTASA.so` exports `_Z20OS_ScreenSwapBuffersv` (0x268ee5, 104 B). It swaps via JNI (`NVThreadGetCurrentJNIEnv` + `JNIEnv::CallBooleanMethod`); libGTASA has no `eglSwapBuffers` import. So the final EGL swap happens on the Java side.
- `_Z24RQ_Command_rqSwapBuffersRPc` is 4 bytes: not hookable.
- `_Z16emu_glReadPixelsiiiijjPv` exists; libGTASA imports `glReadPixels`, `glBindFramebuffer`, `glGetIntegerv` from libGLESV2 (GLES2 only: no PBO).
- libAML exports `AML::GetSym/HookPLT/HookBL/GetAndroidDataPath...` matching `mod/iaml.h`. AML mods folder pattern `%s/mods/`.
- libNezukoSA-MP.so contains `ImGuiRenderer`/`ImGuiWrapper`; libmonetloader provides the Lua `script` usertype (strings: name, path, version, description, get, pause, resume, this) but no `list`/`find`/`dead` string was found.
# Inferred / unverified
- Whether overlays are drawn before the swap hook runs (hence both hook modes).
- That `script.get(name)` returns an object whose `pause()` stops its overlay. The menu probes this at runtime.
- That `ffi.load("libHEXED_Capture.so")` resolves an already loaded AML mod (same pattern as other HEXED scripts); a command-file fallback exists.
