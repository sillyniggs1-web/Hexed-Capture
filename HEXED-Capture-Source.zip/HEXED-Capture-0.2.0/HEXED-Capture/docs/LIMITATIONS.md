# Limitations (0.2.0)
- Not device-tested. Compiled only against stub headers on the host; the real build is the GitHub Actions run.
- Verified on host: PNG/JPEG writers, flip/scale, NV12/I420 conversion, script scanner.
- AML has no UI API: the "native menu" is a mimgui menu in the Lua script (same as the other HEXED menus).
- Lua "visual mod detection" is a text scan of script sources (mimgui/render* usage), not runtime introspection.
- Hiding a script = `pause()`; it freezes the whole script, not just its overlay, and may not hide mimgui overlays on this build. Use Test hide.
- `glReadPixels` stalls the GPU: cost scales with resolution x FPS. Lower resolution/FPS if the game slows. No audio track.
- Android system overlays are excluded by construction (the game's own back buffer is read).
- Custom folders outside Android/data/<pkg> may be refused by scoped storage; the plugin falls back to its default folder.
- Recording uses CPU colour conversion (NV12, I420 fallback); some encoders may reject sizes/bitrates.
