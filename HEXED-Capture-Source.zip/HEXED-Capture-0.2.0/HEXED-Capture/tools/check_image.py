import sys
from PIL import Image
d = sys.argv[1]
def px(im, x, y): return im.convert("RGB").getpixel((x, y))
ok = True
for name, size in (("t.png", (203, 117)), ("t_half.png", (100, 60)), ("t.jpg", (203, 117)), ("t_half.jpg", (100, 60))):
    im = Image.open(f"{d}/{name}"); im.load()
    w, h = im.size
    top = px(im, w // 2, 2)          # picture top  -> red-ish
    bot = px(im, w // 2, h - 3)      # picture bottom -> blue-ish
    good = im.size == size and top[0] > 150 and top[2] < 90 and bot[2] > 150 and bot[0] < 90
    print(name, im.format, im.size, "top", top, "bottom", bot, "OK" if good else "FAIL")
    ok &= good
# YUV check: top-left Y of a red-ish pixel must be lower than a blue-ish one's U must be high
nv = open("/tmp/nv12.bin", "rb").read(); i4 = open("/tmp/i420.bin", "rb").read()
W, H = 64, 32
yTop = nv[5 * W + 10]; yBot = nv[(H - 6) * W + 10]
u_top = nv[W * H + (5 // 2) * W + (10 // 2) * 2]; v_top = nv[W * H + (5 // 2) * W + (10 // 2) * 2 + 1]
print("nv12 top Y", yTop, "U", u_top, "V", v_top, "(red => V>128, U<128)")
yes = v_top > 150 and u_top < 128
u_i = i4[W * H + (5 // 2) * (W // 2) + 10 // 2]; v_i = i4[W * H + (W // 2) * (H // 2) + (5 // 2) * (W // 2) + 10 // 2]
print("i420 top U", u_i, "V", v_i)
yes &= (u_i == u_top and v_i == v_top)
print("YUV", "OK" if yes else "FAIL")
sys.exit(0 if ok and yes else 1)
