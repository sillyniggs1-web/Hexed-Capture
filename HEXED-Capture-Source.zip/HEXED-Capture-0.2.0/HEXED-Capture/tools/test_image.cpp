// Host-side test for the PNG / JPEG writers and the YUV converter.
// Build: g++ -O2 -std=c++17 -Isrc tools/test_image.cpp src/image.cpp -lz -o /tmp/test_image
// Run  : /tmp/test_image /tmp/out && python3 tools/check_image.py /tmp/out
#include "image.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <vector>
using namespace hexed::image;
int main(int argc, char** argv)
{
    const char* dir = argc > 1 ? argv[1] : ".";
    const int W = 203, H = 117;                 // odd sizes on purpose
    std::vector<uint8_t> px((size_t)W * H * 4);
    // bottom-up source: row 0 is the BOTTOM of the picture.
    // Picture: top half red, bottom half blue, green gradient left->right, alpha 0 (must be ignored)
    for (int y = 0; y < H; y++)
        for (int x = 0; x < W; x++) {
            bool top = y >= H / 2;
            uint8_t* p = &px[((size_t)y * W + x) * 4];
            p[0] = top ? 220 : 20;
            p[1] = (uint8_t)(x * 255 / (W - 1));
            p[2] = top ? 20 : 220;
            p[3] = 0;
        }
    char path[600];
    snprintf(path, sizeof(path), "%s/t.png", dir);       if (!WritePNG(path, px.data(), W, H, W, H)) return 1;
    snprintf(path, sizeof(path), "%s/t_half.png", dir);  if (!WritePNG(path, px.data(), W, H, 100, 60)) return 2;
    snprintf(path, sizeof(path), "%s/t.jpg", dir);       if (!WriteJPG(path, px.data(), W, H, W, H, 90)) return 3;
    snprintf(path, sizeof(path), "%s/t_half.jpg", dir);  if (!WriteJPG(path, px.data(), W, H, 100, 60, 75)) return 4;
    // yuv: 64x32 out
    std::vector<uint8_t> yuv(64 * 32 * 3 / 2);
    RgbaToYuv420(px.data(), W, H, yuv.data(), 64, 32, true);
    FILE* f = fopen("/tmp/nv12.bin", "wb"); fwrite(yuv.data(), 1, yuv.size(), f); fclose(f);
    RgbaToYuv420(px.data(), W, H, yuv.data(), 64, 32, false);
    f = fopen("/tmp/i420.bin", "wb"); fwrite(yuv.data(), 1, yuv.size(), f); fclose(f);
    return 0;
}
