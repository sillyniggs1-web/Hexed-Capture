#!/bin/bash
set -e
ROOT="$(cd "$(dirname "$0")" && pwd)"
export ANDROID_NDK_HOME="${ANDROID_NDK_HOME:-$NDK_ROOT}"
if [ -z "$ANDROID_NDK_HOME" ]; then
  echo "Set ANDROID_NDK_HOME to your NDK (r26d recommended)"
  exit 1
fi
ndk-build -C "$ROOT/jni" NDK_LIBS_OUT="$ROOT/libs" NDK_OUT="$ROOT/obj" -j$(nproc 2>/dev/null || echo 4)
echo "Built: $ROOT/libs/armeabi-v7a/libHEXED_Capture.so"
