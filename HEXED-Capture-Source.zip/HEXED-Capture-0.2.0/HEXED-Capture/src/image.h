#pragma once
#include <stdint.h>

namespace hexed {
namespace image {

// Source is tightly packed RGBA8, BOTTOM-UP (the order glReadPixels returns).
// Output is resized (nearest neighbour) to ow x oh and written top-down.
// The alpha channel is dropped on purpose: the default framebuffer alpha is
// not guaranteed to be 255 and a transparent PNG would look empty in viewers.
bool WritePNG(const char* path, const uint8_t* rgba, int sw, int sh, int ow, int oh);
bool WriteJPG(const char* path, const uint8_t* rgba, int sw, int sh, int ow, int oh, int quality);

// RGBA(bottom-up, sw x sh) -> YUV420 (top-down, ow x oh, both even).
// nv12 = true: Y plane + interleaved UV (COLOR_FormatYUV420SemiPlanar = 21)
// nv12 = false: Y + U + V planes   (COLOR_FormatYUV420Planar = 19)
void RgbaToYuv420(const uint8_t* rgba, int sw, int sh, uint8_t* dst, int ow, int oh, bool nv12);

}
}
