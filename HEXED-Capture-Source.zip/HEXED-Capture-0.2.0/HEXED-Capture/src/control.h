#pragma once
#include <stddef.h>
namespace hexed {
namespace control {
void LoadConfig();
void SaveConfig();
// One text command (see README). Returns 1 on success, 0 on failure (see "error=" in the status).
int Command(const char* line);
void BuildStatus(char* out, size_t n);
// Starts the service thread: polls hexed_capture.cmd, writes hexed_capture.status.
void StartService(void (*onSurvived)());
}
}
