/*
 * Present hook.
 *
 * Verified in the supplied APK (libGTASA.so, SA-MP Nezuko 1.0.3 TESTING):
 *   - libGTASA does NOT import eglSwapBuffers. OS_ScreenSwapBuffers (exported,
 *     _Z20OS_ScreenSwapBuffersv, 104 bytes) swaps through JNI
 *     (JNIEnv::CallBooleanMethod), i.e. EGL10.eglSwapBuffers on the Java side.
 *   - RQ_Command_rqSwapBuffers (_Z24RQ_Command_rqSwapBuffersRPc) is only 4 bytes
 *     long: an inline hook there overwrites the next function, so it is NOT hooked.
 *
 * Mode EGL (default): hook libEGL's eglSwapBuffers. Anything drawn by native code
 *   before the swap (game, SA-MP, ImGui overlays) is in the back buffer here.
 * Mode OS : hook OS_ScreenSwapBuffers in libGTASA (runs right before the JNI swap).
 */
#include "hook.h"
#include "capture.h"
#include "state.h"

#include <mod/amlmod.h>
#include <mod/logger.h>

#include <EGL/egl.h>
#include <dlfcn.h>

namespace hexed {
namespace hook {

static EGLBoolean (*orig_egl)(EGLDisplay, EGLSurface) = nullptr;
static void (*orig_os)() = nullptr;

static EGLBoolean hk_egl(EGLDisplay d, EGLSurface s)
{
    capture::OnPresent(d, s);
    return orig_egl ? orig_egl(d, s) : EGL_FALSE;
}

static void hk_os()
{
    capture::OnPresent(EGL_NO_DISPLAY, EGL_NO_SURFACE);
    if (orig_os) orig_os();
}

static bool InstallEgl()
{
    void* h = dlopen("libEGL.so", RTLD_NOW | RTLD_NOLOAD);
    if (!h) h = dlopen("libEGL.so", RTLD_NOW);
    if (!h) { HLog("hook: libEGL.so not found"); return false; }
    void* p = dlsym(h, "eglSwapBuffers");
    if (!p) { HLog("hook: eglSwapBuffers not found"); return false; }
    if (!aml->Hook(p, (void*)hk_egl, (void**)&orig_egl) || !orig_egl) {
        HLog("hook: AML Hook(eglSwapBuffers) failed");
        orig_egl = nullptr;
        return false;
    }
    HLog("hook: eglSwapBuffers @ %p", p);
    return true;
}

static bool InstallOs()
{
    uintptr_t lib = aml->GetLib("libGTASA.so");
    if (!lib) { HLog("hook: libGTASA.so not found"); return false; }
    uintptr_t p = aml->GetSym(lib, "_Z20OS_ScreenSwapBuffersv");
    if (!p) { HLog("hook: _Z20OS_ScreenSwapBuffersv not exported"); return false; }
    if (!aml->Hook((void*)p, (void*)hk_os, (void**)&orig_os) || !orig_os) {
        HLog("hook: AML Hook(OS_ScreenSwapBuffers) failed");
        orig_os = nullptr;
        return false;
    }
    HLog("hook: OS_ScreenSwapBuffers @ %p", (void*)p);
    return true;
}

bool Install(int preferred)
{
    int order[2] = {preferred == HOOK_OS ? HOOK_OS : HOOK_EGL, preferred == HOOK_OS ? HOOK_EGL : HOOK_OS};
    for (int i = 0; i < 2; i++) {
        bool ok = order[i] == HOOK_EGL ? InstallEgl() : InstallOs();
        if (ok) { g.activeHook.store(order[i]); return true; }
    }
    g.activeHook.store(-1);
    return false;
}

}
}
