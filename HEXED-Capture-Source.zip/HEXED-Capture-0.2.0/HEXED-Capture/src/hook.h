#pragma once
namespace hexed {
namespace hook {
// Installs exactly ONE present hook (never several: they would all fire per frame).
// preferred: HookMode value. Falls back to the other one if the first cannot be installed.
bool Install(int preferred);
}
}
