#pragma once
#include <EGL/egl.h>

namespace hexed {
namespace capture {

bool Init();                 // starts the worker; enables read-back
void Shutdown();

// Render thread, right before the frame is presented.
// dpy/surf may be EGL_NO_* (OS_ScreenSwapBuffers hook): current ones are used.
void OnPresent(EGLDisplay dpy, EGLSurface surf);

bool StartRecording();
bool StopRecording();
void PauseRecording();
void ResumeRecording();

}
}
