/*
 * Worker thread: PNG/JPEG writing and the MediaCodec + MediaMuxer recorder.
 *
 * Render thread: glReadPixels into a slot (no extra copy) -> job queue.
 * Worker thread: colour conversion, encode, mux, file IO.
 * The render thread never blocks on encoding; if all slots are busy the frame is dropped.
 */
#include "pipeline.h"
#include "image.h"
#include "state.h"

#include <media/NdkMediaCodec.h>
#include <media/NdkMediaFormat.h>
#include <media/NdkMediaMuxer.h>

#include <deque>
#include <vector>
#include <errno.h>
#include <fcntl.h>
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <unistd.h>
#include <sys/stat.h>

namespace hexed {
namespace pipe {

// ---------------------------------------------------------------- slots
static const int NSLOT = 3;
struct Slot {
    uint8_t* data = nullptr;
    size_t cap = 0;
    int refs = 0;          // 0 = free
    bool reserved = false; // handed to the render thread, not yet submitted
};
static Slot g_slot[NSLOT];

// ---------------------------------------------------------------- queue / commands
enum JobType { JOB_SHOT = 0, JOB_FRAME = 1 };
struct Job { int type; int slot; int w, h; int64_t ptsUs; };
enum CmdType { CMD_NONE = 0, CMD_START, CMD_STOP, CMD_QUIT };

static pthread_mutex_t g_mu = PTHREAD_MUTEX_INITIALIZER;
static pthread_cond_t  g_cv = PTHREAD_COND_INITIALIZER;
static std::deque<Job> g_q;
static pthread_t g_thr;
static bool g_thrRunning = false;
static int  g_cmd = CMD_NONE;
static bool g_cmdDone = false;
static bool g_cmdResult = false;

// ---------------------------------------------------------------- recorder state (worker thread only)
static AMediaCodec* g_codec = nullptr;
static AMediaMuxer* g_muxer = nullptr;
static int  g_fd = -1;
static int  g_track = -1;
static bool g_muxStarted = false;
static bool g_nv12 = true;
static int  g_ow = 0, g_oh = 0;
static int64_t g_lastPts = 0;
static char g_recPath[640];
static std::vector<uint8_t>* g_yuv = nullptr;

// ================================================================ slots
uint8_t* Acquire(int w, int h, int* slotOut)
{
    size_t need = (size_t)w * h * 4;
    uint8_t* r = nullptr;
    pthread_mutex_lock(&g_mu);
    for (int i = 0; i < NSLOT; i++) {
        Slot& s = g_slot[i];
        if (s.refs != 0 || s.reserved) continue;
        if (s.cap < need) {
            free(s.data);
            s.data = (uint8_t*)malloc(need);
            s.cap = s.data ? need : 0;
        }
        if (!s.data) continue;
        s.reserved = true;
        *slotOut = i;
        r = s.data;
        break;
    }
    pthread_mutex_unlock(&g_mu);
    return r;
}

void SetRefs(int slot, int n)
{
    pthread_mutex_lock(&g_mu);
    g_slot[slot].reserved = false;
    g_slot[slot].refs = n;
    pthread_mutex_unlock(&g_mu);
}

void Release(int slot)
{
    pthread_mutex_lock(&g_mu);
    if (g_slot[slot].refs > 0) g_slot[slot].refs--;
    g_slot[slot].reserved = false;
    pthread_mutex_unlock(&g_mu);
}

static void FreeIdleBuffers()
{
    pthread_mutex_lock(&g_mu);
    for (int i = 0; i < NSLOT; i++) {
        if (g_slot[i].refs == 0 && !g_slot[i].reserved && g_slot[i].data) {
            free(g_slot[i].data);
            g_slot[i].data = nullptr;
            g_slot[i].cap = 0;
        }
    }
    pthread_mutex_unlock(&g_mu);
}

static void Push(const Job& j)
{
    pthread_mutex_lock(&g_mu);
    g_q.push_back(j);
    pthread_cond_signal(&g_cv);
    pthread_mutex_unlock(&g_mu);
}

void SubmitShot(int slot, int w, int h)  { Push({JOB_SHOT, slot, w, h, 0}); }
void SubmitFrame(int slot, int w, int h, int64_t ptsUs) { Push({JOB_FRAME, slot, w, h, ptsUs}); }

// ================================================================ screenshots
static void Stamp(char* out, size_t n)
{
    time_t t = time(nullptr);
    struct tm tm;
    localtime_r(&t, &tm);
    snprintf(out, n, "%04d%02d%02d_%02d%02d%02d", tm.tm_year + 1900, tm.tm_mon + 1, tm.tm_mday,
             tm.tm_hour, tm.tm_min, tm.tm_sec);
}

static void OutSize(int sw, int sh, int* ow, int* oh)
{
    int w = g.outW.load(), h = g.outH.load();
    *ow = (w > 0 && h > 0) ? w : sw;
    *oh = (w > 0 && h > 0) ? h : sh;
}

static bool UniquePath(const char* dir, const char* ext, char* out, size_t n)
{
    char stamp[32];
    Stamp(stamp, sizeof(stamp));
    for (int i = 0; i < 100; i++) {
        if (i == 0) snprintf(out, n, "%s/HEXED_%s.%s", dir, stamp, ext);
        else        snprintf(out, n, "%s/HEXED_%s_%d.%s", dir, stamp, i, ext);
        if (access(out, F_OK) != 0) return true;
    }
    return false;
}

static void DoShot(const Job& j)
{
    char dir[400];
    GetShotDir(dir, sizeof(dir));
    bool jpg = g.imgFormat.load() == FMT_JPG;
    const char* ext = jpg ? "jpg" : "png";
    int ow, oh;
    OutSize(j.w, j.h, &ow, &oh);

    char path[640];
    bool ok = false;
    // try the configured folder first, then the default plugin folder
    for (int attempt = 0; attempt < 2 && !ok; attempt++) {
        char d[420];
        if (attempt == 0) snprintf(d, sizeof(d), "%s", dir);
        else snprintf(d, sizeof(d), "%s/HEXED_Screenshots", DataDir());
        if (!d[0] || !MakeDirs(d)) continue;
        if (!UniquePath(d, ext, path, sizeof(path))) continue;
        ok = jpg ? image::WriteJPG(path, g_slot[j.slot].data, j.w, j.h, ow, oh, g.jpegQuality.load())
                 : image::WritePNG(path, g_slot[j.slot].data, j.w, j.h, ow, oh);
        if (!ok && attempt == 0)
            HLog("screenshot: cannot write to '%s' (%s), falling back to default folder", d, strerror(errno));
    }
    if (ok) {
        g.shotsSaved.fetch_add(1);
        SetLastFile(path);
        HLog("screenshot saved: %s (%dx%d)", path, ow, oh);
    } else {
        SetError("screenshot failed (no writable folder)");
    }
}

// ================================================================ recorder
static void CloseRecorder(bool deleteFile)
{
    if (g_codec) {
        AMediaCodec_stop(g_codec);
        AMediaCodec_delete(g_codec);
        g_codec = nullptr;
    }
    if (g_muxer) {
        if (g_muxStarted) AMediaMuxer_stop(g_muxer);
        AMediaMuxer_delete(g_muxer);
        g_muxer = nullptr;
    }
    g_muxStarted = false;
    g_track = -1;
    if (g_fd >= 0) { close(g_fd); g_fd = -1; }
    if (deleteFile && g_recPath[0]) remove(g_recPath);
    delete g_yuv;
    g_yuv = nullptr;
}

static bool OpenRecorder()
{
    int sw = g.srcW.load(), sh = g.srcH.load();
    if (sw <= 0 || sh <= 0) { SetError("recording: no frame seen yet, try again in a second"); return false; }

    int w = g.outW.load(), h = g.outH.load();
    if (!(w > 0 && h > 0)) { w = sw; h = sh; }
    // Encoders are happiest with 16-aligned sizes and this also makes
    // stride == width and slice-height == height, which the buffer API assumes.
    w &= ~15; h &= ~15;
    if (w < 32) w = 32;
    if (h < 32) h = 32;
    g_ow = w; g_oh = h;

    char dir[400];
    GetRecDir(dir, sizeof(dir));
    bool placed = false;
    for (int attempt = 0; attempt < 2 && !placed; attempt++) {
        char d[420];
        if (attempt == 0) snprintf(d, sizeof(d), "%s", dir);
        else snprintf(d, sizeof(d), "%s/HEXED_Recordings", DataDir());
        if (!d[0] || !MakeDirs(d)) continue;
        if (!UniquePath(d, "mp4", g_recPath, sizeof(g_recPath))) continue;
        // MediaMuxer needs a READ+WRITE descriptor.
        g_fd = open(g_recPath, O_CREAT | O_RDWR | O_TRUNC, 0664);
        if (g_fd >= 0) placed = true;
        else HLog("recording: cannot open '%s' (%s)", g_recPath, strerror(errno));
    }
    if (!placed) { SetError("recording: no writable folder"); g_recPath[0] = 0; return false; }

    g_muxer = AMediaMuxer_new(g_fd, AMEDIAMUXER_OUTPUT_FORMAT_MPEG_4);
    if (!g_muxer) { SetError("AMediaMuxer_new failed"); CloseRecorder(true); return false; }

    int fps = g.fps.load();
    if (fps < 1) fps = 30;
    int br = g.bitrateKbps.load();
    if (br < 250) br = 250;

    static const int kFormats[2] = {21 /*SemiPlanar NV12*/, 19 /*Planar I420*/};
    bool configured = false;
    for (int i = 0; i < 2 && !configured; i++) {
        g_codec = AMediaCodec_createEncoderByType("video/avc");
        if (!g_codec) { SetError("no H.264 encoder available"); CloseRecorder(true); return false; }
        AMediaFormat* fmt = AMediaFormat_new();
        AMediaFormat_setString(fmt, AMEDIAFORMAT_KEY_MIME, "video/avc");
        AMediaFormat_setInt32(fmt, AMEDIAFORMAT_KEY_WIDTH, w);
        AMediaFormat_setInt32(fmt, AMEDIAFORMAT_KEY_HEIGHT, h);
        AMediaFormat_setInt32(fmt, AMEDIAFORMAT_KEY_BIT_RATE, br * 1000);
        AMediaFormat_setInt32(fmt, AMEDIAFORMAT_KEY_FRAME_RATE, fps);
        AMediaFormat_setInt32(fmt, AMEDIAFORMAT_KEY_I_FRAME_INTERVAL, 1);
        AMediaFormat_setInt32(fmt, AMEDIAFORMAT_KEY_COLOR_FORMAT, kFormats[i]);
        media_status_t st = AMediaCodec_configure(g_codec, fmt, nullptr, nullptr, AMEDIACODEC_CONFIGURE_FLAG_ENCODE);
        AMediaFormat_delete(fmt);
        if (st == AMEDIA_OK && AMediaCodec_start(g_codec) == AMEDIA_OK) {
            g_nv12 = (kFormats[i] == 21);
            configured = true;
            HLog("recording: encoder configured %dx%d %d fps %d kbps colour-format %d", w, h, fps, br, kFormats[i]);
        } else {
            HLog("recording: colour format %d rejected (status %d)", kFormats[i], (int)st);
            AMediaCodec_delete(g_codec);
            g_codec = nullptr;
        }
    }
    if (!configured) { SetError("encoder rejected both NV12 and I420 at %dx%d", w, h); CloseRecorder(true); return false; }

    g_yuv = new std::vector<uint8_t>((size_t)w * h * 3 / 2);
    g_lastPts = 0;
    return true;
}

static void Drain(bool eos)
{
    if (!g_codec) return;
    AMediaCodecBufferInfo info;
    int64_t deadline = NowUs() + 3000000;
    for (;;) {
        ssize_t ox = AMediaCodec_dequeueOutputBuffer(g_codec, &info, eos ? 10000 : 0);
        if (ox == AMEDIACODEC_INFO_TRY_AGAIN_LATER) {
            if (!eos || NowUs() > deadline) break;
            continue;
        }
        if (ox == AMEDIACODEC_INFO_OUTPUT_FORMAT_CHANGED) {
            if (!g_muxStarted && g_muxer) {
                AMediaFormat* of = AMediaCodec_getOutputFormat(g_codec);
                g_track = AMediaMuxer_addTrack(g_muxer, of);
                AMediaFormat_delete(of);
                if (g_track >= 0 && AMediaMuxer_start(g_muxer) == AMEDIA_OK) {
                    g_muxStarted = true;
                    HLog("recording: muxer started (track %d)", g_track);
                } else {
                    SetError("muxer start failed");
                }
            }
            continue;
        }
        if (ox == AMEDIACODEC_INFO_OUTPUT_BUFFERS_CHANGED) continue;
        if (ox < 0) break;

        size_t sz = 0;
        uint8_t* ob = AMediaCodec_getOutputBuffer(g_codec, (size_t)ox, &sz);
        bool isConfig = (info.flags & AMEDIACODEC_BUFFER_FLAG_CODEC_CONFIG) != 0;
        if (ob && g_muxStarted && !isConfig && info.size > 0) {
            AMediaMuxer_writeSampleData(g_muxer, (size_t)g_track, ob, &info);
            g.framesEncoded.fetch_add(1);
        }
        bool end = (info.flags & AMEDIACODEC_BUFFER_FLAG_END_OF_STREAM) != 0;
        AMediaCodec_releaseOutputBuffer(g_codec, (size_t)ox, false);
        if (end) break;
    }
}

static void DoFrame(const Job& j)
{
    if (!g_codec) return;
    ssize_t ix = AMediaCodec_dequeueInputBuffer(g_codec, 20000);
    if (ix < 0) { g.framesDropped.fetch_add(1); Drain(false); return; }
    size_t cap = 0;
    uint8_t* buf = AMediaCodec_getInputBuffer(g_codec, (size_t)ix, &cap);
    size_t need = (size_t)g_ow * g_oh * 3 / 2;
    if (!buf || cap < need) {
        AMediaCodec_queueInputBuffer(g_codec, (size_t)ix, 0, 0, j.ptsUs, 0);
        SetError("encoder input buffer too small (%zu < %zu)", cap, need);
        return;
    }
    image::RgbaToYuv420(g_slot[j.slot].data, j.w, j.h, buf, g_ow, g_oh, g_nv12);
    AMediaCodec_queueInputBuffer(g_codec, (size_t)ix, 0, need, j.ptsUs, 0);
    g_lastPts = j.ptsUs;
    Drain(false);
}

static bool FinishRecording()
{
    bool hadFrames = false;
    if (g_codec) {
        ssize_t ix = AMediaCodec_dequeueInputBuffer(g_codec, 200000);
        if (ix >= 0)
            AMediaCodec_queueInputBuffer(g_codec, (size_t)ix, 0, 0, g_lastPts + 1000,
                                         AMEDIACODEC_BUFFER_FLAG_END_OF_STREAM);
        Drain(true);
        hadFrames = g_muxStarted && g.framesEncoded.load() > 0;
    }
    char path[640];
    snprintf(path, sizeof(path), "%s", g_recPath);
    CloseRecorder(!hadFrames);
    if (hadFrames) { SetLastFile(path); HLog("recording saved: %s", path); }
    else SetError("recording produced no frames; file removed");
    return hadFrames;
}

// ================================================================ worker
static void ProcessJob(const Job& j)
{
    if (j.type == JOB_SHOT) DoShot(j);
    else DoFrame(j);
    Release(j.slot);
}

static void* Worker(void*)
{
    HLog("worker thread started");
    for (;;) {
        Job job{};
        int cmd = CMD_NONE;
        bool haveJob = false;
        pthread_mutex_lock(&g_mu);
        while ((g_cmd == CMD_NONE || g_cmdDone) && g_q.empty())
            pthread_cond_wait(&g_cv, &g_mu);
        if (g_cmd != CMD_NONE && !g_cmdDone) {
            cmd = g_cmd;
        } else if (!g_q.empty()) {
            job = g_q.front();
            g_q.pop_front();
            haveJob = true;
        }
        pthread_mutex_unlock(&g_mu);

        if (cmd != CMD_NONE) {
            bool res = true;
            if (cmd == CMD_START) {
                g.framesEncoded = 0; g.framesDropped = 0; g.framesRead = 0;
                res = OpenRecorder();
            } else if (cmd == CMD_STOP || cmd == CMD_QUIT) {
                // flush what is already queued, then close the file
                for (;;) {
                    Job j2{};
                    bool have = false;
                    pthread_mutex_lock(&g_mu);
                    if (!g_q.empty()) { j2 = g_q.front(); g_q.pop_front(); have = true; }
                    pthread_mutex_unlock(&g_mu);
                    if (!have) break;
                    ProcessJob(j2);
                }
                res = g_codec ? FinishRecording() : true;
            }
            pthread_mutex_lock(&g_mu);
            g_cmdResult = res;
            g_cmdDone = true;
            pthread_cond_broadcast(&g_cv);
            pthread_mutex_unlock(&g_mu);
            if (cmd == CMD_QUIT) break;
            continue;
        }
        if (haveJob) {
            ProcessJob(job);
            pthread_mutex_lock(&g_mu);
            bool idle = g_q.empty();
            pthread_mutex_unlock(&g_mu);
            if (idle && !g_codec) FreeIdleBuffers();   // keep memory low when not recording
        }
    }
    FreeIdleBuffers();
    HLog("worker thread exit");
    return nullptr;
}

static bool RunCmd(int cmd, int timeoutMs)
{
    if (!g_thrRunning) return false;
    pthread_mutex_lock(&g_mu);
    g_cmd = cmd;
    g_cmdDone = false;
    pthread_cond_broadcast(&g_cv);
    int64_t deadline = NowUs() + (int64_t)timeoutMs * 1000;
    while (!g_cmdDone && NowUs() < deadline) {
        struct timespec ts;
        clock_gettime(CLOCK_REALTIME, &ts);
        ts.tv_nsec += 50 * 1000000L;
        if (ts.tv_nsec >= 1000000000L) { ts.tv_sec++; ts.tv_nsec -= 1000000000L; }
        pthread_cond_timedwait(&g_cv, &g_mu, &ts);
    }
    bool done = g_cmdDone;
    bool res = g_cmdResult;
    g_cmd = CMD_NONE;
    g_cmdDone = false;
    pthread_mutex_unlock(&g_mu);
    return done && res;
}

bool StartRecording() { return RunCmd(CMD_START, 4000); }
bool StopRecording()  { return RunCmd(CMD_STOP, 8000); }

bool Init()
{
    if (g_thrRunning) return true;
    if (pthread_create(&g_thr, nullptr, Worker, nullptr) != 0) {
        HLog("pipeline: pthread_create failed");
        return false;
    }
    g_thrRunning = true;
    return true;
}

void Shutdown()
{
    if (!g_thrRunning) return;
    RunCmd(CMD_QUIT, 8000);
    pthread_join(g_thr, nullptr);
    g_thrRunning = false;
}

}
}
