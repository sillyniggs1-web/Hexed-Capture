#pragma once
#include <stddef.h>
namespace hexed {
namespace scan {
// Lists *.lua in `dir` (and <subdir>/main.lua one level down) and flags the ones whose
// SOURCE TEXT uses overlay/draw APIs. Output lines: "<file>\t<flags>\n"
//   flags: 1 = mimgui/imgui overlay, 2 = render* draw functions
// Read-only; scripts are never modified.
int Scripts(const char* dir, char* out, size_t outLen);
}
}
