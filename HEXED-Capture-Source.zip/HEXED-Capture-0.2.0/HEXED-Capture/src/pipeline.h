#pragma once
#include <stdint.h>

namespace hexed {
namespace pipe {

bool Init();        // starts the worker thread
void Shutdown();    // stops recording, joins the worker, frees buffers

// ---- render thread side ----
// Returns a buffer of at least w*h*4 bytes (or null if all slots are busy).
uint8_t* Acquire(int w, int h, int* slot);
// After the GL read-back: how many jobs will use this slot (0 = give it back).
void SubmitShot(int slot, int w, int h);
void SubmitFrame(int slot, int w, int h, int64_t ptsUs);
void Release(int slot);
// Call once after the slot has been filled; n = number of Submit* calls that follow.
void SetRefs(int slot, int n);

// ---- control side (any thread, blocks until the worker finished) ----
bool StartRecording();
bool StopRecording();

}
}
