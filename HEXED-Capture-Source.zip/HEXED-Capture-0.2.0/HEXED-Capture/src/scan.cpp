#include "scan.h"
#include "state.h"

#include <ctype.h>
#include <dirent.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>

namespace hexed {
namespace scan {

static bool EndsWithNoCase(const char* s, const char* suf)
{
    size_t a = strlen(s), b = strlen(suf);
    if (a < b) return false;
    for (size_t i = 0; i < b; i++)
        if (tolower((unsigned char)s[a - b + i]) != tolower((unsigned char)suf[i])) return false;
    return true;
}

static int Classify(const char* path)
{
    FILE* f = fopen(path, "rb");
    if (!f) return -1;
    const size_t MAXB = 512 * 1024;
    char* buf = (char*)malloc(MAXB + 1);
    if (!buf) { fclose(f); return -1; }
    size_t n = fread(buf, 1, MAXB, f);
    fclose(f);
    buf[n] = 0;
    // a stray NUL would hide the rest from strstr: precompiled chunks are not text anyway
    int flags = 0;
    static const char* kImgui[] = {"mimgui", "imgui.OnFrame", "GetBackgroundDrawList", "GetForegroundDrawList", nullptr};
    static const char* kRender[] = {"renderDraw", "renderFont", "renderGetFontDrawText", "renderBegin", nullptr};
    for (int i = 0; kImgui[i]; i++) if (strstr(buf, kImgui[i])) { flags |= 1; break; }
    for (int i = 0; kRender[i]; i++) if (strstr(buf, kRender[i])) { flags |= 2; break; }
    free(buf);
    return flags;
}

static bool Append(char* out, size_t outLen, size_t* used, const char* line)
{
    size_t l = strlen(line);
    if (*used + l + 1 >= outLen) return false;
    memcpy(out + *used, line, l);
    *used += l;
    out[*used] = 0;
    return true;
}

int Scripts(const char* dir, char* out, size_t outLen)
{
    if (!out || outLen < 2) return -1;
    out[0] = 0;
    if (!dir || !dir[0]) return -1;
    DIR* d = opendir(dir);
    if (!d) { SetError("scan: cannot open '%s'", dir); return -1; }

    size_t used = 0;
    int count = 0;
    struct dirent* e;
    while ((e = readdir(d)) != nullptr) {
        if (e->d_name[0] == '.') continue;
        char full[640];
        snprintf(full, sizeof(full), "%s/%s", dir, e->d_name);
        struct stat st;
        if (stat(full, &st) != 0) continue;

        char shown[300] = {0};
        char target[700] = {0};
        if (S_ISREG(st.st_mode) && EndsWithNoCase(e->d_name, ".lua")) {
            snprintf(shown, sizeof(shown), "%s", e->d_name);
            snprintf(target, sizeof(target), "%s", full);
        } else if (S_ISDIR(st.st_mode)) {
            snprintf(target, sizeof(target), "%s/main.lua", full);
            struct stat st2;
            if (stat(target, &st2) != 0) continue;
            snprintf(shown, sizeof(shown), "%s/main.lua", e->d_name);
        } else {
            continue;
        }
        int fl = Classify(target);
        if (fl < 0) continue;
        char line[400];
        snprintf(line, sizeof(line), "%s\t%d\n", shown, fl);
        if (!Append(out, outLen, &used, line)) break;
        count++;
    }
    closedir(d);
    return count;
}

}
}
