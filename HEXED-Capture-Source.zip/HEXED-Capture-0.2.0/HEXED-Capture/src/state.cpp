#include "state.h"
#include <mod/amlmod.h>
#include <mod/logger.h>

#include <pthread.h>
#include <stdarg.h>
#include <stdio.h>
#include <string.h>
#include <time.h>
#include <unistd.h>
#include <errno.h>
#include <sys/stat.h>
#include <android/log.h>

namespace hexed {

Shared g;

static pthread_mutex_t g_strMu = PTHREAD_MUTEX_INITIALIZER;
static char s_shotDir[400];
static char s_recDir[400];
static char s_lastFile[512];
static char s_error[256];

int64_t NowUs()
{
    struct timespec t;
    clock_gettime(CLOCK_MONOTONIC, &t);
    return (int64_t)t.tv_sec * 1000000LL + t.tv_nsec / 1000;
}

static void CopyLocked(char* dst, size_t dstN, const char* src)
{
    if (!dstN) return;
    pthread_mutex_lock(&g_strMu);
    snprintf(dst, dstN, "%s", src ? src : "");
    pthread_mutex_unlock(&g_strMu);
}
static void GetLocked(const char* src, char* out, size_t n)
{
    if (!out || !n) return;
    pthread_mutex_lock(&g_strMu);
    snprintf(out, n, "%s", src);
    pthread_mutex_unlock(&g_strMu);
}

void SetShotDir(const char* p)  { CopyLocked(s_shotDir, sizeof(s_shotDir), p); }
void SetRecDir(const char* p)   { CopyLocked(s_recDir, sizeof(s_recDir), p); }
void GetShotDir(char* o, size_t n) { GetLocked(s_shotDir, o, n); }
void GetRecDir(char* o, size_t n)  { GetLocked(s_recDir, o, n); }
void SetLastFile(const char* p) { CopyLocked(s_lastFile, sizeof(s_lastFile), p); }
void GetLastFile(char* o, size_t n) { GetLocked(s_lastFile, o, n); }

void SetError(const char* fmt, ...)
{
    char buf[256];
    va_list ap;
    va_start(ap, fmt);
    vsnprintf(buf, sizeof(buf), fmt, ap);
    va_end(ap);
    CopyLocked(s_error, sizeof(s_error), buf);
    HLog("ERROR: %s", buf);
}
void GetError(char* o, size_t n) { GetLocked(s_error, o, n); }

bool MakeDirs(const char* path)
{
    if (!path || !path[0]) return false;
    char tmp[512];
    snprintf(tmp, sizeof(tmp), "%s", path);
    size_t len = strlen(tmp);
    while (len > 1 && tmp[len - 1] == '/') tmp[--len] = 0;
    for (char* p = tmp + 1; *p; ++p) {
        if (*p == '/') {
            *p = 0;
            mkdir(tmp, 0775);
            *p = '/';
        }
    }
    if (mkdir(tmp, 0775) != 0 && errno != EEXIST) return false;
    return access(tmp, W_OK) == 0;
}

// ---- data directory -------------------------------------------------------
static char s_dataDir[512];
static char s_mediaDir[512];
static bool s_dirTried = false;

static bool EndsWith(const char* s, const char* suf)
{
    size_t a = strlen(s), b = strlen(suf);
    return a >= b && !strcmp(s + a - b, suf);
}

const char* DataDir()
{
    if (s_dirTried) return s_dataDir;
    s_dirTried = true;
    s_dataDir[0] = 0;
    s_mediaDir[0] = 0;
    if (!aml) return s_dataDir;

    // IAML::GetAndroidDataPath() is documented as ".../Android/data/<pkg>/files/*".
    // Do not assume whether the trailing "/files" is included.
    const char* p = aml->GetAndroidDataPath();
    if (p && p[0]) {
        snprintf(s_dataDir, sizeof(s_dataDir), "%s", p);
        size_t n = strlen(s_dataDir);
        while (n > 1 && s_dataDir[n - 1] == '/') s_dataDir[--n] = 0;
        if (!EndsWith(s_dataDir, "/files"))
            strncat(s_dataDir, "/files", sizeof(s_dataDir) - strlen(s_dataDir) - 1);
        MakeDirs(s_dataDir);
    }
    if (!s_dataDir[0] || access(s_dataDir, W_OK) != 0) {
        p = aml->GetDataPath();
        if (p && p[0]) {
            snprintf(s_dataDir, sizeof(s_dataDir), "%s", p);
            MakeDirs(s_dataDir);
        }
    }

    // Android/data/<pkg>/files  ->  Android/media/<pkg>/monetloader
    const char* d = strstr(s_dataDir, "/Android/data/");
    if (d) {
        size_t head = (size_t)(d - s_dataDir);
        char pkg[160] = {0};
        const char* q = d + strlen("/Android/data/");
        const char* e = strchr(q, '/');
        size_t pl = e ? (size_t)(e - q) : strlen(q);
        if (pl > 0 && pl < sizeof(pkg)) {
            memcpy(pkg, q, pl);
            snprintf(s_mediaDir, sizeof(s_mediaDir), "%.*s/Android/media/%s/monetloader",
                     (int)head, s_dataDir, pkg);
        }
    }
    return s_dataDir;
}

const char* MediaScriptDir()
{
    DataDir();
    return s_mediaDir;
}

// ---- logging ---------------------------------------------------------------
void HLog(const char* fmt, ...)
{
    char buf[900];
    va_list ap;
    va_start(ap, fmt);
    vsnprintf(buf, sizeof(buf), fmt, ap);
    va_end(ap);

    __android_log_print(ANDROID_LOG_INFO, "HEXED_Capture", "%s", buf);

    const char* dir = DataDir();
    if (!dir || !dir[0]) return;
    char path[640];
    snprintf(path, sizeof(path), "%s/hexed_capture.log", dir);

    // keep the log small: restart it past ~256 KB
    struct stat st;
    if (stat(path, &st) == 0 && st.st_size > 256 * 1024) remove(path);

    FILE* f = fopen(path, "a");
    if (f) {
        fputs(buf, f);
        fputc('\n', f);
        fclose(f);
    }
}

}
