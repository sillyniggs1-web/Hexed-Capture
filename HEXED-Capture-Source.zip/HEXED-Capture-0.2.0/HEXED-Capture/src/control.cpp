#include "control.h"
#include "capture.h"
#include "scan.h"
#include "state.h"

#include <errno.h>
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

namespace hexed {
namespace control {

static int Clamp(int v, int lo, int hi) { return v < lo ? lo : (v > hi ? hi : v); }

// ---------------------------------------------------------------- config file (key=value)
static void CfgPath(char* out, size_t n)
{
    snprintf(out, n, "%s/hexed_capture.ini", DataDir());
}

void LoadConfig()
{
    char path[640];
    CfgPath(path, sizeof(path));
    FILE* f = fopen(path, "r");
    char def[420];
    snprintf(def, sizeof(def), "%s/HEXED_Screenshots", DataDir());
    SetShotDir(def);
    snprintf(def, sizeof(def), "%s/HEXED_Recordings", DataDir());
    SetRecDir(def);
    if (!f) return;
    char line[700];
    while (fgets(line, sizeof(line), f)) {
        size_t l = strlen(line);
        while (l && (line[l - 1] == '\n' || line[l - 1] == '\r')) line[--l] = 0;
        char* eq = strchr(line, '=');
        if (!eq) continue;
        *eq = 0;
        const char* k = line;
        const char* v = eq + 1;
        int iv = atoi(v);
        if (!strcmp(k, "fps")) g.fps = Clamp(iv, 1, 60);
        else if (!strcmp(k, "bitrate")) g.bitrateKbps = Clamp(iv, 250, 60000);
        else if (!strcmp(k, "width")) g.outW = Clamp(iv, 0, 4096);
        else if (!strcmp(k, "height")) g.outH = Clamp(iv, 0, 4096);
        else if (!strcmp(k, "jpeg")) g.jpegQuality = Clamp(iv, 1, 100);
        else if (!strcmp(k, "format")) g.imgFormat = !strcmp(v, "jpg") ? FMT_JPG : FMT_PNG;
        else if (!strcmp(k, "hook")) g.hookMode = !strcmp(v, "os") ? HOOK_OS : HOOK_EGL;
        else if (!strcmp(k, "shot_dir") && v[0]) SetShotDir(v);
        else if (!strcmp(k, "rec_dir") && v[0]) SetRecDir(v);
    }
    fclose(f);
}

void SaveConfig()
{
    char path[640];
    CfgPath(path, sizeof(path));
    FILE* f = fopen(path, "w");
    if (!f) return;
    char sd[400], rd[400];
    GetShotDir(sd, sizeof(sd));
    GetRecDir(rd, sizeof(rd));
    fprintf(f, "fps=%d\nbitrate=%d\nwidth=%d\nheight=%d\njpeg=%d\nformat=%s\nhook=%s\nshot_dir=%s\nrec_dir=%s\n",
            g.fps.load(), g.bitrateKbps.load(), g.outW.load(), g.outH.load(), g.jpegQuality.load(),
            g.imgFormat.load() == FMT_JPG ? "jpg" : "png", g.hookMode.load() == HOOK_OS ? "os" : "egl", sd, rd);
    fclose(f);
}

// ---------------------------------------------------------------- status
void BuildStatus(char* out, size_t n)
{
    static const char* names[] = {"idle", "recording", "paused", "stopping"};
    int st = g.recState.load();
    char sd[400], rd[400], lf[512], er[256];
    GetShotDir(sd, sizeof(sd));
    GetRecDir(rd, sizeof(rd));
    GetLastFile(lf, sizeof(lf));
    GetError(er, sizeof(er));
    int64_t recSec = 0;
    if (st == REC_RECORDING || st == REC_PAUSED)
        recSec = (NowUs() - g.recStartUs.load() - g.pausedTotalUs.load() -
                  (st == REC_PAUSED ? NowUs() - g.pauseBeginUs.load() : 0)) / 1000000;
    snprintf(out, n,
             "state=%s\nfps=%d\nbitrate=%d\nwidth=%d\nheight=%d\njpeg=%d\nformat=%s\nhook=%s\nactive_hook=%d\n"
             "src_w=%d\nsrc_h=%d\nframes_read=%d\nframes_encoded=%d\nframes_dropped=%d\nshots=%d\nrec_seconds=%lld\n"
             "shot_dir=%s\nrec_dir=%s\nlast_file=%s\nerror=%s\nversion=0.2.0\n",
             names[st < 0 || st > 3 ? 0 : st], g.fps.load(), g.bitrateKbps.load(), g.outW.load(), g.outH.load(),
             g.jpegQuality.load(), g.imgFormat.load() == FMT_JPG ? "jpg" : "png", g.hookMode.load() == HOOK_OS ? "os" : "egl",
             g.activeHook.load(), g.srcW.load(), g.srcH.load(), g.framesRead.load(), g.framesEncoded.load(),
             g.framesDropped.load(), g.shotsSaved.load(), (long long)recSec, sd, rd, lf, er);
}

// ---------------------------------------------------------------- commands
static void Trim(char* s)
{
    size_t l = strlen(s);
    while (l && (s[l - 1] == '\n' || s[l - 1] == '\r' || s[l - 1] == ' ' || s[l - 1] == '\t')) s[--l] = 0;
}

int Command(const char* lineIn)
{
    if (!lineIn) return 0;
    char line[700];
    snprintf(line, sizeof(line), "%s", lineIn);
    Trim(line);
    const char* p = line;
    while (*p == ' ') p++;
    if (!*p) return 0;

    char cmd[24] = {0};
    int off = 0;
    sscanf(p, "%23s%n", cmd, &off);
    const char* arg = p + off;
    while (*arg == ' ') arg++;

    if (!strcmp(cmd, "shot"))   { g.wantShot = 1; HLog("cmd: screenshot"); return 1; }
    if (!strcmp(cmd, "start"))  return capture::StartRecording() ? 1 : 0;
    if (!strcmp(cmd, "stop"))   return capture::StopRecording() ? 1 : 0;
    if (!strcmp(cmd, "pause"))  { capture::PauseRecording(); return 1; }
    if (!strcmp(cmd, "resume")) { capture::ResumeRecording(); return 1; }
    if (!strcmp(cmd, "save"))   { SaveConfig(); return 1; }

    if (!strcmp(cmd, "set")) {
        char key[24] = {0};
        int o2 = 0;
        sscanf(arg, "%23s%n", key, &o2);
        const char* val = arg + o2;
        while (*val == ' ') val++;
        int iv = atoi(val);
        if (!strcmp(key, "fps")) g.fps = Clamp(iv, 1, 60);
        else if (!strcmp(key, "bitrate")) g.bitrateKbps = Clamp(iv, 250, 60000);
        else if (!strcmp(key, "width")) g.outW = Clamp(iv, 0, 4096);
        else if (!strcmp(key, "height")) g.outH = Clamp(iv, 0, 4096);
        else if (!strcmp(key, "jpeg")) g.jpegQuality = Clamp(iv, 1, 100);
        else if (!strcmp(key, "format")) g.imgFormat = !strncmp(val, "jpg", 3) ? FMT_JPG : FMT_PNG;
        else if (!strcmp(key, "hook")) g.hookMode = !strncmp(val, "os", 2) ? HOOK_OS : HOOK_EGL;   // next launch
        else { SetError("unknown setting '%s'", key); return 0; }
        SaveConfig();
        return 1;
    }
    if (!strcmp(cmd, "dir")) {
        char which[8] = {0};
        int o2 = 0;
        sscanf(arg, "%7s%n", which, &o2);
        const char* val = arg + o2;
        while (*val == ' ') val++;
        if (!*val) { SetError("dir: empty path"); return 0; }
        if (!MakeDirs(val)) { SetError("dir: cannot create or write '%s'", val); return 0; }
        if (!strcmp(which, "shot")) SetShotDir(val);
        else if (!strcmp(which, "rec")) SetRecDir(val);
        else { SetError("dir: use 'dir shot <path>' or 'dir rec <path>'"); return 0; }
        SaveConfig();
        return 1;
    }
    SetError("unknown command '%s'", cmd);
    return 0;
}

// ---------------------------------------------------------------- file channel + service thread
static void (*s_onSurvived)() = nullptr;

static void WriteFileAtomic(const char* dir, const char* name, const char* data)
{
    char path[700], tmp[720];
    snprintf(path, sizeof(path), "%s/%s", dir, name);
    snprintf(tmp, sizeof(tmp), "%s.tmp", path);
    FILE* f = fopen(tmp, "w");
    if (!f) return;
    fputs(data, f);
    fclose(f);
    rename(tmp, path);
}

static void PollDir(const char* dir)
{
    if (!dir || !dir[0]) return;
    char path[700];
    snprintf(path, sizeof(path), "%s/hexed_capture.cmd", dir);
    if (access(path, R_OK) != 0) return;
    FILE* f = fopen(path, "r");
    if (!f) return;
    char lines[16][700];
    int n = 0;
    while (n < 16 && fgets(lines[n], sizeof(lines[n]), f)) n++;
    fclose(f);
    remove(path);
    for (int i = 0; i < n; i++) {
        Trim(lines[i]);
        if (!strncmp(lines[i], "scan ", 5)) {
            static char body[48 * 1024];
            static char outbuf[48 * 1024 + 64];
            int c = scan::Scripts(lines[i] + 5, body, sizeof(body));
            snprintf(outbuf, sizeof(outbuf), "count=%d\n%s", c, c >= 0 ? body : "");
            WriteFileAtomic(dir, "hexed_capture.scan", outbuf);
        } else {
            Command(lines[i]);
        }
    }
}

static void* Service(void*)
{
    int64_t t0 = NowUs();
    bool survived = false;
    int64_t lastStatus = 0;
    char last[2048] = {0};
    for (;;) {
        usleep(250 * 1000);
        PollDir(DataDir());
        const char* media = MediaScriptDir();
        if (media && media[0]) PollDir(media);

        int64_t now = NowUs();
        if (!survived && now - t0 > 20LL * 1000000) {
            survived = true;
            if (s_onSurvived) s_onSurvived();
        }
        if (now - lastStatus > 500000) {
            lastStatus = now;
            char st[2048];
            BuildStatus(st, sizeof(st));
            if (strcmp(st, last) != 0 || g.recState.load() != REC_IDLE) {
                snprintf(last, sizeof(last), "%s", st);
                WriteFileAtomic(DataDir(), "hexed_capture.status", st);
                if (media && media[0] && access(media, W_OK) == 0) WriteFileAtomic(media, "hexed_capture.status", st);
            }
        }
    }
    return nullptr;
}

void StartService(void (*onSurvived)())
{
    s_onSurvived = onSurvived;
    pthread_t t;
    pthread_attr_t a;
    pthread_attr_init(&a);
    pthread_attr_setdetachstate(&a, PTHREAD_CREATE_DETACHED);
    pthread_create(&t, &a, Service, nullptr);
    pthread_attr_destroy(&a);
}

}
}

// ---------------------------------------------------------------- C API for ffi.load from Lua
extern "C" {
__attribute__((visibility("default"))) int HEXED_Command(const char* line)
{
    return hexed::control::Command(line);
}
__attribute__((visibility("default"))) int HEXED_Status(char* buf, int len)
{
    if (!buf || len < 64) return 0;
    hexed::control::BuildStatus(buf, (size_t)len);
    return 1;
}
__attribute__((visibility("default"))) int HEXED_Scan(const char* dir, char* buf, int len)
{
    if (!buf || len < 16) return -1;
    return hexed::scan::Scripts(dir, buf, (size_t)len);
}
}
