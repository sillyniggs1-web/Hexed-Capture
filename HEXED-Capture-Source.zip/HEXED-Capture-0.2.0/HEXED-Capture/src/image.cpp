#include "image.h"

#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <vector>
#include <zlib.h>

namespace hexed {
namespace image {

// ---------------------------------------------------------------------------
// shared: fetch one output row (RGB8, top-down) from the bottom-up RGBA source
// ---------------------------------------------------------------------------
struct RowSource {
    const uint8_t* src;
    int sw, sh, ow, oh;
    std::vector<int> xmap;

    RowSource(const uint8_t* s, int sw_, int sh_, int ow_, int oh_)
        : src(s), sw(sw_), sh(sh_), ow(ow_), oh(oh_), xmap(ow_)
    {
        for (int x = 0; x < ow; x++) xmap[x] = (int)((int64_t)x * sw / ow) * 4;
    }
    void Row(int oy, uint8_t* rgb) const
    {
        int sy = sh - 1 - (int)((int64_t)oy * sh / oh);   // flip vertically
        const uint8_t* row = src + (size_t)sy * sw * 4;
        for (int x = 0; x < ow; x++) {
            const uint8_t* p = row + xmap[x];
            rgb[x * 3 + 0] = p[0];
            rgb[x * 3 + 1] = p[1];
            rgb[x * 3 + 2] = p[2];
        }
    }
};

// ---------------------------------------------------------------------------
// PNG (zlib streamed, RGB8)
// ---------------------------------------------------------------------------
static void be32(uint8_t* p, uint32_t v)
{
    p[0] = v >> 24; p[1] = v >> 16; p[2] = v >> 8; p[3] = v;
}

static bool Chunk(FILE* f, const char* type, const uint8_t* data, uint32_t len)
{
    uint8_t hdr[8];
    be32(hdr, len);
    memcpy(hdr + 4, type, 4);
    if (fwrite(hdr, 1, 8, f) != 8) return false;
    uLong c = crc32(0L, (const Bytef*)type, 4);
    if (len) {
        if (fwrite(data, 1, len, f) != len) return false;
        c = crc32(c, data, len);
    }
    uint8_t tail[4];
    be32(tail, (uint32_t)c);
    return fwrite(tail, 1, 4, f) == 4;
}

bool WritePNG(const char* path, const uint8_t* rgba, int sw, int sh, int ow, int oh)
{
    if (!path || !rgba || sw <= 0 || sh <= 0 || ow <= 0 || oh <= 0) return false;
    FILE* f = fopen(path, "wb");
    if (!f) return false;

    static const uint8_t sig[8] = {137, 80, 78, 71, 13, 10, 26, 10};
    bool ok = fwrite(sig, 1, 8, f) == 8;

    uint8_t ihdr[13];
    be32(ihdr, (uint32_t)ow);
    be32(ihdr + 4, (uint32_t)oh);
    ihdr[8] = 8;   // bit depth
    ihdr[9] = 2;   // colour type: RGB
    ihdr[10] = ihdr[11] = ihdr[12] = 0;
    ok = ok && Chunk(f, "IHDR", ihdr, 13);

    z_stream zs;
    memset(&zs, 0, sizeof(zs));
    if (deflateInit(&zs, 3) != Z_OK) { fclose(f); remove(path); return false; }

    RowSource rs(rgba, sw, sh, ow, oh);
    std::vector<uint8_t> line((size_t)ow * 3 + 1);
    std::vector<uint8_t> out(64 * 1024);
    line[0] = 0;   // filter: none

    for (int y = 0; y < oh && ok; y++) {
        rs.Row(y, &line[1]);
        zs.next_in = line.data();
        zs.avail_in = (uInt)line.size();
        do {
            zs.next_out = out.data();
            zs.avail_out = (uInt)out.size();
            if (deflate(&zs, Z_NO_FLUSH) == Z_STREAM_ERROR) { ok = false; break; }
            uint32_t n = (uint32_t)(out.size() - zs.avail_out);
            if (n) ok = ok && Chunk(f, "IDAT", out.data(), n);
        } while (zs.avail_out == 0 && ok);
    }
    int zr = Z_OK;
    while (ok && zr != Z_STREAM_END) {
        zs.next_out = out.data();
        zs.avail_out = (uInt)out.size();
        zr = deflate(&zs, Z_FINISH);
        if (zr == Z_STREAM_ERROR) { ok = false; break; }
        uint32_t n = (uint32_t)(out.size() - zs.avail_out);
        if (n) ok = ok && Chunk(f, "IDAT", out.data(), n);
    }
    deflateEnd(&zs);

    ok = ok && Chunk(f, "IEND", nullptr, 0);
    if (fclose(f) != 0) ok = false;
    if (!ok) remove(path);
    return ok;
}

// ---------------------------------------------------------------------------
// JPEG: baseline, 4:4:4, one quantisation table and one Huffman table pair
// (the standard luminance ones) shared by Y, Cb and Cr. Valid baseline JFIF.
// ---------------------------------------------------------------------------
static const uint8_t kZigZag[64] = {
     0,  1,  8, 16,  9,  2,  3, 10, 17, 24, 32, 25, 18, 11,  4,  5,
    12, 19, 26, 33, 40, 48, 41, 34, 27, 20, 13,  6,  7, 14, 21, 28,
    35, 42, 49, 56, 57, 50, 43, 36, 29, 22, 15, 23, 30, 37, 44, 51,
    58, 59, 52, 45, 38, 31, 39, 46, 53, 60, 61, 54, 47, 55, 62, 63};

static const uint8_t kQLum[64] = {
    16, 11, 10, 16,  24,  40,  51,  61,
    12, 12, 14, 19,  26,  58,  60,  55,
    14, 13, 16, 24,  40,  57,  69,  56,
    14, 17, 22, 29,  51,  87,  80,  62,
    18, 22, 37, 56,  68, 109, 103,  77,
    24, 35, 55, 64,  81, 104, 113,  92,
    49, 64, 78, 87, 103, 121, 120, 101,
    72, 92, 95, 98, 112, 100, 103,  99};

static const uint8_t kDcBits[16] = {0, 1, 5, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0};
static const uint8_t kDcVals[12] = {0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11};
static const uint8_t kAcBits[16] = {0, 2, 1, 3, 3, 2, 4, 3, 5, 5, 4, 4, 0, 0, 1, 0x7d};
static const uint8_t kAcVals[162] = {
    0x01, 0x02, 0x03, 0x00, 0x04, 0x11, 0x05, 0x12, 0x21, 0x31, 0x41, 0x06, 0x13, 0x51, 0x61, 0x07,
    0x22, 0x71, 0x14, 0x32, 0x81, 0x91, 0xa1, 0x08, 0x23, 0x42, 0xb1, 0xc1, 0x15, 0x52, 0xd1, 0xf0,
    0x24, 0x33, 0x62, 0x72, 0x82, 0x09, 0x0a, 0x16, 0x17, 0x18, 0x19, 0x1a, 0x25, 0x26, 0x27, 0x28,
    0x29, 0x2a, 0x34, 0x35, 0x36, 0x37, 0x38, 0x39, 0x3a, 0x43, 0x44, 0x45, 0x46, 0x47, 0x48, 0x49,
    0x4a, 0x53, 0x54, 0x55, 0x56, 0x57, 0x58, 0x59, 0x5a, 0x63, 0x64, 0x65, 0x66, 0x67, 0x68, 0x69,
    0x6a, 0x73, 0x74, 0x75, 0x76, 0x77, 0x78, 0x79, 0x7a, 0x83, 0x84, 0x85, 0x86, 0x87, 0x88, 0x89,
    0x8a, 0x92, 0x93, 0x94, 0x95, 0x96, 0x97, 0x98, 0x99, 0x9a, 0xa2, 0xa3, 0xa4, 0xa5, 0xa6, 0xa7,
    0xa8, 0xa9, 0xaa, 0xb2, 0xb3, 0xb4, 0xb5, 0xb6, 0xb7, 0xb8, 0xb9, 0xba, 0xc2, 0xc3, 0xc4, 0xc5,
    0xc6, 0xc7, 0xc8, 0xc9, 0xca, 0xd2, 0xd3, 0xd4, 0xd5, 0xd6, 0xd7, 0xd8, 0xd9, 0xda, 0xe1, 0xe2,
    0xe3, 0xe4, 0xe5, 0xe6, 0xe7, 0xe8, 0xe9, 0xea, 0xf1, 0xf2, 0xf3, 0xf4, 0xf5, 0xf6, 0xf7, 0xf8,
    0xf9, 0xfa};

struct Huff { uint16_t code[256]; uint8_t len[256]; };

static void BuildHuff(Huff& h, const uint8_t* bits, const uint8_t* vals)
{
    memset(&h, 0, sizeof(h));
    int code = 0, k = 0;
    for (int l = 1; l <= 16; l++) {
        for (int i = 0; i < bits[l - 1]; i++) {
            h.code[vals[k]] = (uint16_t)code;
            h.len[vals[k]] = (uint8_t)l;
            code++;
            k++;
        }
        code <<= 1;
    }
}

struct BitWriter {
    FILE* f;
    uint32_t acc = 0;
    int n = 0;
    bool ok = true;
    explicit BitWriter(FILE* f_) : f(f_) {}
    void Byte(uint8_t b)
    {
        if (fputc(b, f) == EOF) ok = false;
        if (b == 0xFF) { if (fputc(0, f) == EOF) ok = false; }
    }
    void Put(uint32_t bits, int len)
    {
        if (!len) return;
        acc = (acc << len) | (bits & ((1u << len) - 1));
        n += len;
        while (n >= 8) {
            Byte((uint8_t)(acc >> (n - 8)));
            n -= 8;
        }
        acc &= (1u << n) - 1;
    }
    void Flush()
    {
        if (n > 0) Put(0x7F, 8 - n);   // pad with 1s
    }
};

static inline int BitLen(int v)
{
    int a = v < 0 ? -v : v, l = 0;
    while (a) { l++; a >>= 1; }
    return l;
}

static void W16(FILE* f, int v) { fputc(v >> 8, f); fputc(v & 0xFF, f); }

bool WriteJPG(const char* path, const uint8_t* rgba, int sw, int sh, int ow, int oh, int quality)
{
    if (!path || !rgba || sw <= 0 || sh <= 0 || ow <= 0 || oh <= 0) return false;
    if (quality < 1) quality = 1;
    if (quality > 100) quality = 100;

    FILE* f = fopen(path, "wb");
    if (!f) return false;

    int scale = quality < 50 ? 5000 / quality : 200 - quality * 2;
    uint8_t qt[64];       // natural order
    for (int i = 0; i < 64; i++) {
        int q = (kQLum[i] * scale + 50) / 100;
        qt[i] = (uint8_t)(q < 1 ? 1 : (q > 255 ? 255 : q));
    }

    // ---- headers
    fputc(0xFF, f); fputc(0xD8, f);                                    // SOI
    static const uint8_t jfif[] = {0xFF, 0xE0, 0, 16, 'J', 'F', 'I', 'F', 0, 1, 1, 0, 0, 1, 0, 1, 0, 0};
    fwrite(jfif, 1, sizeof(jfif), f);
    fputc(0xFF, f); fputc(0xDB, f); W16(f, 67); fputc(0, f);           // DQT id 0
    for (int i = 0; i < 64; i++) fputc(qt[kZigZag[i]], f);
    fputc(0xFF, f); fputc(0xC0, f); W16(f, 17); fputc(8, f);           // SOF0
    W16(f, oh); W16(f, ow); fputc(3, f);
    for (int c = 1; c <= 3; c++) { fputc(c, f); fputc(0x11, f); fputc(0, f); }
    fputc(0xFF, f); fputc(0xC4, f); W16(f, 2 + 17 + 12);               // DHT DC id 0
    fputc(0x00, f); fwrite(kDcBits, 1, 16, f); fwrite(kDcVals, 1, 12, f);
    fputc(0xFF, f); fputc(0xC4, f); W16(f, 2 + 17 + 162);              // DHT AC id 0
    fputc(0x10, f); fwrite(kAcBits, 1, 16, f); fwrite(kAcVals, 1, 162, f);
    fputc(0xFF, f); fputc(0xDA, f); W16(f, 12); fputc(3, f);           // SOS
    for (int c = 1; c <= 3; c++) { fputc(c, f); fputc(0x00, f); }
    fputc(0, f); fputc(63, f); fputc(0, f);

    Huff dc, ac;
    BuildHuff(dc, kDcBits, kDcVals);
    BuildHuff(ac, kAcBits, kAcVals);

    // DCT basis: T[u][x] = 0.5 * C(u) * cos((2x+1) u pi / 16)
    float T[8][8];
    for (int u = 0; u < 8; u++)
        for (int x = 0; x < 8; x++)
            T[u][x] = 0.5f * (u == 0 ? 0.70710678f : 1.0f) * cosf((2 * x + 1) * u * 3.14159265f / 16.0f);

    RowSource rs(rgba, sw, sh, ow, oh);
    BitWriter bw(f);
    std::vector<uint8_t> rgb((size_t)8 * ow * 3);
    int pred[3] = {0, 0, 0};

    for (int by = 0; by < oh; by += 8) {
        for (int r = 0; r < 8; r++) {
            int y = by + r;
            if (y >= oh) y = oh - 1;   // replicate the last row
            rs.Row(y, &rgb[(size_t)r * ow * 3]);
        }
        for (int bx = 0; bx < ow; bx += 8) {
            float comp[3][64];
            for (int r = 0; r < 8; r++) {
                for (int c = 0; c < 8; c++) {
                    int x = bx + c;
                    if (x >= ow) x = ow - 1;   // replicate the last column
                    const uint8_t* p = &rgb[((size_t)r * ow + x) * 3];
                    float R = p[0], G = p[1], B = p[2];
                    comp[0][r * 8 + c] = 0.299f * R + 0.587f * G + 0.114f * B - 128.0f;
                    comp[1][r * 8 + c] = -0.168736f * R - 0.331264f * G + 0.5f * B;
                    comp[2][r * 8 + c] = 0.5f * R - 0.418688f * G - 0.081312f * B;
                }
            }
            for (int ci = 0; ci < 3; ci++) {
                const float* in = comp[ci];
                float tmp[64], F[64];
                // rows: tmp[r][u] = sum_x in[r][x] * T[u][x]
                for (int r = 0; r < 8; r++)
                    for (int u = 0; u < 8; u++) {
                        float s = 0;
                        for (int x = 0; x < 8; x++) s += in[r * 8 + x] * T[u][x];
                        tmp[r * 8 + u] = s;
                    }
                // cols: F[v][u] = sum_r tmp[r][u] * T[v][r]
                for (int v = 0; v < 8; v++)
                    for (int u = 0; u < 8; u++) {
                        float s = 0;
                        for (int r = 0; r < 8; r++) s += tmp[r * 8 + u] * T[v][r];
                        F[v * 8 + u] = s;
                    }
                int q[64];
                for (int i = 0; i < 64; i++) {
                    int idx = kZigZag[i];
                    float v = F[idx] / (float)qt[idx];
                    q[i] = (int)(v < 0 ? v - 0.5f : v + 0.5f);
                }
                // DC
                int diff = q[0] - pred[ci];
                pred[ci] = q[0];
                int nb = BitLen(diff);
                bw.Put(dc.code[nb], dc.len[nb]);
                if (nb) bw.Put((uint32_t)(diff < 0 ? diff - 1 : diff), nb);
                // AC
                int run = 0;
                for (int i = 1; i < 64; i++) {
                    if (q[i] == 0) { run++; continue; }
                    while (run > 15) { bw.Put(ac.code[0xF0], ac.len[0xF0]); run -= 16; }
                    int n2 = BitLen(q[i]);
                    int sym = (run << 4) | n2;
                    bw.Put(ac.code[sym], ac.len[sym]);
                    bw.Put((uint32_t)(q[i] < 0 ? q[i] - 1 : q[i]), n2);
                    run = 0;
                }
                if (run) bw.Put(ac.code[0x00], ac.len[0x00]);   // EOB
            }
        }
    }
    bw.Flush();
    fputc(0xFF, f); fputc(0xD9, f);                                    // EOI
    bool ok = bw.ok;
    if (fclose(f) != 0) ok = false;
    if (!ok) remove(path);
    return ok;
}

// ---------------------------------------------------------------------------
// RGBA -> YUV420 for MediaCodec
// ---------------------------------------------------------------------------
void RgbaToYuv420(const uint8_t* rgba, int sw, int sh, uint8_t* dst, int ow, int oh, bool nv12)
{
    std::vector<int> xmap(ow);
    for (int x = 0; x < ow; x++) xmap[x] = (int)((int64_t)x * sw / ow) * 4;

    uint8_t* yp = dst;
    uint8_t* up = dst + (size_t)ow * oh;
    uint8_t* vp = up + (size_t)(ow / 2) * (oh / 2);

    for (int oy = 0; oy < oh; oy++) {
        int sy = sh - 1 - (int)((int64_t)oy * sh / oh);
        const uint8_t* row = rgba + (size_t)sy * sw * 4;
        uint8_t* yr = yp + (size_t)oy * ow;
        bool chroma = (oy & 1) == 0;
        for (int ox = 0; ox < ow; ox++) {
            const uint8_t* p = row + xmap[ox];
            int r = p[0], gg = p[1], b = p[2];
            yr[ox] = (uint8_t)(((66 * r + 129 * gg + 25 * b + 128) >> 8) + 16);
            if (chroma && (ox & 1) == 0) {
                int u = ((-38 * r - 74 * gg + 112 * b + 128) >> 8) + 128;
                int v = ((112 * r - 94 * gg - 18 * b + 128) >> 8) + 128;
                if (u < 0) u = 0; else if (u > 255) u = 255;
                if (v < 0) v = 0; else if (v > 255) v = 255;
                int cy = oy / 2, cx = ox / 2;
                if (nv12) {
                    uint8_t* uv = up + (size_t)cy * ow + cx * 2;
                    uv[0] = (uint8_t)u;
                    uv[1] = (uint8_t)v;
                } else {
                    up[(size_t)cy * (ow / 2) + cx] = (uint8_t)u;
                    vp[(size_t)cy * (ow / 2) + cx] = (uint8_t)v;
                }
            }
        }
    }
}

}
}
