# HEXED Capture – investigation notes (Nezuko SA-MP)

## APK facts (SA-MP Nezuko v1.0.3 TESTING)

- ABI: **armeabi-v7a only**
- Relevant native libraries:
  - `libAML.so`
  - `libGTASA.so` (main game + RenderWare)
  - `libNezukoSA-MP.so`
  - `libmonetloader.so` + `libluajit-5.1.so` (Lua visual mods live here)
  - `libsamp.so`, Dobby, etc.
- Present-path strings found in `libGTASA.so`:
  - `OS_ScreenSwapBuffers`
  - `RQ_Command_rqSwapBuffers`
  - `emu_glReadPixels`
  - full set of `gl*Framebuffer*` and `RwCamera*` symbols

## Capture strategy

1. Hook one (or more) of:
   - `OS_ScreenSwapBuffers`
   - `RQ_Command_rqSwapBuffers`
   - `eglSwapBuffers` (fallback, always available)
2. At the moment of the hook the default framebuffer should contain the finished frame, **including** any draws performed by MonetLoader / ImGui / Lua visual scripts that target the same FBO.
3. `glReadPixels` → RGBA buffer.
4. Screenshot → raw RGBA dump (or PNG once a deflate path is added).
5. Recording → background thread, RGB→NV12, `AMediaCodec` (video/avc) + `AMediaMuxer` (MPEG-4).

## Lua visual-mod selection (not yet implemented)

MonetLoader keeps a list of loaded scripts and their draw callbacks.  
To implement “Individual Lua visual mod selection”:

1. Locate the script registry / draw-list inside `libmonetloader.so` (or the Lua state).
2. Expose a toggle per script that temporarily disables its `onDraw` / ImGui window for the duration of a capture, **or**
3. Capture *after* the selected subset has drawn and *before* the deselected ones (requires ordering control that may not exist).

Until that RE is done the plugin always captures whatever is currently on screen (the “include all Lua visuals that are already drawing” behaviour).

## Independence

- Own GUID: `net.hexed.capture`
- Own config / log / stage files: `hexed_capture.*`
- No calls into HEXED Resolution or any other mod interface.
- Does not touch surface size, padding, or touch paths.

## Next RE steps on device

1. Confirm which of the three present hooks actually fires every frame (`adb logcat -s HEXED_Capture`).
2. Confirm `glReadPixels` of the default framebuffer returns the final image (not a previous pass or a cleared buffer).
3. Measure FPS impact of a 30 fps, 720p, 8 Mbps encode path.
4. Locate MonetLoader’s script list for the visual-mod UI.
5. Replace the raw screenshot dump with a real PNG/JPEG writer (stb_image_write or Android `Bitmap.compress`).
6. Consider an FBO / PBO / ImageReader path to reduce the copy cost.
