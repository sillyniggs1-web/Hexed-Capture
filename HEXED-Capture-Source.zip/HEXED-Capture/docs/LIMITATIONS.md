# HEXED Capture 0.2.0 – status

## Working in this build (needs device confirmation of pixel path)

- AML load, safe-stage, file logging, config
- Present hooks: OS_ScreenSwapBuffers / RQ_SwapBuffers / eglSwapBuffers
- glReadPixels capture of current framebuffer
- PNG screenshots via stb_image_write (JPEG fallback)
- H.264 recording via MediaCodec + MediaMuxer (CPU RGB→NV12)
- Start / Pause / Resume / Stop
- FPS / bitrate / optional capture size
- Custom output dirs under game files/
- Full mimgui Lua menu (`/hxdcap` / `/hxd`) with FFI into native exports
- Chat commands + in-game Capture / Settings / Status tabs

## Still limited / device-dependent

- Present hook may need confirmation on your exact Nezuko build
- FPS cost of glReadPixels + CPU colour convert can be high
- Lua visual-mod per-script selection not implemented (captures whatever is on screen)
- Audio track in MP4 not implemented
- Some devices may reject NV12 colour format 21 – try logcat if encode fails

## Install

1. libHEXED_Capture.so → AML mods
2. lua/hexed_capture.lua → MonetLoader scripts
3. adb logcat -s HEXED_Capture
4. /hxdcap
