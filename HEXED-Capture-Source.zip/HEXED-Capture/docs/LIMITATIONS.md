# HEXED Capture 0.1.0 – status and limitations

## What this build is

A **compilable, correctly structured, standalone AML plugin skeleton** aimed at Nezuko SA-MP (armeabi-v7a).  
It follows the same engineering patterns as HEXED Resolution (safe stage, file logging, config, independent GUID, ndk-build + GitHub Actions).

It is **not** a finished, device-verified product.

## Verified by static analysis of the supplied APK

- Presence of `OS_ScreenSwapBuffers`, `RQ_Command_rqSwapBuffers`, `emu_glReadPixels`, EGL/GLES framebuffer symbols.
- MonetLoader + LuaJIT + ImGui are present.
- AML 1.4-style headers and load order are the same as the Resolution project.

## Implemented in source (compiles, needs device proof)

| Area | Status |
|------|--------|
| AML mod declaration, config, logging | Done |
| Safe-stage crash guard | Done (same design as Resolution) |
| Hook installation for present path | Done (symbol + egl fallback) |
| `glReadPixels` capture path | Done (skeleton) |
| Screenshot to `.raw` dump | Done (PNG path is placeholder – needs zlib) |
| MediaCodec + MediaMuxer H.264 recorder | Done (skeleton, RGB→NV12 on CPU) |
| Start / Pause / Resume / Stop | Done |
| Configurable FPS, bitrate, capture size | Done |
| Custom output directories | Done |
| Exported C API for Lua / FFI | Done |
| MonetLoader Lua menu shell | Done (chat commands; full ImGui UI pending) |
| Individual Lua visual-mod selection | **Not implemented** – requires MonetLoader RE |
| Select All / Deselect All for visuals | **Not implemented** |
| Separate screenshot vs recording visual profiles | **Not implemented** |
| Native AML in-game menu (beyond exports) | Minimal – primary UI is Lua |
| Zero-copy / GPU encode path | **Not implemented** |
| Exclusion of Android system overlays | Relies on capturing the game’s own surface only |

## Known risks (from Resolution experience on the same client)

- Present-hook may not be the final pass on every frame; some builds composite later.
- `glReadPixels` can stall the GPU; expect measurable FPS cost until a PBO / ImageReader path is added.
- MediaCodec colour-format acceptance varies by device; NV12 (colour format 21) is the most common but not universal.
- 32-bit pointer arithmetic bugs already bit Resolution once – the scan helpers here avoid the wrap that caused it.
- A crash during the first 12 s will lower the stage for the next launch.

## Beta-testing instructions (once a `.so` is built)

1. Copy `libHEXED_Capture.so` into the AML mods folder of the Nezuko client.
2. Copy `lua/hexed_capture.lua` into the MonetLoader scripts folder.
3. `adb logcat -s HEXED_Capture`
4. Expect lines: `hooked …`, `Ready. stage=3`
5. In game: `/hxdcap shot`, `/hxdcap rec`, `/hxdcap stop`
6. Check `Android/data/<package>/files/HEXED_Screenshots` and `HEXED_Recordings`
7. If the game fails to start, inspect `hexed_capture.log` and `hexed_capture.stage`; delete the stage file to force full mode again.

## What still has to be done on a real device

1. Confirm which present hook fires and that the pixels are the final image.
2. Measure and, if needed, reduce the capture cost.
3. Implement real PNG/JPEG output.
4. Reverse MonetLoader’s visual-mod list for the selection UI.
5. Harden the MediaCodec path (colour format, EOS, orientation, audio track if desired).
