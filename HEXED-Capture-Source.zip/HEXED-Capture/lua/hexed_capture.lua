--[[
  HEXED Capture – MonetLoader / Lua menu
  Place this file in the MonetLoader scripts folder used by Nezuko.

  Commands:
    /hxdcap          – open menu
    /hxdcap shot     – take screenshot
    /hxdcap rec      – start recording
    /hxdcap stop     – stop recording

  The native plugin exports C symbols (HEXED_*) that a future FFI binding
  can call. Until that binding exists this script only provides the UI
  shell and writes requests into a simple command file that the native
  side can poll (or you can extend the natives later).
]]

local SCRIPT_NAME = "HEXED Capture"
local CMD_FILE    = "hexed_capture.cmd"   -- written under the game files dir

local function write_cmd(line)
    -- MonetLoader usually exposes getWorkingDirectory or similar.
    -- We try a few common locations; the native side also watches its own log.
    local paths = {
        getWorkingDirectory and (getWorkingDirectory() .. "/" .. CMD_FILE),
        "hexed_capture.cmd",
    }
    for _, p in ipairs(paths) do
        if p then
            local f = io.open(p, "w")
            if f then
                f:write(line .. "\n")
                f:close()
                return true
            end
        end
    end
    return false
end

local menu = {
    open = false,
    tab  = 1,          -- 1=Capture 2=Settings 3=Status
    fps  = 30,
    bitrate = 8000,
}

function main()
    if not isSampLoaded or not isSampLoaded() then
        wait(1000)
    end
    if isSampAvailable and not isSampAvailable() then
        wait(1000)
    end

    sampRegisterChatCommand("hxdcap", function(arg)
        arg = (arg or ""):lower():match("^%s*(.-)%s*$")
        if arg == "shot" or arg == "screenshot" then
            write_cmd("screenshot")
            sampAddChatMessage("{00FF88}[HEXED] Screenshot requested", -1)
        elseif arg == "rec" or arg == "record" or arg == "start" then
            write_cmd("start")
            sampAddChatMessage("{00FF88}[HEXED] Recording start requested", -1)
        elseif arg == "stop" then
            write_cmd("stop")
            sampAddChatMessage("{00FF88}[HEXED] Recording stop requested", -1)
        elseif arg == "pause" then
            write_cmd("pause")
        elseif arg == "resume" then
            write_cmd("resume")
        else
            menu.open = not menu.open
            sampAddChatMessage("{00FF88}[HEXED] Menu " .. (menu.open and "opened" or "closed") .. " (UI shell – native binding pending)", -1)
        end
    end)

    sampAddChatMessage("{00FF88}[HEXED Capture] loaded. /hxdcap", -1)

    while true do
        wait(0)
        -- Future: draw ImGui / MoonLoader style menu here once the
        -- MonetLoader UI API for this client is confirmed.
        -- For now the chat commands are the supported interface.
    end
end
