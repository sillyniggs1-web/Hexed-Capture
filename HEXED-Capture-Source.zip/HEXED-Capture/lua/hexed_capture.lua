script_name("Hexed Capture")
script_author("HEXED Studio")
script_version("0.2.1")
require "lib.moonloader"
local imgui = require("mimgui")
local ffi   = require("ffi")
local DPI   = MONET_DPI_SCALE or 1

local H = {
    lib = nil,
    status = "Starting...",
    open = imgui.new.bool(false),
    tab = 1,
    fps = imgui.new.int(30),
    bitrate = imgui.new.int(8000),
    capW = imgui.new.int(0),
    capH = imgui.new.int(0),
    path = "?",
}

local TABS = { "Capture", "Settings", "Status" }

ffi.cdef[[
    int HEXED_Tick();
    int HEXED_IsReady();
    void HEXED_RequestScreenshot();
    int HEXED_StartRecording();
    void HEXED_PauseRecording();
    void HEXED_ResumeRecording();
    void HEXED_StopRecording();
    void HEXED_SetFps(int fps);
    void HEXED_SetBitrate(int kbps);
    void HEXED_SetCaptureSize(int w, int h);
    int HEXED_IsRecording();
    int HEXED_IsPaused();
    int HEXED_GetLastW();
    int HEXED_GetLastH();
    int HEXED_GetFps();
    int HEXED_GetBitrate();
    int HEXED_GetFramesCaptured();
    int HEXED_GetFramesEncoded();
    int HEXED_GetDropped();
    int HEXED_GetRecState();
    int HEXED_GetPresentCount();
    int HEXED_GetPresentSized();
    int HEXED_GetScreenshotsSaved();
    int HEXED_GetLastGlError();
    const char* HEXED_GetStatus();
    const char* HEXED_GetError();
]]

local function findLib()
    local ok, f = pcall(io.open, "/proc/self/maps", "r")
    if ok and f then
        for line in f:lines() do
            local p = line:match("(/%S*libHEXED_Capture%.so)")
            if p then
                f:close()
                local ok2, l = pcall(ffi.load, p)
                if ok2 then return l, p end
            end
        end
        f:close()
    end
    local ok3, l = pcall(ffi.load, "libHEXED_Capture.so")
    if ok3 then return l, "libHEXED_Capture.so" end
end

local function ready()
    if not H.lib then
        H.status = "Native mod not loaded (is libHEXED_Capture.so in AML mods?)"
        return false
    end
    return true
end

local function refreshStatus()
    if not H.lib then return end
    local ok, s = pcall(function() return ffi.string(H.lib.HEXED_GetStatus()) end)
    if ok and s and #s > 0 then H.status = s end
end

local function recLabel()
    if not H.lib then return "Idle" end
    local st = H.lib.HEXED_GetRecState()
    if st == 1 then return "RECORDING" end
    if st == 2 then return "PAUSED" end
    if st == 3 then return "Stopping..." end
    return "Idle"
end

imgui.OnInitialize(function()
    local s = imgui.GetStyle()
    local c = s.Colors
    s.WindowRounding = 10
    s.FrameRounding = 6
    s.ChildRounding = 8
    s.WindowBorderSize = 1
    c[imgui.Col.WindowBg]      = imgui.ImVec4(0.02, 0.03, 0.07, 0.96)
    c[imgui.Col.ChildBg]       = imgui.ImVec4(0.03, 0.05, 0.11, 1.00)
    c[imgui.Col.Border]        = imgui.ImVec4(0.10, 0.55, 0.35, 1.00)
    c[imgui.Col.FrameBg]       = imgui.ImVec4(0.05, 0.08, 0.18, 1.00)
    c[imgui.Col.Button]        = imgui.ImVec4(0.08, 0.45, 0.30, 1.00)
    c[imgui.Col.ButtonHovered] = imgui.ImVec4(0.12, 0.60, 0.40, 1.00)
    c[imgui.Col.ButtonActive]  = imgui.ImVec4(0.06, 0.35, 0.22, 1.00)
    c[imgui.Col.SliderGrab]    = imgui.ImVec4(0.15, 0.75, 0.45, 1.00)
    c[imgui.Col.Header]        = imgui.ImVec4(0.08, 0.40, 0.28, 1.00)
    c[imgui.Col.HeaderHovered] = imgui.ImVec4(0.12, 0.55, 0.38, 1.00)
end)

local function tabCapture()
    imgui.Text(("State: %s"):format(recLabel()))
    imgui.Separator()
    if imgui.Button("Screenshot", imgui.ImVec2(-1, 36 * DPI)) and ready() then
        H.lib.HEXED_RequestScreenshot()
        H.status = "Screenshot requested"
        sampAddChatMessage("{00FF88}[HEXED] Screenshot requested", -1)
    end
    imgui.Spacing()
    if not H.lib or H.lib.HEXED_IsRecording() == 0 then
        if imgui.Button("Start Recording", imgui.ImVec2(-1, 36 * DPI)) and ready() then
            if H.lib.HEXED_StartRecording() == 1 then
                H.status = "Recording started"
                sampAddChatMessage("{00FF88}[HEXED] Recording started", -1)
            else
                H.status = "Start failed (see logcat)"
            end
        end
    else
        if H.lib.HEXED_IsPaused() == 1 then
            if imgui.Button("Resume", imgui.ImVec2(-1, 36 * DPI)) then
                H.lib.HEXED_ResumeRecording()
                H.status = "Resumed"
            end
        else
            if imgui.Button("Pause", imgui.ImVec2(-1, 36 * DPI)) then
                H.lib.HEXED_PauseRecording()
                H.status = "Paused"
            end
        end
        imgui.Spacing()
        if imgui.Button("Stop Recording", imgui.ImVec2(-1, 36 * DPI)) then
            H.lib.HEXED_StopRecording()
            H.status = "Stopped"
            sampAddChatMessage("{00FF88}[HEXED] Recording stopped", -1)
        end
    end
end

local function tabSettings()
    imgui.Text("Target FPS")
    if imgui.SliderInt("##fps", H.fps, 5, 60) and ready() then
        H.lib.HEXED_SetFps(H.fps[0])
    end
    imgui.Text("Bitrate (kbps)")
    if imgui.SliderInt("##br", H.bitrate, 1000, 20000) and ready() then
        H.lib.HEXED_SetBitrate(H.bitrate[0])
    end
    imgui.Text("Capture size (0 = native)")
    imgui.PushItemWidth(120 * DPI)
    imgui.InputInt("W##cw", H.capW)
    imgui.SameLine()
    imgui.InputInt("H##ch", H.capH)
    imgui.PopItemWidth()
    if imgui.Button("Apply size", imgui.ImVec2(-1, 28 * DPI)) and ready() then
        H.lib.HEXED_SetCaptureSize(H.capW[0], H.capH[0])
        H.status = ("Capture size %dx%d"):format(H.capW[0], H.capH[0])
    end
    imgui.Spacing()
    imgui.TextWrapped("Screenshots and recordings are written under the game files dir: HEXED_Screenshots / HEXED_Recordings")
end

local function tabStatus()
    refreshStatus()
    if H.lib then
        imgui.Text(("Present hooks: %d"):format(H.lib.HEXED_GetPresentCount()))
        imgui.Text(("Present w/ size: %d"):format(H.lib.HEXED_GetPresentSized()))
        imgui.Text(("Last size: %d x %d"):format(H.lib.HEXED_GetLastW(), H.lib.HEXED_GetLastH()))
        imgui.Text(("Screenshots saved: %d"):format(H.lib.HEXED_GetScreenshotsSaved()))
        imgui.Text(("GL error: 0x%x"):format(H.lib.HEXED_GetLastGlError()))
        imgui.Text(("Captured frames: %d"):format(H.lib.HEXED_GetFramesCaptured()))
        imgui.Text(("Encoded: %d  Dropped: %d"):format(H.lib.HEXED_GetFramesEncoded(), H.lib.HEXED_GetDropped()))
        imgui.Text(("Lib: %s"):format(H.path or "?"))
        if H.lib.HEXED_GetPresentCount() == 0 then
            imgui.TextColored(imgui.ImVec4(1, 0.4, 0.2, 1), "No present hooks firing - capture inactive")
        end
    else
        imgui.TextColored(imgui.ImVec4(1, 0.3, 0.3, 1), "Native library not loaded")
        imgui.TextWrapped("Copy libHEXED_Capture.so into the AML mods folder and restart.")
    end
    imgui.Separator()
    imgui.TextWrapped(H.status or "")
end

imgui.OnFrame(function() return H.open[0] end,
function()
    local size = imgui.ImVec2(340 * DPI, 420 * DPI)
    imgui.SetNextWindowPos(imgui.ImVec2(80 * DPI, 120 * DPI), imgui.Cond.FirstUseEver)
    imgui.SetNextWindowSize(size, imgui.Cond.FirstUseEver)
    if imgui.Begin("HEXED Capture", H.open, imgui.WindowFlags.NoCollapse) then
        if imgui.BeginTabBar("##tabs") then
            for i, name in ipairs(TABS) do
                if imgui.BeginTabItem(name) then
                    H.tab = i
                    if i == 1 then tabCapture()
                    elseif i == 2 then tabSettings()
                    else tabStatus() end
                    imgui.EndTabItem()
                end
            end
            imgui.EndTabBar()
        end
    end
    imgui.End()
end)

local function handleCmd(arg)
    arg = (arg or ""):lower():match("^%s*(.-)%s*$") or ""
    if arg == "shot" or arg == "screenshot" or arg == "ss" then
        if ready() then
            H.lib.HEXED_RequestScreenshot()
            sampAddChatMessage("{00FF88}[HEXED] Screenshot requested", -1)
        else
            sampAddChatMessage("{FF5555}[HEXED] " .. H.status, -1)
        end
    elseif arg == "rec" or arg == "record" or arg == "start" then
        if ready() and H.lib.HEXED_StartRecording() == 1 then
            sampAddChatMessage("{00FF88}[HEXED] Recording started", -1)
        else
            sampAddChatMessage("{FF5555}[HEXED] Start failed / native missing", -1)
        end
    elseif arg == "stop" then
        if ready() then H.lib.HEXED_StopRecording() end
        sampAddChatMessage("{00FF88}[HEXED] Recording stopped", -1)
    elseif arg == "pause" then
        if ready() then H.lib.HEXED_PauseRecording() end
    elseif arg == "resume" then
        if ready() then H.lib.HEXED_ResumeRecording() end
    else
        H.open[0] = not H.open[0]
        sampAddChatMessage("{00FF88}[HEXED] Menu " .. (H.open[0] and "opened" or "closed"), -1)
    end
end

function main()
    while not isSampAvailable or not isSampAvailable() do wait(100) end

    H.lib, H.path = findLib()
    if H.lib then
        H.status = "Native linked: " .. tostring(H.path)
        pcall(function()
            H.fps[0] = H.lib.HEXED_GetFps()
            H.bitrate[0] = H.lib.HEXED_GetBitrate()
        end)
        sampAddChatMessage("{00FF88}[HEXED Capture] loaded (native OK). /hxdcap", -1)
    else
        H.status = "Native mod not loaded"
        sampAddChatMessage("{FF5555}[HEXED Capture] Lua OK, but native .so not found. /hxdcap", -1)
    end

    sampRegisterChatCommand("hxdcap", handleCmd)
    sampRegisterChatCommand("hxd", handleCmd)

    while true do
        wait(500)
        if H.lib then refreshStatus() end
    end
end
