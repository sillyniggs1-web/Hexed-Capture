# HEXED Capture 0.2.0

Standalone native **AML** plugin for **GTA SA-MP Nezuko Android** that provides:

- Native gameplay screenshots
- Native gameplay screen recording (H.264 / MP4)
- Start / Pause / Resume / Stop
- Configurable FPS, bitrate and capture resolution
- Custom storage paths
- Safe-stage crash guard and file logging

**Status:** compilable skeleton based on static analysis of the supplied Nezuko APK and the same engineering patterns as HEXED Resolution.  
**Not yet device-verified.** See `docs/LIMITATIONS.md`.

## Target

| Item | Value |
|------|--------|
| Client | SA-MP Nezuko (TESTING builds) |
| ABI | armeabi-v7a (32-bit) |
| Mod loader | AML (Android Mod Loader) |
| Language | C++17, NDK |
| Output | `libHEXED_Capture.so` |

## Build

### ndk-build (recommended, matches GitHub Actions)

```bash
export ANDROID_NDK_HOME=/path/to/ndk-r26d
ndk-build -C jni NDK_LIBS_OUT=./libs NDK_OUT=./obj
```

Result: `libs/armeabi-v7a/libHEXED_Capture.so`

### CMake (optional)

```bash
cmake -S . -B build \
  -DCMAKE_TOOLCHAIN_FILE=$ANDROID_NDK_HOME/build/cmake/android.toolchain.cmake \
  -DANDROID_ABI=armeabi-v7a \
  -DANDROID_PLATFORM=android-21 \
  -DANDROID_STL=c++_static \
  -DCMAKE_BUILD_TYPE=Release
cmake --build build -j
```

### GitHub Actions

Push a source ZIP to the repo root (or run the workflow manually). Same ZIP→SO flow as HEXED Resolution: extract, ndk-build, validate symbols, upload artifact + build log.

## Install

1. `libHEXED_Capture.so` → AML mods folder  
   (typically `Android/data/<package>/mods/` or the unprotected equivalent)
2. `lua/hexed_capture.lua` → MonetLoader scripts folder
3. `adb logcat -s HEXED_Capture`

You should see:

```
hooked OS_ScreenSwapBuffers / eglSwapBuffers …
Ready. stage=3
```

## Usage (chat commands)

| Command | Action |
|---------|--------|
| `/hxdcap` | Toggle menu shell (UI pending full ImGui binding) |
| `/hxdcap shot` | Request one screenshot |
| `/hxdcap rec` | Start recording |
| `/hxdcap stop` | Stop recording |
| `/hxdcap pause` / `resume` | Pause / resume |

Output goes to:

- `…/files/HEXED_Screenshots/`
- `…/files/HEXED_Recordings/`

Config / logs:

- `hexed_capture.cfg`
- `hexed_capture.log`
- `hexed_capture.stage` (safe-mode level)

## Independence

- Own GUID: `net.hexed.capture`
- Does **not** depend on, call into, or share state with HEXED Resolution or any other AML mod.
- Does not alter surface size, padding, or touch handling.

## What is still TODO (see docs/)

- Confirm present-hook + `glReadPixels` quality on device
- Real PNG/JPEG writer (current screenshot path writes a raw dump)
- MonetLoader visual-mod enumeration + per-mod enable/disable
- Separate screenshot / recording visual profiles
- Lower-overhead capture (PBO / ImageReader / GPU path)
- Full native / ImGui menu

## License / authorship

HEXED – internal beta. Headers under `mod/` come from the AndroidModLoader project (see their license).
