LOCAL_PATH := $(call my-dir)

include $(CLEAR_VARS)
LOCAL_MODULE            := HEXED_Capture
LOCAL_SRC_FILES         := ../src/main.cpp \
                           ../src/capture.cpp \
                           ../src/recorder.cpp \
                           ../src/natives.cpp \
                           ../src/ui.cpp \
                           ../src/hlog.cpp \
                           ../mod/logger.cpp \
                           ../mod/config.cpp

LOCAL_C_INCLUDES        += $(LOCAL_PATH)/..
LOCAL_C_INCLUDES        += $(LOCAL_PATH)/../mod

# android: ANativeWindow / Surface
# mediandk: MediaCodec / MediaMuxer (API 21+)
# EGL / GLESv2 for framebuffer readback
LOCAL_LDLIBS            := -llog -ldl -landroid -lmediandk -lEGL -lGLESv2
LOCAL_CFLAGS            += -O2 -fvisibility=hidden -DNDEBUG -Wno-error=format-security
LOCAL_CPPFLAGS          += -std=c++17 -fvisibility=hidden -fno-exceptions -fno-rtti -DNDEBUG -Wno-error=format-security
LOCAL_ARM_MODE          := arm

include $(BUILD_SHARED_LIBRARY)
