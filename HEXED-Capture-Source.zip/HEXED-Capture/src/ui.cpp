/*
 * Native exports for MonetLoader FFI (same pattern as HEXED Resolution).
 */
#include "capture.h"
#include "state.h"
#include "hlog.h"

#include <mod/amlmod.h>
#include <stdio.h>
#include <string.h>

namespace hexed {
namespace ui {

static char g_status[256] = "Starting...";
static char g_err[128] = "";

void Init()
{
    HLog("ui: Init");
    snprintf(g_status, sizeof(g_status), "Ready");
}

void GetStatus(char* out, size_t n)
{
    int st = g.recState.load();
    const char* s = "Idle";
    if (st == (int)RecState::Recording) s = "Recording";
    else if (st == (int)RecState::Paused) s = "Paused";
    else if (st == (int)RecState::Stopping) s = "Stopping";

    snprintf(out, n,
        "%s | present %d (%dx%d) | saved %d | cap %d | glErr 0x%x",
        s,
        g.presentCount.load(), g.lastPresentW.load(), g.lastPresentH.load(),
        g.screenshotsSaved.load(),
        g.framesCaptured.load(),
        (unsigned)g.lastGlError.load());
    snprintf(g_status, sizeof(g_status), "%s", out);
}

void SetError(const char* e)
{
    snprintf(g_err, sizeof(g_err), "%s", e ? e : "");
}

}
}

extern "C" {

__attribute__((visibility("default")))
int HEXED_Tick()
{
    // 1 once capture is past Init
    return (hexed::g.lastFrameW.load() > 0 || hexed::capture::IsRecording() || true) ? 1 : 0;
}

__attribute__((visibility("default")))
int HEXED_IsReady()
{
    return 1;
}

__attribute__((visibility("default")))
void HEXED_RequestScreenshot()
{
    hexed::capture::RequestScreenshot();
}

__attribute__((visibility("default")))
int HEXED_StartRecording()
{
    return hexed::capture::StartRecording() ? 1 : 0;
}

__attribute__((visibility("default")))
void HEXED_PauseRecording()
{
    hexed::capture::PauseRecording();
}

__attribute__((visibility("default")))
void HEXED_ResumeRecording()
{
    hexed::capture::ResumeRecording();
}

__attribute__((visibility("default")))
void HEXED_StopRecording()
{
    hexed::capture::StopRecording();
}

__attribute__((visibility("default")))
void HEXED_SetFps(int fps)
{
    if (fps < 1) fps = 1;
    if (fps > 60) fps = 60;
    hexed::g.targetFps = fps;
}

__attribute__((visibility("default")))
void HEXED_SetBitrate(int kbps)
{
    if (kbps < 500) kbps = 500;
    if (kbps > 50000) kbps = 50000;
    hexed::g.bitrateKbps = kbps;
}

__attribute__((visibility("default")))
void HEXED_SetCaptureSize(int w, int h)
{
    hexed::g.captureW = w < 0 ? 0 : w;
    hexed::g.captureH = h < 0 ? 0 : h;
}

__attribute__((visibility("default")))
int HEXED_IsRecording()
{
    return hexed::capture::IsRecording() ? 1 : 0;
}

__attribute__((visibility("default")))
int HEXED_IsPaused()
{
    return hexed::capture::IsPaused() ? 1 : 0;
}

__attribute__((visibility("default")))
int HEXED_GetLastW() { return hexed::g.lastFrameW.load(); }

__attribute__((visibility("default")))
int HEXED_GetLastH() { return hexed::g.lastFrameH.load(); }

__attribute__((visibility("default")))
int HEXED_GetFps() { return hexed::g.targetFps.load(); }

__attribute__((visibility("default")))
int HEXED_GetBitrate() { return hexed::g.bitrateKbps.load(); }

__attribute__((visibility("default")))
int HEXED_GetFramesCaptured() { return hexed::g.framesCaptured.load(); }

__attribute__((visibility("default")))
int HEXED_GetFramesEncoded() { return hexed::g.framesEncoded.load(); }

__attribute__((visibility("default")))
int HEXED_GetDropped() { return hexed::g.droppedFrames.load(); }

__attribute__((visibility("default")))
int HEXED_GetRecState() { return hexed::g.recState.load(); }

__attribute__((visibility("default")))
const char* HEXED_GetStatus()
{
    static char buf[256];
    hexed::ui::GetStatus(buf, sizeof(buf));
    return buf;
}

__attribute__((visibility("default")))
const char* HEXED_GetError()
{
    return "";
}

__attribute__((visibility("default")))
void HEXED_GetStatusBuf(char* buf, int buflen)
{
    if (!buf || buflen < 8) return;
    hexed::ui::GetStatus(buf, (size_t)buflen);
}

__attribute__((visibility("default")))
int HEXED_GetPresentCount() { return hexed::g.presentCount.load(); }

__attribute__((visibility("default")))
int HEXED_GetPresentSized() { return hexed::g.presentWithSize.load(); }

__attribute__((visibility("default")))
int HEXED_GetScreenshotsSaved() { return hexed::g.screenshotsSaved.load(); }

__attribute__((visibility("default")))
int HEXED_GetLastGlError() { return hexed::g.lastGlError.load(); }

}
