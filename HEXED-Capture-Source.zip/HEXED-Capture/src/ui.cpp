/*
 * Minimal native status helpers + Lua bridge natives.
 * The real user-facing menu lives in lua/hexed_capture.lua (MonetLoader).
 * Native side only exposes a few SA:MP / CLEO-style natives that the Lua
 * script can call, plus a simple in-game text overlay for diagnostics.
 */
#include "capture.h"
#include "state.h"
#include "hlog.h"

#include <mod/amlmod.h>
#include <stdio.h>
#include <string.h>

namespace hexed {
namespace ui {

// Called from main after everything is ready – can register extra interfaces later
void Init()
{
    HLog("ui: Init (Lua menu is the primary UI)");
}

// Status string for the Lua menu / log
void GetStatus(char* out, size_t n)
{
    int st = g.recState.load();
    const char* s = "Idle";
    if (st == (int)RecState::Recording) s = "Recording";
    else if (st == (int)RecState::Paused) s = "Paused";
    else if (st == (int)RecState::Stopping) s = "Stopping";

    snprintf(out, n,
        "HEXED Capture | %s | frame %dx%d | cap %d enc %d drop %d | fps %d bitrate %d",
        s,
        g.lastFrameW.load(), g.lastFrameH.load(),
        g.framesCaptured.load(), g.framesEncoded.load(), g.droppedFrames.load(),
        g.targetFps.load(), g.bitrateKbps.load());
}

}
}

// ---- simple C API that the Lua script can reach via MonetLoader FFI / natives ----
// These are exported so a future CLEO / AS4AML / MonetLoader binding can call them.
extern "C" {

__attribute__((visibility("default")))
void HEXED_RequestScreenshot()
{
    hexed::capture::RequestScreenshot();
}

__attribute__((visibility("default")))
int HEXED_StartRecording()
{
    return hexed::capture::StartRecording() ? 1 : 0;
}

__attribute__((visibility("default")))
void HEXED_PauseRecording()
{
    hexed::capture::PauseRecording();
}

__attribute__((visibility("default")))
void HEXED_ResumeRecording()
{
    hexed::capture::ResumeRecording();
}

__attribute__((visibility("default")))
void HEXED_StopRecording()
{
    hexed::capture::StopRecording();
}

__attribute__((visibility("default")))
void HEXED_SetFps(int fps)
{
    if (fps < 1) fps = 1;
    if (fps > 60) fps = 60;
    hexed::g.targetFps = fps;
}

__attribute__((visibility("default")))
void HEXED_SetBitrate(int kbps)
{
    if (kbps < 500) kbps = 500;
    if (kbps > 50000) kbps = 50000;
    hexed::g.bitrateKbps = kbps;
}

__attribute__((visibility("default")))
void HEXED_SetCaptureSize(int w, int h)
{
    hexed::g.captureW = w;
    hexed::g.captureH = h;
}

__attribute__((visibility("default")))
int HEXED_IsRecording()
{
    return hexed::capture::IsRecording() ? 1 : 0;
}

__attribute__((visibility("default")))
int HEXED_IsPaused()
{
    return hexed::capture::IsPaused() ? 1 : 0;
}

__attribute__((visibility("default")))
void HEXED_GetStatus(char* buf, int buflen)
{
    if (!buf || buflen < 8) return;
    hexed::ui::GetStatus(buf, (size_t)buflen);
}

}
