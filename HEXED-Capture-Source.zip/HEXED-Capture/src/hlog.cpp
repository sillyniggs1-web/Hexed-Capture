#include "hlog.h"
#include <mod/logger.h>
#include <mod/amlmod.h>
#include <stdio.h>
#include <stdarg.h>
#include <string.h>
#include <unistd.h>
#include <sys/stat.h>
#include <android/log.h>

namespace hexed {

static char g_dataDir[512] = {0};
static bool g_dataDirTried = false;

const char* DataDir()
{
    if (g_dataDirTried) return g_dataDir[0] ? g_dataDir : nullptr;
    g_dataDirTried = true;

    // Prefer AML's Android data path
    if (aml) {
        const char* p = aml->GetAndroidDataPath();
        if (p && p[0]) {
            snprintf(g_dataDir, sizeof(g_dataDir), "%s/files", p);
            mkdir(g_dataDir, 0755);
            return g_dataDir;
        }
        p = aml->GetDataPath();
        if (p && p[0]) {
            snprintf(g_dataDir, sizeof(g_dataDir), "%s", p);
            return g_dataDir;
        }
    }

    // Fallback common locations for Nezuko / GTA SA Android
    const char* candidates[] = {
        "/sdcard/Android/data/com.rockstargames.gtasa/files",
        "/storage/emulated/0/Android/data/com.rockstargames.gtasa/files",
        "/sdcard/Android/data/com.arizona.game/files",
        nullptr
    };
    for (int i = 0; candidates[i]; ++i) {
        if (access(candidates[i], W_OK) == 0) {
            strncpy(g_dataDir, candidates[i], sizeof(g_dataDir) - 1);
            return g_dataDir;
        }
    }
    return nullptr;
}

void HLog(const char* fmt, ...)
{
    char buf[1024];
    va_list ap;
    va_start(ap, fmt);
    vsnprintf(buf, sizeof(buf), fmt, ap);
    va_end(ap);

    __android_log_print(ANDROID_LOG_INFO, "HEXED_Capture", "%s", buf);
    if (logger) logger->Info("%s", buf);

    // Also append to a file so the last line is visible after a crash
    const char* dir = DataDir();
    if (!dir) return;
    char path[600];
    snprintf(path, sizeof(path), "%s/hexed_capture.log", dir);
    FILE* f = fopen(path, "a");
    if (f) {
        fputs(buf, f);
        fputc('\n', f);
        fflush(f);
        fclose(f);
    }
}

}
