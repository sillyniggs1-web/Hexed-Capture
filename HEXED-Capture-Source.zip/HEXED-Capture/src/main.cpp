/*
 * HEXED Capture 0.2.1 – standalone AML screenshot & screen-recorder
 * Target: SA-MP Nezuko (TESTING) armeabi-v7a
 *
 * Completely independent of HEXED Resolution and any other AML mod.
 *
 * See docs/LIMITATIONS.md and docs/NOTES.md for what is verified vs. stubbed.
 */
#include <mod/amlmod.h>
#include <mod/logger.h>
#include <mod/config.h>

#include "hlog.h"
#include "state.h"
#include "capture.h"
#include "recorder.h"
#include "scan.h"

#include <pthread.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <time.h>
#include <sys/stat.h>

MYMODCFG(net.hexed.capture, HEXED Capture, 0.2.1, HEXED)

namespace hexed { Shared g; }
using namespace hexed;

// Forward decls from other TUs
namespace hexed {
namespace natives { bool Install(); }
namespace ui      { void Init(); }
}

// ---------- config ----------
static void LoadConfig()
{
    char path[400];
    const char* dir = DataDir();
    if (!dir) return;
    snprintf(path, sizeof(path), "%s/hexed_capture.cfg", dir);
    FILE* f = fopen(path, "r");
    if (!f) return;
    char tag[16] = {0};
    int fps = 30, br = 8000, qw = 0, qh = 0, jq = 90;
    if (fscanf(f, "%15s %d %d %d %d %d", tag, &fps, &br, &qw, &qh, &jq) >= 3) {
        if (!strcmp(tag, "HXDCAP1")) {
            g.targetFps = fps;
            g.bitrateKbps = br;
            g.captureW = qw;
            g.captureH = qh;
            g.jpegQuality = jq;
            HLog("config loaded: fps=%d br=%d size=%dx%d", fps, br, qw, qh);
        }
    }
    fclose(f);
}

static void SaveConfig()
{
    char path[400];
    const char* dir = DataDir();
    if (!dir) return;
    snprintf(path, sizeof(path), "%s/hexed_capture.cfg", dir);
    FILE* f = fopen(path, "w");
    if (!f) return;
    fprintf(f, "HXDCAP1 %d %d %d %d %d\n",
            g.targetFps.load(), g.bitrateKbps.load(),
            g.captureW.load(), g.captureH.load(),
            g.jpegQuality.load());
    fclose(f);
}

// ---------- safe-stage crash guard (same idea as Resolution) ----------
static int  g_stage = 3;   // 0=none 1=scan only 2=hooks no capture 3=full
static char g_stagePath[400] = {0};

static void LoadStage()
{
    const char* dir = DataDir();
    if (!dir) return;
    snprintf(g_stagePath, sizeof(g_stagePath), "%s/hexed_capture.stage", dir);
    FILE* f = fopen(g_stagePath, "r");
    if (!f) return;
    int s = 3;
    char ver[32] = {0};
    if (fscanf(f, "%31s %d", ver, &s) == 2) {
        if (!strcmp(ver, "0.2.1") && s >= 0 && s <= 3)
            g_stage = s;
    }
    fclose(f);
}

static void SaveStage(int s)
{
    if (!g_stagePath[0]) return;
    FILE* f = fopen(g_stagePath, "w");
    if (f) {
        fprintf(f, "0.2.1 %d\n", s);
        fclose(f);
    }
}

static void* BootGuardThread(void*)
{
    // Wait ~12 s. If we are still alive, clear any pending stage-down.
    struct timespec t0, t;
    clock_gettime(CLOCK_MONOTONIC, &t0);
    for (;;) {
        clock_gettime(CLOCK_MONOTONIC, &t);
        if (t.tv_sec - t0.tv_sec >= 12) break;
        usleep(200 * 1000);
    }
    // Success – restore full stage for next launch
    SaveStage(3);
    HLog("boot guard: survived, stage restored to 3");
    return nullptr;
}

// ---------- entry points ----------
// ---------- Lua cmd file poller (hexed_capture.cmd) ----------
static void* CmdPollThread(void*)
{
    HLog("cmd poller started");
    char path[400] = {0};
    const char* dir = DataDir();
    if (dir)
        snprintf(path, sizeof(path), "%s/hexed_capture.cmd", dir);

    const char* fallbacks[] = {
        path,
        "/sdcard/Android/data/com.rockstargames.gtasa/files/hexed_capture.cmd",
        "/storage/emulated/0/Android/data/com.rockstargames.gtasa/files/hexed_capture.cmd",
        nullptr
    };

    while (true) {
        usleep(250 * 1000);
        for (int i = 0; fallbacks[i]; ++i) {
            const char* pth = fallbacks[i];
            if (!pth || !pth[0]) continue;
            FILE* f = fopen(pth, "r");
            if (!f) continue;
            char line[64] = {0};
            if (fgets(line, sizeof(line), f)) {
                for (char* c = line; *c; ++c)
                    if (*c == '\n' || *c == '\r') *c = 0;
                if (line[0]) {
                    HLog("cmd: %s", line);
                    if (!strcmp(line, "screenshot")) capture::RequestScreenshot();
                    else if (!strcmp(line, "start"))  capture::StartRecording();
                    else if (!strcmp(line, "stop"))   capture::StopRecording();
                    else if (!strcmp(line, "pause"))  capture::PauseRecording();
                    else if (!strcmp(line, "resume")) capture::ResumeRecording();
                }
            }
            fclose(f);
            unlink(pth);
            break;
        }
    }
    return nullptr;
}

ON_MOD_PRELOAD()
{
    logger->SetTag("HEXED_Capture");
    HLog("ON_MOD_PRELOAD");
}

ON_MOD_LOAD()
{
    HLog("ON_MOD_LOAD – HEXED Capture 0.2.1");
    LoadStage();
    HLog("stage = %d", g_stage);

    if (g_stage <= 0) {
        HLog("stage 0 – doing nothing (safe mode)");
        return;
    }

    LoadConfig();

    // Prepare directories early
    const char* base = DataDir();
    if (base) {
        snprintf(g.screenshotDir, sizeof(g.screenshotDir), "%s/HEXED_Screenshots", base);
        snprintf(g.recordingDir,  sizeof(g.recordingDir),  "%s/HEXED_Recordings",  base);
        mkdir(g.screenshotDir, 0755);
        mkdir(g.recordingDir,  0755);
        HLog("screenshot dir: %s", g.screenshotDir);
        HLog("recording  dir: %s", g.recordingDir);
    } else {
        HLog("WARNING: could not resolve data directory");
    }

    if (g_stage >= 1) {
        // Stage 1+: just prove we can see the library
        uintptr_t p = aml->GetLib("libGTASA.so");
        HLog("libGTASA.so = %p", (void*)p);
    }

    if (g_stage >= 2) {
        if (!natives::Install()) {
            HLog("natives::Install failed – staying at reduced functionality");
        }
    }

    if (g_stage >= 3) {
        capture::Init();
        ui::Init();
        // Poll hexed_capture.cmd written by the Lua menu
        {
            pthread_t ct;
            pthread_attr_t ca;
            pthread_attr_init(&ca);
            pthread_attr_setdetachstate(&ca, PTHREAD_CREATE_DETACHED);
            pthread_create(&ct, &ca, CmdPollThread, nullptr);
            pthread_attr_destroy(&ca);
        }
    }

    // Arm boot guard
    pthread_t t;
    pthread_attr_t a;
    pthread_attr_init(&a);
    pthread_attr_setdetachstate(&a, PTHREAD_CREATE_DETACHED);
    pthread_create(&t, &a, BootGuardThread, nullptr);
    pthread_attr_destroy(&a);

    // Write a pending marker; if the process dies before the guard finishes,
    // next launch can decide to drop a stage.
    {
        char path[400];
        const char* dir = DataDir();
        if (dir) {
            snprintf(path, sizeof(path), "%s/hexed_capture.boot", dir);
            FILE* f = fopen(path, "w");
            if (f) { fputs("1\n", f); fclose(f); }
        }
    }

    HLog("Ready. stage=%d  (adb logcat -s HEXED_Capture)", g_stage);
    SaveConfig();
}

ON_MOD_UNLOAD()
{
    HLog("ON_MOD_UNLOAD");
    capture::Shutdown();
    SaveConfig();
}

ON_GAME_CRASH()
{
    // library, sig, code, libaddr, mcontext are provided by the macro
    HLog("ON_GAME_CRASH sig=%d – lowering stage for next launch", sig);
    int next = g_stage > 0 ? g_stage - 1 : 0;
    SaveStage(next);
}
