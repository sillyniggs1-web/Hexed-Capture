#pragma once
#include <atomic>
#include <stdint.h>

namespace hexed {

enum class RecState : int {
    Idle = 0,
    Recording,
    Paused,
    Stopping
};

struct Shared {
    // Capture / record controls (atomics – safe to read from render thread)
    std::atomic<int>  wantScreenshot{0};   // 1 = take one next frame
    std::atomic<int>  recState{(int)RecState::Idle};
    std::atomic<int>  targetFps{30};
    std::atomic<int>  bitrateKbps{8000};
    std::atomic<int>  captureW{0};         // 0 = native
    std::atomic<int>  captureH{0};
    std::atomic<int>  jpegQuality{90};

    // Runtime stats (written by capture thread, read by UI)
    std::atomic<int>  lastFrameW{0};
    std::atomic<int>  lastFrameH{0};
    std::atomic<int>  framesCaptured{0};
    std::atomic<int>  framesEncoded{0};
    std::atomic<int>  droppedFrames{0};

    // Feature flags
    std::atomic<int>  includeLuaVisuals{1};
    std::atomic<int>  excludeSystemOverlay{1};

    // Paths (set once at load, then read-only)
    char screenshotDir[320] = {0};
    char recordingDir[320]  = {0};
};

extern Shared g;

}
