/*
 * MediaCodec + MediaMuxer based H.264 recorder.
 *
 * This is a functional skeleton that compiles against the NDK mediandk headers.
 * On-device behaviour (colour conversion, surface input vs buffer input, exact
 * colour format the GPU produces) still needs verification on Nezuko.
 *
 * Preferred future path once RE is done:
 *   - Create a persistent FBO / texture the game renders into, or
 *   - Use EGLImage / ImageReader for zero-copy into the encoder.
 * For the first beta we accept a colour-conversion cost.
 */
#include "recorder.h"
#include "state.h"
#include "hlog.h"

#include <media/NdkMediaCodec.h>
#include <media/NdkMediaFormat.h>
#include <media/NdkMediaMuxer.h>

#include <pthread.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <time.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <errno.h>
#include <vector>
#include <queue>
#include <atomic>

namespace hexed {
namespace recorder {

struct FrameJob {
    uint8_t* data;
    int w, h, stride;
    int64_t ptsNs;
};

static pthread_mutex_t g_mu   = PTHREAD_MUTEX_INITIALIZER;
static pthread_cond_t  g_cv   = PTHREAD_COND_INITIALIZER;
static pthread_t       g_thr  = 0;
static std::atomic<bool> g_run{false};
static std::atomic<bool> g_active{false};

static AMediaCodec*  g_codec  = nullptr;
static AMediaMuxer*  g_muxer  = nullptr;
static int           g_track  = -1;
static int           g_fd     = -1;
static int           g_fps    = 30;
static int           g_bitrate = 8000000;
static int           g_outW = 0, g_outH = 0;
static char          g_path[512] = {0};

static std::queue<FrameJob> g_queue;
static const size_t MAX_QUEUE = 8;

// Very simple RGB→NV12 conversion (BT.601). Replace with a faster path later.
static void RgbaToNv12(const uint8_t* rgba, int w, int h, int stride,
                       uint8_t* yPlane, uint8_t* uvPlane)
{
    for (int y = 0; y < h; y++) {
        const uint8_t* row = rgba + y * stride;
        uint8_t* yRow = yPlane + y * w;
        for (int x = 0; x < w; x++) {
            int r = row[x*4+0];
            int g = row[x*4+1];
            int b = row[x*4+2];
            yRow[x] = (uint8_t)((66*r + 129*g + 25*b + 128) >> 8) + 16;
        }
    }
    for (int y = 0; y < h; y += 2) {
        const uint8_t* row0 = rgba + y * stride;
        const uint8_t* row1 = rgba + (y+1) * stride;
        uint8_t* uv = uvPlane + (y/2) * w;
        for (int x = 0; x < w; x += 2) {
            int r = (row0[x*4+0] + row0[(x+1)*4+0] + row1[x*4+0] + row1[(x+1)*4+0]) >> 2;
            int g = (row0[x*4+1] + row0[(x+1)*4+1] + row1[x*4+1] + row1[(x+1)*4+1]) >> 2;
            int b = (row0[x*4+2] + row0[(x+1)*4+2] + row1[x*4+2] + row1[(x+1)*4+2]) >> 2;
            int u = ((-38*r - 74*g + 112*b + 128) >> 8) + 128;
            int v = ((112*r - 94*g - 18*b + 128) >> 8) + 128;
            uv[x]   = (uint8_t)u;
            uv[x+1] = (uint8_t)v;
        }
    }
}

static void* EncoderThread(void*)
{
    HLog("encoder thread started");
    while (g_run.load()) {
        FrameJob job = {nullptr, 0, 0, 0, 0};
        {
            pthread_mutex_lock(&g_mu);
            while (g_queue.empty() && g_run.load())
                pthread_cond_wait(&g_cv, &g_mu);
            if (!g_queue.empty()) {
                job = g_queue.front();
                g_queue.pop();
            }
            pthread_mutex_unlock(&g_mu);
        }
        if (!job.data) continue;

        if (g_codec && g_active.load()) {
            // Wait for an input buffer
            ssize_t ix = AMediaCodec_dequeueInputBuffer(g_codec, 5000);
            if (ix >= 0) {
                size_t outSize = 0;
                uint8_t* buf = AMediaCodec_getInputBuffer(g_codec, ix, &outSize);
                if (buf && outSize >= (size_t)(job.w * job.h * 3 / 2)) {
                    // Convert into the input buffer (NV12)
                    RgbaToNv12(job.data, job.w, job.h, job.stride,
                               buf, buf + job.w * job.h);
                    AMediaCodec_queueInputBuffer(g_codec, ix, 0,
                        (size_t)(job.w * job.h * 3 / 2),
                        job.ptsNs / 1000, 0); // us
                } else {
                    AMediaCodec_queueInputBuffer(g_codec, ix, 0, 0, job.ptsNs / 1000, 0);
                }
            }

            // Drain output
            AMediaCodecBufferInfo info;
            for (;;) {
                ssize_t ox = AMediaCodec_dequeueOutputBuffer(g_codec, &info, 0);
                if (ox == AMEDIACODEC_INFO_OUTPUT_FORMAT_CHANGED) {
                    if (g_track < 0 && g_muxer) {
                        AMediaFormat* fmt = AMediaCodec_getOutputFormat(g_codec);
                        g_track = AMediaMuxer_addTrack(g_muxer, fmt);
                        AMediaMuxer_start(g_muxer);
                        AMediaFormat_delete(fmt);
                        HLog("muxer track added (%d)", g_track);
                    }
                } else if (ox >= 0) {
                    size_t outSize = 0;
                    uint8_t* obuf = AMediaCodec_getOutputBuffer(g_codec, ox, &outSize);
                    if (obuf && g_muxer && g_track >= 0 && info.size > 0) {
                        AMediaMuxer_writeSampleData(g_muxer, g_track, obuf, &info);
                        g.framesEncoded.fetch_add(1);
                    }
                    AMediaCodec_releaseOutputBuffer(g_codec, ox, false);
                } else {
                    break;
                }
            }
        }
        free(job.data);
    }
    HLog("encoder thread exit");
    return nullptr;
}

bool Start(const char* dir, int fps, int bitrateKbps, int forceW, int forceH)
{
    if (g_active.load()) return false;
    if (!dir || !dir[0]) return false;
    mkdir(dir, 0755);

    g_fps = fps > 0 ? fps : 30;
    g_bitrate = (bitrateKbps > 0 ? bitrateKbps : 8000) * 1000;
    g_outW = forceW;
    g_outH = forceH;

    time_t t = time(nullptr);
    struct tm tm;
    localtime_r(&t, &tm);
    snprintf(g_path, sizeof(g_path), "%s/HEXED_%04d%02d%02d_%02d%02d%02d.mp4",
             dir, tm.tm_year + 1900, tm.tm_mon + 1, tm.tm_mday,
             tm.tm_hour, tm.tm_min, tm.tm_sec);

    g_fd = open(g_path, O_WRONLY | O_CREAT | O_TRUNC, 0644);
    if (g_fd < 0) {
        HLog("open(%s) failed: %s", g_path, strerror(errno));
        return false;
    }

    g_muxer = AMediaMuxer_new(g_fd, AMEDIAMUXER_OUTPUT_FORMAT_MPEG_4);
    if (!g_muxer) {
        HLog("AMediaMuxer_new failed");
        close(g_fd); g_fd = -1;
        return false;
    }

    // We create the codec lazily on the first real frame so we know the size.
    // For the skeleton we also allow a forced size.
    g_codec = AMediaCodec_createEncoderByType("video/avc");
    if (!g_codec) {
        HLog("AMediaCodec_createEncoderByType(video/avc) failed");
        AMediaMuxer_delete(g_muxer); g_muxer = nullptr;
        close(g_fd); g_fd = -1;
        return false;
    }

    g_track = -1;
    g_run = true;
    g_active = true;
    if (pthread_create(&g_thr, nullptr, EncoderThread, nullptr) != 0) {
        HLog("encoder pthread_create failed");
        AMediaCodec_delete(g_codec); g_codec = nullptr;
        AMediaMuxer_delete(g_muxer); g_muxer = nullptr;
        close(g_fd); g_fd = -1;
        g_active = false;
        g_run = false;
        return false;
    }

    HLog("recorder started → %s", g_path);
    return true;
}

void SubmitFrame(const uint8_t* rgba, int w, int h, int stride, int64_t ptsNs)
{
    if (!g_active.load() || !rgba || w <= 0 || h <= 0) return;

    // Configure codec on first frame if size was not forced
    if (g_outW <= 0) g_outW = w;
    if (g_outH <= 0) g_outH = h;

    static bool configured = false;
    if (!configured && g_codec) {
        AMediaFormat* fmt = AMediaFormat_new();
        AMediaFormat_setString(fmt, AMEDIAFORMAT_KEY_MIME, "video/avc");
        AMediaFormat_setInt32(fmt, AMEDIAFORMAT_KEY_WIDTH, g_outW);
        AMediaFormat_setInt32(fmt, AMEDIAFORMAT_KEY_HEIGHT, g_outH);
        AMediaFormat_setInt32(fmt, AMEDIAFORMAT_KEY_BIT_RATE, g_bitrate);
        AMediaFormat_setInt32(fmt, AMEDIAFORMAT_KEY_FRAME_RATE, g_fps);
        AMediaFormat_setInt32(fmt, AMEDIAFORMAT_KEY_I_FRAME_INTERVAL, 1);
        AMediaFormat_setInt32(fmt, AMEDIAFORMAT_KEY_COLOR_FORMAT, 21); // NV12 / YUV420SemiPlanar
        media_status_t st = AMediaCodec_configure(g_codec, fmt, nullptr, nullptr,
                                                  AMEDIACODEC_CONFIGURE_FLAG_ENCODE);
        AMediaFormat_delete(fmt);
        if (st != AMEDIA_OK) {
            HLog("AMediaCodec_configure failed: %d", (int)st);
            return;
        }
        AMediaCodec_start(g_codec);
        configured = true;
        HLog("codec configured %dx%d @ %d fps, %d kbps", g_outW, g_outH, g_fps, g_bitrate/1000);
    }

    // Copy frame into a job (render thread must not block on encode)
    size_t n = (size_t)stride * h;
    uint8_t* copy = (uint8_t*)malloc(n);
    if (!copy) return;
    memcpy(copy, rgba, n);

    pthread_mutex_lock(&g_mu);
    if (g_queue.size() >= MAX_QUEUE) {
        // drop oldest
        FrameJob old = g_queue.front();
        g_queue.pop();
        free(old.data);
        g.droppedFrames.fetch_add(1);
    }
    FrameJob job = {copy, w, h, stride, ptsNs};
    g_queue.push(job);
    pthread_cond_signal(&g_cv);
    pthread_mutex_unlock(&g_mu);
}

void Stop()
{
    if (!g_active.load()) return;
    HLog("recorder stopping…");
    g_run = false;
    pthread_cond_broadcast(&g_cv);
    if (g_thr) {
        pthread_join(g_thr, nullptr);
        g_thr = 0;
    }

    if (g_codec) {
        AMediaCodec_stop(g_codec);
        AMediaCodec_delete(g_codec);
        g_codec = nullptr;
    }
    if (g_muxer) {
        if (g_track >= 0) AMediaMuxer_stop(g_muxer);
        AMediaMuxer_delete(g_muxer);
        g_muxer = nullptr;
    }
    if (g_fd >= 0) {
        close(g_fd);
        g_fd = -1;
    }

    // Drain any leftover jobs
    pthread_mutex_lock(&g_mu);
    while (!g_queue.empty()) {
        free(g_queue.front().data);
        g_queue.pop();
    }
    pthread_mutex_unlock(&g_mu);

    g_active = false;
    HLog("recorder stopped, file: %s", g_path);
}

bool IsActive() { return g_active.load(); }

}
}
