#pragma once
namespace hexed {
void HLog(const char* fmt, ...);
const char* DataDir();          // Android/data/<pkg>/files  (or fallback)
}
