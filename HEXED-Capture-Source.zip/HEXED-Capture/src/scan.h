#pragma once
#include <stdint.h>
#include <string.h>

namespace hexed {
namespace scan {

// Safe bounded search (avoids 32-bit wrap that crashed early Resolution builds)
inline bool In(uintptr_t addr, uintptr_t start, uintptr_t end, size_t len)
{
    if (addr < start) return false;
    if (len == 0) return false;
    if (addr > end - len) return false;   // no addition that can wrap
    return true;
}

inline uintptr_t FindPattern(uintptr_t start, size_t size, const char* pattern, const char* mask)
{
    size_t plen = strlen(mask);
    if (plen == 0 || size < plen) return 0;
    uintptr_t end = start + size;
    for (uintptr_t p = start; In(p, start, end, plen); ++p) {
        bool ok = true;
        for (size_t i = 0; i < plen; ++i) {
            if (mask[i] == 'x' && *(uint8_t*)(p + i) != (uint8_t)pattern[i]) {
                ok = false;
                break;
            }
        }
        if (ok) return p;
    }
    return 0;
}

// Convenience: AML pattern scan wrapper that also accepts a library base + length
inline uintptr_t FindInLib(uintptr_t libBase, size_t libLen, const char* pattern, const char* mask)
{
    return FindPattern(libBase, libLen, pattern, mask);
}

}
}
