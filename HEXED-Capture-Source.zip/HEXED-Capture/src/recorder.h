#pragma once
#include <stdint.h>

namespace hexed {
namespace recorder {

// Start a new MP4 session. Returns false if MediaCodec cannot be created.
bool Start(const char* dir, int fps, int bitrateKbps, int forceW, int forceH);

// Called from the capture path with a full RGBA frame (may be called from render thread).
// Internally queues to a background encoder thread.
void SubmitFrame(const uint8_t* rgba, int w, int h, int stride, int64_t ptsNs);

// Finish the current file and release codec resources.
void Stop();

bool IsActive();

}
}
