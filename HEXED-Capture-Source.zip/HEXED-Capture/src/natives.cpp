/*
 * Pattern scan + hooks for the present / swap path.
 *
 * Verified strings in the supplied Nezuko libGTASA.so:
 *   OS_ScreenSwapBuffers
 *   RQ_Command_rqSwapBuffers
 *   emu_glReadPixels
 *   eglSwapBuffers (via libEGL)
 *
 * The exact instruction sequence / PLT entry still needs device confirmation.
 * This file installs the safest possible hooks and falls back gracefully.
 */
#include "capture.h"
#include "hlog.h"
#include "scan.h"
#include "state.h"

#include <mod/amlmod.h>
#include <mod/logger.h>

#include <EGL/egl.h>
#include <dlfcn.h>
#include <stdio.h>
#include <string.h>

namespace hexed {
namespace natives {

static uintptr_t g_libGTASA = 0;
static size_t    g_libLen   = 0;

// Original function pointers
static void (*orig_OS_ScreenSwapBuffers)() = nullptr;
static void (*orig_RQ_SwapBuffers)(char*& /*cmd*/) = nullptr;
static EGLBoolean (*orig_eglSwapBuffers)(EGLDisplay, EGLSurface) = nullptr;

// ---- our hooks ----
static void hooked_OS_ScreenSwapBuffers()
{
    capture::OnPresent();
    if (orig_OS_ScreenSwapBuffers)
        orig_OS_ScreenSwapBuffers();
}

static void hooked_RQ_SwapBuffers(char*& cmd)
{
    capture::OnPresent();
    if (orig_RQ_SwapBuffers)
        orig_RQ_SwapBuffers(cmd);
}

static EGLBoolean hooked_eglSwapBuffers(EGLDisplay dpy, EGLSurface surf)
{
    capture::OnPresent();
    if (orig_eglSwapBuffers)
        return orig_eglSwapBuffers(dpy, surf);
    return EGL_FALSE;
}

// Try to resolve a symbol by name first, then fall back to pattern if needed.
static uintptr_t ResolveSym(const char* name)
{
    if (!g_libGTASA) return 0;
    uintptr_t s = aml->GetSym(g_libGTASA, name);
    if (s) return s;
    // Some builds strip the export; try demangled / alternate names
    char alt[128];
    snprintf(alt, sizeof(alt), "_Z%s", name); // rough
    s = aml->GetSym(g_libGTASA, alt);
    return s;
}

bool Install()
{
    g_libGTASA = aml->GetLib("libGTASA.so");
    if (!g_libGTASA) {
        // Some Nezuko builds may expose it under a different name
        g_libGTASA = aml->GetLib("libGame.so");
    }
    if (!g_libGTASA) {
        HLog("natives: libGTASA.so not found");
        return false;
    }
    g_libLen = aml->GetLibLength("libGTASA.so");
    if (!g_libLen) g_libLen = 0x800000; // safe upper bound for scanning

    HLog("natives: libGTASA base=%p len=0x%x", (void*)g_libGTASA, (unsigned)g_libLen);

    bool any = false;

    // 1) Prefer the named export if it exists
    uintptr_t pSwap = ResolveSym("OS_ScreenSwapBuffers");
    if (!pSwap) pSwap = ResolveSym("_Z20OS_ScreenSwapBuffersv");
    if (pSwap) {
        if (aml->Hook((void*)pSwap, (void*)hooked_OS_ScreenSwapBuffers, (void**)&orig_OS_ScreenSwapBuffers)) {
            HLog("hooked OS_ScreenSwapBuffers @ %p", (void*)pSwap);
            any = true;
        } else {
            HLog("Hook OS_ScreenSwapBuffers failed");
        }
    } else {
        HLog("OS_ScreenSwapBuffers symbol not found (will try egl)");
    }

    // 2) RQ command path (used by some RW builds)
    uintptr_t pRQ = ResolveSym("RQ_Command_rqSwapBuffers");
    if (!pRQ) pRQ = ResolveSym("_Z24RQ_Command_rqSwapBuffersRPc");
    if (pRQ) {
        if (aml->Hook((void*)pRQ, (void*)hooked_RQ_SwapBuffers, (void**)&orig_RQ_SwapBuffers)) {
            HLog("hooked RQ_Command_rqSwapBuffers @ %p", (void*)pRQ);
            any = true;
        }
    }

    // 3) Always try eglSwapBuffers as a reliable fallback
    void* egl = dlopen("libEGL.so", RTLD_NOW | RTLD_NOLOAD);
    if (!egl) egl = dlopen("libEGL.so", RTLD_NOW);
    if (egl) {
        void* p = dlsym(egl, "eglSwapBuffers");
        if (p) {
            if (aml->Hook(p, (void*)hooked_eglSwapBuffers, (void**)&orig_eglSwapBuffers)) {
                HLog("hooked eglSwapBuffers @ %p", p);
                any = true;
            } else {
                HLog("Hook eglSwapBuffers failed");
            }
        }
    }

    if (!any) {
        HLog("natives: no present hooks installed – capture will be inactive");
        return false;
    }
    return true;
}

}
}
