#pragma once
#include <stdint.h>

namespace hexed {
namespace capture {

// Called once after hooks are installed
bool Init();

// Called from the hooked present / swap path (render thread)
void OnPresent();

// Request a single screenshot (sets atomic flag)
void RequestScreenshot();

// Start / pause / resume / stop recording
bool StartRecording();
void PauseRecording();
void ResumeRecording();
void StopRecording();

// Current state helpers
bool IsRecording();
bool IsPaused();

// Shutdown
void Shutdown();

}
}
