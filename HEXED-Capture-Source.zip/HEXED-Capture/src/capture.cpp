/*
 * Frame capture core for HEXED Capture.
 *
 * Design:
 *   - Hook the game's final present (OS_ScreenSwapBuffers / RQ_Command_rqSwapBuffers
 *     or eglSwapBuffers). At that moment the colour buffer contains the finished
 *     frame, including any Lua/ImGui visual mods that drew into the same FBO.
 *   - Read back with glReadPixels (or a PBO / FBO blit once RE confirms a safe path).
 *   - Hand the RGB/RGBA buffer to the recorder or write a PNG/JPG.
 *
 * IMPORTANT: the exact hook target and the GL state at present time are still
 * subject to device verification. See docs/LIMITATIONS.md and docs/NOTES.md.
 */
#include "capture.h"
#include "state.h"
#include "recorder.h"
#include "hlog.h"
#include "scan.h"

#include <mod/amlmod.h>
#include <mod/logger.h>

#include <EGL/egl.h>
#include <GLES2/gl2.h>
#include <android/log.h>
#include <pthread.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <unistd.h>
#include <sys/stat.h>

#define STB_IMAGE_WRITE_IMPLEMENTATION
#include "mod/thirdparty/stb_image_write.h"

// Minimal PNG writer (no external dep) – RGB8 only
#include <stdio.h>
#include <stdint.h>

namespace hexed {
namespace capture {

static pthread_mutex_t g_mu = PTHREAD_MUTEX_INITIALIZER;
static bool g_inited = false;

// Frame buffer we own (re-allocated when size changes)
static uint8_t* g_pixels = nullptr;
static int      g_pixW = 0, g_pixH = 0, g_pixStride = 0;

// FPS limiter for recording
static int64_t g_lastCaptureNs = 0;

static int64_t NowNs()
{
    struct timespec t;
    clock_gettime(CLOCK_MONOTONIC, &t);
    return (int64_t)t.tv_sec * 1000000000LL + t.tv_nsec;
}

static void EnsureBuffer(int w, int h)
{
    if (w <= 0 || h <= 0) return;
    if (g_pixels && g_pixW == w && g_pixH == h) return;
    free(g_pixels);
    g_pixStride = w * 4;           // RGBA
    size_t n = (size_t)g_pixStride * h;
    g_pixels = (uint8_t*)malloc(n);
    g_pixW = w;
    g_pixH = h;
    if (!g_pixels) {
        HLog("capture: malloc %dx%d failed", w, h);
        g_pixW = g_pixH = 0;
    }
}

static void SaveScreenshot(const uint8_t* rgba, int w, int h, int stride)
{
    const char* dir = g.screenshotDir[0] ? g.screenshotDir : DataDir();
    if (!dir) {
        HLog("screenshot: no output directory");
        return;
    }
    mkdir(dir, 0755);

    time_t t = time(nullptr);
    struct tm tm;
    localtime_r(&t, &tm);

    // glReadPixels is bottom-up; stb expects top-down → flip via negative stride
    const uint8_t* top = rgba + (h - 1) * stride;
    int negStride = -stride;

    char pathPng[512];
    snprintf(pathPng, sizeof(pathPng), "%s/HEXED_%04d%02d%02d_%02d%02d%02d.png",
             dir, tm.tm_year + 1900, tm.tm_mon + 1, tm.tm_mday,
             tm.tm_hour, tm.tm_min, tm.tm_sec);

    int ok = stbi_write_png(pathPng, w, h, 4, top, negStride);
    if (ok) {
        HLog("screenshot PNG: %s (%dx%d)", pathPng, w, h);
        return;
    }

    // fallback JPEG
    char pathJpg[512];
    snprintf(pathJpg, sizeof(pathJpg), "%s/HEXED_%04d%02d%02d_%02d%02d%02d.jpg",
             dir, tm.tm_year + 1900, tm.tm_mon + 1, tm.tm_mday,
             tm.tm_hour, tm.tm_min, tm.tm_sec);
    int q = g.jpegQuality.load();
    if (q < 50) q = 50;
    if (q > 100) q = 100;
    ok = stbi_write_jpg(pathJpg, w, h, 4, top, q);
    // stbi_write_jpg ignores stride - need contiguous top-down buffer if stride != w*4
    if (!ok && stride != w * 4) {
        uint8_t* contig = (uint8_t*)malloc((size_t)w * h * 4);
        if (contig) {
            for (int y = 0; y < h; y++)
                memcpy(contig + (size_t)y * w * 4, rgba + (size_t)(h - 1 - y) * stride, (size_t)w * 4);
            ok = stbi_write_jpg(pathJpg, w, h, 4, contig, q);
            free(contig);
        }
    } else if (!ok) {
        // try with flipped contiguous
        uint8_t* contig = (uint8_t*)malloc((size_t)w * h * 4);
        if (contig) {
            for (int y = 0; y < h; y++)
                memcpy(contig + (size_t)y * w * 4, rgba + (size_t)(h - 1 - y) * stride, (size_t)w * 4);
            ok = stbi_write_jpg(pathJpg, w, h, 4, contig, q);
            free(contig);
        }
    }

    if (ok)
        HLog("screenshot JPG: %s (%dx%d)", pathJpg, w, h);
    else
        HLog("screenshot write FAILED (%dx%d)", w, h);
}


static void ReadFramebuffer()
{
    GLint viewport[4] = {0, 0, 0, 0};
    glGetIntegerv(GL_VIEWPORT, viewport);
    int w = viewport[2];
    int h = viewport[3];
    if (w <= 0 || h <= 0) {
        // fallback: try EGL surface query
        EGLDisplay dpy = eglGetCurrentDisplay();
        EGLSurface surf = eglGetCurrentSurface(EGL_DRAW);
        if (dpy != EGL_NO_DISPLAY && surf != EGL_NO_SURFACE) {
            EGLint ew = 0, eh = 0;
            eglQuerySurface(dpy, surf, EGL_WIDTH, &ew);
            eglQuerySurface(dpy, surf, EGL_HEIGHT, &eh);
            w = ew; h = eh;
        }
    }
    if (w <= 0 || h <= 0) return;

    // Optional downscale request
    int outW = g.captureW.load();
    int outH = g.captureH.load();
    if (outW <= 0) outW = w;
    if (outH <= 0) outH = h;

    EnsureBuffer(w, h);
    if (!g_pixels) return;

    // Read the back buffer. On many Android GLES drivers the default framebuffer
    // is the one just drawn when we are inside the swap path.
    glPixelStorei(GL_PACK_ALIGNMENT, 1);
    glReadPixels(0, 0, w, h, GL_RGBA, GL_UNSIGNED_BYTE, g_pixels);

    GLenum err = glGetError();
    if (err != GL_NO_ERROR) {
        HLog("glReadPixels error 0x%x", (unsigned)err);
        return;
    }

    g.lastFrameW = w;
    g.lastFrameH = h;
    g.framesCaptured.fetch_add(1);

    // Screenshot?
    if (g.wantScreenshot.exchange(0)) {
        SaveScreenshot(g_pixels, w, h, g_pixStride);
    }

    // Recording?
    int st = g.recState.load();
    if (st == (int)RecState::Recording) {
        int64_t now = NowNs();
        int fps = g.targetFps.load();
        if (fps < 1) fps = 30;
        int64_t interval = 1000000000LL / fps;
        if (now - g_lastCaptureNs >= interval) {
            g_lastCaptureNs = now;
            recorder::SubmitFrame(g_pixels, w, h, g_pixStride, now);
        } else {
            g.droppedFrames.fetch_add(1);
        }
    }
}

void OnPresent()
{
    if (!g_inited) return;
    // Keep this path as light as possible
    ReadFramebuffer();
}

bool Init()
{
    if (g_inited) return true;
    HLog("capture: Init");
    // Default directories
    const char* base = DataDir();
    if (base) {
        snprintf(g.screenshotDir, sizeof(g.screenshotDir), "%s/HEXED_Screenshots", base);
        snprintf(g.recordingDir,  sizeof(g.recordingDir),  "%s/HEXED_Recordings",  base);
        mkdir(g.screenshotDir, 0755);
        mkdir(g.recordingDir,  0755);
    }
    g_inited = true;
    return true;
}

void RequestScreenshot()
{
    g.wantScreenshot = 1;
    HLog("screenshot requested");
}

bool StartRecording()
{
    if (g.recState.load() != (int)RecState::Idle) return false;
    if (!recorder::Start(g.recordingDir, g.targetFps.load(), g.bitrateKbps.load(),
                         g.captureW.load(), g.captureH.load())) {
        HLog("recorder::Start failed");
        return false;
    }
    g.recState = (int)RecState::Recording;
    g_lastCaptureNs = 0;
    HLog("recording started");
    return true;
}

void PauseRecording()
{
    if (g.recState.load() == (int)RecState::Recording) {
        g.recState = (int)RecState::Paused;
        HLog("recording paused");
    }
}

void ResumeRecording()
{
    if (g.recState.load() == (int)RecState::Paused) {
        g.recState = (int)RecState::Recording;
        HLog("recording resumed");
    }
}

void StopRecording()
{
    int st = g.recState.load();
    if (st == (int)RecState::Idle) return;
    g.recState = (int)RecState::Stopping;
    recorder::Stop();
    g.recState = (int)RecState::Idle;
    HLog("recording stopped");
}

bool IsRecording() { return g.recState.load() == (int)RecState::Recording; }
bool IsPaused()    { return g.recState.load() == (int)RecState::Paused; }

void Shutdown()
{
    StopRecording();
    free(g_pixels);
    g_pixels = nullptr;
    g_pixW = g_pixH = 0;
    g_inited = false;
}

}
}
