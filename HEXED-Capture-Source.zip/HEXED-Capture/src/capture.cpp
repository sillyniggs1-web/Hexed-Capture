/*
 * Frame capture core for HEXED Capture.
 *
 * Design:
 *   - Hook the game's final present (OS_ScreenSwapBuffers / RQ_Command_rqSwapBuffers
 *     or eglSwapBuffers). At that moment the colour buffer contains the finished
 *     frame, including any Lua/ImGui visual mods that drew into the same FBO.
 *   - Read back with glReadPixels (or a PBO / FBO blit once RE confirms a safe path).
 *   - Hand the RGB/RGBA buffer to the recorder or write a PNG/JPG.
 *
 * IMPORTANT: the exact hook target and the GL state at present time are still
 * subject to device verification. See docs/LIMITATIONS.md and docs/NOTES.md.
 */
#include "capture.h"
#include "state.h"
#include "recorder.h"
#include "hlog.h"
#include "scan.h"

#include <mod/amlmod.h>
#include <mod/logger.h>

#include <EGL/egl.h>
#include <GLES2/gl2.h>
#include <android/log.h>
#include <pthread.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <unistd.h>
#include <sys/stat.h>

// Minimal PNG writer (no external dep) – RGB8 only
#include <stdio.h>
#include <stdint.h>

namespace hexed {
namespace capture {

static pthread_mutex_t g_mu = PTHREAD_MUTEX_INITIALIZER;
static bool g_inited = false;

// Frame buffer we own (re-allocated when size changes)
static uint8_t* g_pixels = nullptr;
static int      g_pixW = 0, g_pixH = 0, g_pixStride = 0;

// FPS limiter for recording
static int64_t g_lastCaptureNs = 0;

static int64_t NowNs()
{
    struct timespec t;
    clock_gettime(CLOCK_MONOTONIC, &t);
    return (int64_t)t.tv_sec * 1000000000LL + t.tv_nsec;
}

static void EnsureBuffer(int w, int h)
{
    if (w <= 0 || h <= 0) return;
    if (g_pixels && g_pixW == w && g_pixH == h) return;
    free(g_pixels);
    g_pixStride = w * 4;           // RGBA
    size_t n = (size_t)g_pixStride * h;
    g_pixels = (uint8_t*)malloc(n);
    g_pixW = w;
    g_pixH = h;
    if (!g_pixels) {
        HLog("capture: malloc %dx%d failed", w, h);
        g_pixW = g_pixH = 0;
    }
}

// Extremely small CRC + PNG helpers (enough for screenshots)
static uint32_t crc_table[256];
static bool crc_ready = false;
static void make_crc_table()
{
    for (uint32_t n = 0; n < 256; n++) {
        uint32_t c = n;
        for (int k = 0; k < 8; k++)
            c = (c & 1) ? (0xedb88320u ^ (c >> 1)) : (c >> 1);
        crc_table[n] = c;
    }
    crc_ready = true;
}
static uint32_t crc32(const uint8_t* buf, size_t len)
{
    if (!crc_ready) make_crc_table();
    uint32_t c = 0xffffffffu;
    for (size_t i = 0; i < len; i++)
        c = crc_table[(c ^ buf[i]) & 0xff] ^ (c >> 8);
    return c ^ 0xffffffffu;
}
static void put32(FILE* f, uint32_t v)
{
    fputc((v >> 24) & 0xff, f);
    fputc((v >> 16) & 0xff, f);
    fputc((v >>  8) & 0xff, f);
    fputc( v        & 0xff, f);
}
static void write_chunk(FILE* f, const char* type, const uint8_t* data, size_t len)
{
    put32(f, (uint32_t)len);
    fwrite(type, 1, 4, f);
    if (len) fwrite(data, 1, len, f);
    uint8_t tmp[4];
    memcpy(tmp, type, 4);
    uint32_t c = crc32(tmp, 4);
    if (len) {
        // re-compute over type+data
        c = 0xffffffffu;
        for (int i = 0; i < 4; i++) c = crc_table[(c ^ type[i]) & 0xff] ^ (c >> 8);
        for (size_t i = 0; i < len; i++) c = crc_table[(c ^ data[i]) & 0xff] ^ (c >> 8);
        c ^= 0xffffffffu;
    }
    put32(f, c);
}

static bool WritePNG(const char* path, const uint8_t* rgba, int w, int h, int stride)
{
    FILE* f = fopen(path, "wb");
    if (!f) return false;
    // signature
    static const uint8_t sig[8] = {137,80,78,71,13,10,26,10};
    fwrite(sig, 1, 8, f);

    // IHDR
    uint8_t ihdr[13];
    ihdr[0] = (w >> 24) & 0xff; ihdr[1] = (w >> 16) & 0xff;
    ihdr[2] = (w >>  8) & 0xff; ihdr[3] =  w        & 0xff;
    ihdr[4] = (h >> 24) & 0xff; ihdr[5] = (h >> 16) & 0xff;
    ihdr[6] = (h >>  8) & 0xff; ihdr[7] =  h        & 0xff;
    ihdr[8] = 8;  // bit depth
    ihdr[9] = 6;  // RGBA
    ihdr[10] = 0; ihdr[11] = 0; ihdr[12] = 0;
    write_chunk(f, "IHDR", ihdr, 13);

    // IDAT – raw uncompressed (filter 0 + pixels). For real builds replace with zlib.
    // This is intentionally a placeholder; a production build should use stb_image_write
    // or Android Bitmap.compress. Here we just write a valid-ish PNG skeleton so the
    // call path can be tested.
    size_t rawLen = (size_t)(w * 4 + 1) * h;
    uint8_t* raw = (uint8_t*)malloc(rawLen);
    if (!raw) { fclose(f); return false; }
    size_t off = 0;
    for (int y = 0; y < h; y++) {
        raw[off++] = 0; // filter none
        const uint8_t* row = rgba + (h - 1 - y) * stride; // flip Y
        memcpy(raw + off, row, (size_t)w * 4);
        off += (size_t)w * 4;
    }
    // Note: real PNG needs zlib deflate. Without it most viewers reject the file.
    // Mark this path as "raw dump for debugging" and prefer JPEG / MediaCodec later.
    write_chunk(f, "IDAT", raw, off);
    free(raw);

    write_chunk(f, "IEND", nullptr, 0);
    fclose(f);
    return true;
}

// Fallback: write a simple raw RGBA dump that can be converted offline
static bool WriteRaw(const char* path, const uint8_t* rgba, int w, int h, int stride)
{
    FILE* f = fopen(path, "wb");
    if (!f) return false;
    // tiny header: "HXDRAW" + w + h
    fwrite("HXDRAW", 1, 6, f);
    uint32_t wh[2] = {(uint32_t)w, (uint32_t)h};
    fwrite(wh, 4, 2, f);
    for (int y = 0; y < h; y++) {
        const uint8_t* row = rgba + (h - 1 - y) * stride;
        fwrite(row, 1, (size_t)w * 4, f);
    }
    fclose(f);
    return true;
}

static void SaveScreenshot(const uint8_t* rgba, int w, int h, int stride)
{
    const char* dir = g.screenshotDir[0] ? g.screenshotDir : DataDir();
    if (!dir) {
        HLog("screenshot: no output directory");
        return;
    }
    mkdir(dir, 0755);

    time_t t = time(nullptr);
    struct tm tm;
    localtime_r(&t, &tm);
    char path[512];
    snprintf(path, sizeof(path), "%s/HEXED_%04d%02d%02d_%02d%02d%02d.raw",
             dir, tm.tm_year + 1900, tm.tm_mon + 1, tm.tm_mday,
             tm.tm_hour, tm.tm_min, tm.tm_sec);

    if (WriteRaw(path, rgba, w, h, stride))
        HLog("screenshot saved: %s (%dx%d)", path, w, h);
    else
        HLog("screenshot write failed: %s", path);
}

static void ReadFramebuffer()
{
    GLint viewport[4] = {0, 0, 0, 0};
    glGetIntegerv(GL_VIEWPORT, viewport);
    int w = viewport[2];
    int h = viewport[3];
    if (w <= 0 || h <= 0) {
        // fallback: try EGL surface query
        EGLDisplay dpy = eglGetCurrentDisplay();
        EGLSurface surf = eglGetCurrentSurface(EGL_DRAW);
        if (dpy != EGL_NO_DISPLAY && surf != EGL_NO_SURFACE) {
            EGLint ew = 0, eh = 0;
            eglQuerySurface(dpy, surf, EGL_WIDTH, &ew);
            eglQuerySurface(dpy, surf, EGL_HEIGHT, &eh);
            w = ew; h = eh;
        }
    }
    if (w <= 0 || h <= 0) return;

    // Optional downscale request
    int outW = g.captureW.load();
    int outH = g.captureH.load();
    if (outW <= 0) outW = w;
    if (outH <= 0) outH = h;

    EnsureBuffer(w, h);
    if (!g_pixels) return;

    // Read the back buffer. On many Android GLES drivers the default framebuffer
    // is the one just drawn when we are inside the swap path.
    glPixelStorei(GL_PACK_ALIGNMENT, 1);
    glReadPixels(0, 0, w, h, GL_RGBA, GL_UNSIGNED_BYTE, g_pixels);

    GLenum err = glGetError();
    if (err != GL_NO_ERROR) {
        HLog("glReadPixels error 0x%x", (unsigned)err);
        return;
    }

    g.lastFrameW = w;
    g.lastFrameH = h;
    g.framesCaptured.fetch_add(1);

    // Screenshot?
    if (g.wantScreenshot.exchange(0)) {
        SaveScreenshot(g_pixels, w, h, g_pixStride);
    }

    // Recording?
    int st = g.recState.load();
    if (st == (int)RecState::Recording) {
        int64_t now = NowNs();
        int fps = g.targetFps.load();
        if (fps < 1) fps = 30;
        int64_t interval = 1000000000LL / fps;
        if (now - g_lastCaptureNs >= interval) {
            g_lastCaptureNs = now;
            recorder::SubmitFrame(g_pixels, w, h, g_pixStride, now);
        } else {
            g.droppedFrames.fetch_add(1);
        }
    }
}

void OnPresent()
{
    if (!g_inited) return;
    // Keep this path as light as possible
    ReadFramebuffer();
}

bool Init()
{
    if (g_inited) return true;
    HLog("capture: Init");
    // Default directories
    const char* base = DataDir();
    if (base) {
        snprintf(g.screenshotDir, sizeof(g.screenshotDir), "%s/HEXED_Screenshots", base);
        snprintf(g.recordingDir,  sizeof(g.recordingDir),  "%s/HEXED_Recordings",  base);
        mkdir(g.screenshotDir, 0755);
        mkdir(g.recordingDir,  0755);
    }
    g_inited = true;
    return true;
}

void RequestScreenshot()
{
    g.wantScreenshot = 1;
    HLog("screenshot requested");
}

bool StartRecording()
{
    if (g.recState.load() != (int)RecState::Idle) return false;
    if (!recorder::Start(g.recordingDir, g.targetFps.load(), g.bitrateKbps.load(),
                         g.captureW.load(), g.captureH.load())) {
        HLog("recorder::Start failed");
        return false;
    }
    g.recState = (int)RecState::Recording;
    g_lastCaptureNs = 0;
    HLog("recording started");
    return true;
}

void PauseRecording()
{
    if (g.recState.load() == (int)RecState::Recording) {
        g.recState = (int)RecState::Paused;
        HLog("recording paused");
    }
}

void ResumeRecording()
{
    if (g.recState.load() == (int)RecState::Paused) {
        g.recState = (int)RecState::Recording;
        HLog("recording resumed");
    }
}

void StopRecording()
{
    int st = g.recState.load();
    if (st == (int)RecState::Idle) return;
    g.recState = (int)RecState::Stopping;
    recorder::Stop();
    g.recState = (int)RecState::Idle;
    HLog("recording stopped");
}

bool IsRecording() { return g.recState.load() == (int)RecState::Recording; }
bool IsPaused()    { return g.recState.load() == (int)RecState::Paused; }

void Shutdown()
{
    StopRecording();
    free(g_pixels);
    g_pixels = nullptr;
    g_pixW = g_pixH = 0;
    g_inited = false;
}

}
}
