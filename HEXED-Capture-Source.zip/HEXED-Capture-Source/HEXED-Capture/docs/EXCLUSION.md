# Selective Lua visual exclusion (0.4.0) - how it actually works

## Why 0.3.0 could not work
* "Hide" = `script:pause()` / `unload()+load()` on the deselected scripts. Device test (2026-11-10): `pause` leaves mimgui
  overlays drawing; `reload` destroys script state. Both act on the *script*, never on the *capture*.
* The capture path is one `glReadPixels` of the final back buffer: sources are already merged into pixels.

## Architecture (nothing is paused, unloaded or reset)
```
Lua callbacks (all scripts keep running)            libmonetloader (Dear ImGui 1.72)
   lua_pcall/lua_call/lua_resume  --GOT hook-->  script id via thisScript()
   ImGui::Begin(name)             --inline hook-> window name  -> script id
   Background/Foreground list     -- index ranges produced inside a script's pcall -> script id
igGetDrawData (hook, render thread) / ImGui::Render (same-thread case): capture due this frame?  yes -> in the draw data, indices of the selected
                             scripts' lists/ranges := 0 (degenerate triangles). ElemCount untouched.
native overlay renderer    : draws everything else
eglSwapBuffers (hook)      : glReadPixels  -> screenshot / video frame      (selected overlays absent)
                             restore indices, redraw ONLY the selected ranges with a small GLES2 renderer
                             (GL state saved/restored) -> swap: the screen shows everything
```
* Only frames that are actually captured are touched; all other frames: zero change.
* One profile per frame (screenshot and recording may exclude different scripts); a due recording frame is taken one frame later.
* On-screen difference: selected overlays are drawn last, i.e. on top of overlapping unselected ones.
* Works for any script whose output goes through ImGui (windows, `GetBackgroundDrawList`, `GetForegroundDrawList`, popups, tooltips, child windows).

## Fail closed (never a silent leak)
A frame is captured only if it was masked. Otherwise: skip and retry; after 90 failed frames the request is dropped with
`error=capture blocked: <reason>` (reasons: hooks not installed yet, draw list not attributable, ImDrawCmd layout not
confirmed, Render and present on different threads, shader failure, crash guard...). `exclude_failsafe=allow` (ini / `exclude failsafe allow`)
makes it capture anyway (not recommended).

## Runtime self-calibration (nothing assumed about the build)
* `ImDrawCmd` stride (32/36/40 B) is verified by `sum(ElemCount) == IdxBuffer.Size` over all lists, else no capture.
* Indices must be 16 bit and < vertex count, else no capture. Draw-list owner names are read with a mapped-memory check.
* Threads (found on the first device run: ImGui is built on the game thread, drawn and presented on the render thread):
  `igGetDrawData` is hooked too. When the presenting thread differs from the ImGui thread, the mask is applied on the render thread the moment the
  renderer fetches the draw data, a lock is held until the present (restore + redraw happen on the same thread), and the game thread's `NewFrame`
  waits at most 200 ms for it. If the renderer never fetches the draw data through `igGetDrawData`, captures are blocked with that exact reason
  (status line `exclude_threads=`).
* Crash guard: a game crash within 20 s of installing the hooks keeps exclusion off until `/hxdcap`-menu "Reset crash guard".

## Files / commands
* `src/exclude.cpp` hooks, attribution, mask, redraw, self-test; `src/exclude_core.h` + `imgui_abi.h` pure logic (host-tested).
* Config (`hexed_capture.ini`): `exclude_shot=a.lua|b.lua`, `exclude_rec=...`, `exclude_shot_on=1`, `exclude_rec_on=0`, `exclude_failsafe=block`.
  Menu ini `Hexed Capture.ini` keeps the checkbox state and `[excl]` names. Hooks install ~25 s after start, only when exclusion is enabled.
* Commands: `exclude add|del|clear|set|on|off shot|rec [name]`, `exclude test`, `exclude diag`, `exclude reset`, `exclude failsafe block|allow`;
  `win:<ImGui window name>[*]` entries exclude by window title (fallback when script attribution does not work).
* `/hxdcap verify` or Lua Visuals -> Verify: reference frame + masked frame, compares pixels around the selected overlays
  (removed-from-capture >= 30 px, changed-outside <= 0.01 %, redraw ok). Result in status `selftest=` and `hexed_capture.log`.

## What is NOT covered (honest limits)
* Scripts that draw only with MoonLoader `renderDraw*`/`renderFont*` natives (no ImGui) cannot be separated by this layer; the Lua
  tab shows "no ImGui output attributed" for scripts that run but never produce attributed ImGui output.
* If libmonetloader dispatches a script's frame callback through an FFI callback instead of lua_pcall/lua_call/lua_resume, that script is
  unattributed (use `win:` entries). `exclude diag` shows the windows seen and their script.
* Layout assumptions (ImGui 1.72, GLES2, GL texture ids) are checked at runtime but only a device run can confirm them: **this build has not
  been run on a device.**
