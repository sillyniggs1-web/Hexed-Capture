# Verified facts (SA-MP Nezuko 1.0.3 TESTING APK)
- `libGTASA.so` exports `_Z20OS_ScreenSwapBuffersv` (0x268ee5, 104 B). It swaps via JNI (`NVThreadGetCurrentJNIEnv` + `JNIEnv::CallBooleanMethod`); libGTASA has no `eglSwapBuffers` import. So the final EGL swap happens on the Java side.
- `_Z24RQ_Command_rqSwapBuffersRPc` is 4 bytes: not hookable.
- `_Z16emu_glReadPixelsiiiijjPv` exists; libGTASA imports `glReadPixels`, `glBindFramebuffer`, `glGetIntegerv` from libGLESV2 (GLES2 only: no PBO).
- libAML exports `AML::GetSym/HookPLT/HookBL/GetAndroidDataPath...` matching `mod/iaml.h`. AML mods folder pattern `%s/mods/`.
- libNezukoSA-MP.so contains `ImGuiRenderer`/`ImGuiWrapper`; libmonetloader provides the Lua `script` usertype (strings: name, path, version, description, get, pause, resume, this) but no `list`/`find`/`dead` string was found.
# Inferred / unverified
- Whether overlays are drawn before the swap hook runs (hence both hook modes).
- That `script.get(name)` returns an object whose `pause()` stops its overlay. The menu probes this at runtime.
- That `ffi.load("libHEXED_Capture.so")` resolves an already loaded AML mod (same pattern as other HEXED scripts); a command-file fallback exists.

# Hide-from-capture-only feature: what is known (0.3.0)
- libmonetloader has Dear ImGui 1.72; igBegin/igEnd/igRender/igNewFrame/igEndFrame are 4-byte B.W stubs (real: Begin 0x1df5e0, NewFrame 0x1dbd60, Render 0x1e6648, EndFrame 0x1e59f4). igGetDrawData / igGetBackgroundDrawList / igGetForegroundDrawList are real 20-24 byte functions.
- libmonetloader imports lua_pcall / lua_call / lua_resume via GOT (0x433594 / 0x433598 / 0x4337d0): script identity can be recovered per lua_State with thisScript().
- A pixel read-back cannot subtract an overlay. To keep scripts visible on screen but absent from the capture, the overlay pass must be split per script and composited off-screen. That needs: (1) attribution of ImGui calls to scripts, (2) the render order of the overlay pass vs. the game scene, (3) how the draw data is consumed. The probe (hexed_capture.ini probe=1, Status tab) records exactly these.

# 0.4.0
- Pause/reload hiding removed (violates "scripts must keep running"); replaced by capture-side masking, docs/EXCLUSION.md.
- probe.cpp removed: its hooks (Begin/NewFrame/Render + lua_pcall/call GOT) are now owned by exclude.cpp; `exclude diag` replaces the probe dump.
- Host-verified: mask/restore/redraw-item logic against a software rasterizer (tools/test_exclude.cpp, 48 checks). Device-unverified: hooks, attribution, GL redraw.
