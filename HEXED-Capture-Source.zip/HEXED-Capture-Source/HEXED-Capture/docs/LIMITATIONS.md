# Limitations (0.3.0)
- Not device-tested. Compiled only against stub headers on the host; the real build is the GitHub Actions run.
- Verified on host: PNG/JPEG writers, flip/scale, NV12/I420 conversion, script scanner.
- AML has no UI API: the "native menu" is a mimgui menu in the Lua script (same as the other HEXED menus).
- Lua "visual mod detection" is a text scan of script sources (mimgui/render* usage), not runtime introspection.
- Hiding a script = `pause()`; it freezes the whole script, not just its overlay, and may not hide mimgui overlays on this build. Use Test hide.
- `glReadPixels` stalls the GPU: cost scales with resolution x FPS. Lower resolution/FPS if the game slows. No audio track.
- Android system overlays are excluded by construction (the game's own back buffer is read).
- Custom folders outside Android/data/<pkg> may be refused by scoped storage; the plugin falls back to its default folder.
- Recording uses CPU colour conversion (NV12, I420 fallback); some encoders may reject sizes/bitrates.

# Device test results (2026-11-10, 2000x1200 tablet)
- Screenshots (PNG): OK, upright, HUD + overlays + chat included. Recording: valid H.264 MP4 (24 s, 1280x720, ~22.7 fps average).
- Hide method "pause": the call succeeds but mimgui overlays keep drawing -> does not work.
- 0.3.0 adds hide method "reload" (unload before capture, script.load after) and a "Probe script API" button
  (writes hexed_capture_api.txt next to the scripts). Reload is untested: send the probe file if it fails.
