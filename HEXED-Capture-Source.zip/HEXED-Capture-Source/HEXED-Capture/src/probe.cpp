/*
 * Render probe (READ ONLY). Goal: learn, on a real device, what is needed to keep selected
 * Lua overlays on screen while leaving them out of the captured image.
 *
 * Verified in the APK (libmonetloader.so, Dear ImGui 1.72):
 *   igBegin/igEnd/igRender/igNewFrame/igEndFrame exports are 4-byte "B.W" stubs -> never
 *   hooked directly. The stub target is decoded and the real function is hooked instead.
 *   libmonetloader imports lua_pcall/lua_call/lua_resume through the GOT.
 *
 * What it records: per frame the order of NEWFRAME / BEGIN(window name, script) / BGLIST / FGLIST /
 * RENDER(draw data totals) / PRESENT, and which Lua script (via thisScript()) was running its
 * pcall when each ImGui call happened.
 */
#include "probe.h"
#include "state.h"

#include <mod/amlmod.h>

#include <atomic>
#include <dlfcn.h>
#include <elf.h>
#include <link.h>
#include <stdio.h>
#include <string.h>
#include <sys/mman.h>
#include <unistd.h>
#include <sys/syscall.h>

namespace hexed {
namespace probe {

struct lua_State;
typedef int (*lua_CFunction_t)(lua_State*);
static const int GLOBALSINDEX = -10002;
static int  (*lj_gettop)(lua_State*) = nullptr;
static void (*lj_settop)(lua_State*, int) = nullptr;
static void (*lj_getfield)(lua_State*, int, const char*) = nullptr;
static int  (*lj_type)(lua_State*, int) = nullptr;
static const char* (*lj_tolstring)(lua_State*, int, size_t*) = nullptr;

typedef int (*pcall_t)(lua_State*, int, int, int);
typedef void (*call_t)(lua_State*, int, int);
static pcall_t orig_pcall = nullptr;
static call_t  orig_call = nullptr;

static bool (*orig_Begin)(const char*, bool*, int) = nullptr;
static void (*orig_NewFrame)() = nullptr;
static void (*orig_Render)() = nullptr;
static void* (*orig_Bg)() = nullptr;
static void* (*orig_Fg)() = nullptr;
static void* (*fn_GetDrawData)() = nullptr;

static std::atomic<bool> g_installed{false};
static std::atomic<int>  g_framesLeft{0};
static std::atomic<int>  g_frame{0};

// ---- script identity per lua_State
struct Named { lua_State* L; char name[80]; };
static Named g_names[64];
static int g_nNames = 0;
static __thread const char* t_script = nullptr;

static const char* ScriptName(lua_State* L)
{
    for (int i = 0; i < g_nNames; i++) if (g_names[i].L == L) return g_names[i].name;
    if (g_nNames >= 64 || !lj_gettop || !orig_pcall) return nullptr;
    char nm[80] = "?";
    int top = lj_gettop(L);
    lj_getfield(L, GLOBALSINDEX, "thisScript");
    if (lj_type(L, -1) == 6 /*LUA_TFUNCTION*/ && orig_pcall(L, 0, 1, 0) == 0) {
        static const char* fields[] = {"path", "name", nullptr};
        for (int f = 0; fields[f]; f++) {
            lj_getfield(L, -1, fields[f]);
            const char* s = lj_tolstring(L, -1, nullptr);
            if (s && *s) {
                const char* slash = strrchr(s, '/');
                snprintf(nm, sizeof(nm), "%s", slash ? slash + 1 : s);
                lj_settop(L, -2);
                break;
            }
            lj_settop(L, -2);
        }
    }
    lj_settop(L, top);
    Named& n = g_names[g_nNames];
    n.L = L;
    snprintf(n.name, sizeof(n.name), "%s", nm);
    g_nNames++;
    return n.name;
}

// ---- event ring
enum EvType { EV_NEWFRAME = 1, EV_BEGIN, EV_BG, EV_FG, EV_RENDER, EV_PRESENT, EV_PCALL };
struct Ev { uint8_t type; int32_t tid; int64_t us; char script[40]; char arg[40]; int a, b; };
static const int MAXEV = 6000;
static Ev g_ev[MAXEV];
static std::atomic<int> g_nev{0};

static void Log(int type, const char* arg, int a = 0, int b = 0)
{
    if (g_framesLeft.load(std::memory_order_relaxed) <= 0) return;
    int i = g_nev.fetch_add(1);
    if (i >= MAXEV) return;
    Ev& e = g_ev[i];
    e.type = (uint8_t)type;
    e.tid = (int32_t)syscall(SYS_gettid);
    e.us = NowUs();
    snprintf(e.script, sizeof(e.script), "%s", t_script ? t_script : "-");
    snprintf(e.arg, sizeof(e.arg), "%s", arg ? arg : "");
    e.a = a; e.b = b;
}

// ---- hooks
static int hk_pcall(lua_State* L, int nargs, int nres, int errf)
{
    const char* prev = t_script;
    if (g_framesLeft.load(std::memory_order_relaxed) > 0) t_script = ScriptName(L);
    int r = orig_pcall(L, nargs, nres, errf);
    t_script = prev;
    return r;
}
static void hk_call(lua_State* L, int nargs, int nres)
{
    const char* prev = t_script;
    if (g_framesLeft.load(std::memory_order_relaxed) > 0) t_script = ScriptName(L);
    orig_call(L, nargs, nres);
    t_script = prev;
}
static bool hk_Begin(const char* name, bool* open, int flags)
{
    Log(EV_BEGIN, name);
    return orig_Begin(name, open, flags);
}
static void hk_NewFrame()
{
    g_frame.fetch_add(1);
    Log(EV_NEWFRAME, "", g_frame.load());
    orig_NewFrame();
}
static void hk_Render()
{
    orig_Render();
    int lists = 0, vtx = 0, idx = 0;
    if (fn_GetDrawData) {
        // ImDrawData in Dear ImGui 1.72: {bool Valid; ImDrawList** CmdLists; int CmdListsCount; int TotalIdxCount; int TotalVtxCount; ...}
        uint8_t* dd = (uint8_t*)fn_GetDrawData();
        if (dd) { lists = *(int*)(dd + 8); idx = *(int*)(dd + 12); vtx = *(int*)(dd + 16); }
    }
    Log(EV_RENDER, "", lists, vtx);
    (void)idx;
    // the window counts down per Render call
    int left = g_framesLeft.load();
    if (left > 0) g_framesLeft.store(left - 1);
}
static void* hk_Bg() { Log(EV_BG, ""); return orig_Bg(); }
static void* hk_Fg() { Log(EV_FG, ""); return orig_Fg(); }

void OnPresent()
{
    if (g_framesLeft.load(std::memory_order_relaxed) > 0) Log(EV_PRESENT, "", g_frame.load());
}

// ---- helpers
static uintptr_t FollowStub(uintptr_t exp)
{
    uintptr_t a = exp & ~(uintptr_t)1;
    uint16_t h1 = *(uint16_t*)a, h2 = *(uint16_t*)(a + 2);
    if ((h1 & 0xF800) != 0xF000 || (h2 & 0xD000) != 0x9000) return 0;   // not B.W
    int S = (h1 >> 10) & 1, J1 = (h2 >> 13) & 1, J2 = (h2 >> 11) & 1;
    int I1 = ~(J1 ^ S) & 1, I2 = ~(J2 ^ S) & 1;
    int32_t imm = (S << 24) | (I1 << 23) | (I2 << 22) | ((h1 & 0x3FF) << 12) | ((h2 & 0x7FF) << 1);
    if (S) imm -= (1 << 25);
    return (uintptr_t)((int32_t)(a + 4) + imm) | 1;
}

static bool PatchGot(uintptr_t base, const char* sym, void* fn, void** origOut)
{
    const Elf32_Ehdr* eh = (const Elf32_Ehdr*)base;
    const Elf32_Phdr* ph = (const Elf32_Phdr*)(base + eh->e_phoff);
    const Elf32_Dyn* dyn = nullptr;
    for (int i = 0; i < eh->e_phnum; i++) if (ph[i].p_type == PT_DYNAMIC) dyn = (const Elf32_Dyn*)(base + ph[i].p_vaddr);
    if (!dyn) return false;
    const Elf32_Sym* symtab = nullptr; const char* strtab = nullptr;
    const Elf32_Rel *jmprel = nullptr, *rel = nullptr; size_t jmprelsz = 0, relsz = 0;
    for (const Elf32_Dyn* d = dyn; d->d_tag != DT_NULL; d++) {
        switch (d->d_tag) {
            case DT_SYMTAB: symtab = (const Elf32_Sym*)(base + d->d_un.d_ptr); break;
            case DT_STRTAB: strtab = (const char*)(base + d->d_un.d_ptr); break;
            case DT_JMPREL: jmprel = (const Elf32_Rel*)(base + d->d_un.d_ptr); break;
            case DT_PLTRELSZ: jmprelsz = d->d_un.d_val; break;
            case DT_REL: rel = (const Elf32_Rel*)(base + d->d_un.d_ptr); break;
            case DT_RELSZ: relsz = d->d_un.d_val; break;
        }
    }
    if (!symtab || !strtab) return false;
    const Elf32_Rel* tabs[2] = {jmprel, rel};
    size_t sizes[2] = {jmprelsz, relsz};
    bool done = false;
    for (int t = 0; t < 2; t++) {
        for (size_t i = 0; tabs[t] && i < sizes[t] / sizeof(Elf32_Rel); i++) {
            const Elf32_Rel& r = tabs[t][i];
            int type = ELF32_R_TYPE(r.r_info);
            if (type != 22 /*JUMP_SLOT*/ && type != 21 /*GLOB_DAT*/) continue;
            if (strcmp(strtab + symtab[ELF32_R_SYM(r.r_info)].st_name, sym) != 0) continue;
            void** slot = (void**)(base + r.r_offset);
            uintptr_t page = (uintptr_t)slot & ~(uintptr_t)4095;
            if (mprotect((void*)page, 4096, PROT_READ | PROT_WRITE) != 0) return false;
            if (!*origOut) *origOut = *slot;
            *slot = fn;
            done = true;
        }
    }
    return done;
}

bool Installed() { return g_installed.load(); }

bool Install()
{
    if (g_installed.load()) return true;
    uintptr_t mon = aml->GetLib("libmonetloader.so");
    if (!mon) { HLog("probe: libmonetloader.so not loaded yet"); return false; }

    void* lj = dlopen("libluajit-5.1.so", RTLD_NOW | RTLD_NOLOAD);
    if (lj) {
        *(void**)&lj_gettop = dlsym(lj, "lua_gettop");
        *(void**)&lj_settop = dlsym(lj, "lua_settop");
        *(void**)&lj_getfield = dlsym(lj, "lua_getfield");
        *(void**)&lj_type = dlsym(lj, "lua_type");
        *(void**)&lj_tolstring = dlsym(lj, "lua_tolstring");
    }
    HLog("probe: libmonetloader %p, luajit api %s", (void*)mon, (lj_getfield && lj_tolstring) ? "ok" : "MISSING");

    uintptr_t eBegin = aml->GetSym(mon, "igBegin"), eNew = aml->GetSym(mon, "igNewFrame"), eRender = aml->GetSym(mon, "igRender");
    uintptr_t eBg = aml->GetSym(mon, "igGetBackgroundDrawList"), eFg = aml->GetSym(mon, "igGetForegroundDrawList");
    *(void**)&fn_GetDrawData = (void*)aml->GetSym(mon, "igGetDrawData");
    uintptr_t tBegin = eBegin ? FollowStub(eBegin) : 0, tNew = eNew ? FollowStub(eNew) : 0, tRender = eRender ? FollowStub(eRender) : 0;
    HLog("probe: real ImGui::Begin %p NewFrame %p Render %p (exports %p %p %p)", (void*)tBegin, (void*)tNew, (void*)tRender,
         (void*)eBegin, (void*)eNew, (void*)eRender);

    int ok = 0;
    if (tBegin && aml->Hook((void*)tBegin, (void*)hk_Begin, (void**)&orig_Begin)) ok++;
    if (tNew && aml->Hook((void*)tNew, (void*)hk_NewFrame, (void**)&orig_NewFrame)) ok++;
    if (tRender && aml->Hook((void*)tRender, (void*)hk_Render, (void**)&orig_Render)) ok++;
    if (eBg && aml->Hook((void*)eBg, (void*)hk_Bg, (void**)&orig_Bg)) ok++;
    if (eFg && aml->Hook((void*)eFg, (void*)hk_Fg, (void**)&orig_Fg)) ok++;
    bool g1 = PatchGot(mon, "lua_pcall", (void*)hk_pcall, (void**)&orig_pcall);
    bool g2 = PatchGot(mon, "lua_call", (void*)hk_call, (void**)&orig_call);
    HLog("probe: ImGui hooks %d/5, GOT lua_pcall %d lua_call %d", ok, (int)g1, (int)g2);
    g_installed.store(true);
    return ok > 0;
}

bool Run(int frames)
{
    if (!g_installed.load()) { SetError("probe: not installed (set probe=1 in hexed_capture.ini and restart)"); return false; }
    g_nev.store(0);
    g_framesLeft.store(frames);
    // wait for the window to finish (service thread calls this, blocking is fine)
    int64_t deadline = NowUs() + 15LL * 1000000;
    while (g_framesLeft.load() > 0 && NowUs() < deadline) usleep(50 * 1000);
    int n = g_nev.load();
    g_framesLeft.store(0);
    if (n > MAXEV) n = MAXEV;

    char path[640];
    snprintf(path, sizeof(path), "%s/hexed_capture_probe.txt", DataDir());
    FILE* f = fopen(path, "w");
    if (!f) { SetError("probe: cannot write %s", path); return false; }
    fprintf(f, "HEXED Capture render probe, %d events, scripts seen via thisScript():\n", n);
    for (int i = 0; i < g_nNames; i++) fprintf(f, "  L=%p %s\n", (void*)g_names[i].L, g_names[i].name);

    // aggregate per script
    struct Agg { char s[40]; int begin, bg, fg; };
    static Agg agg[40]; int na = 0;
    int frameCount = 0, renderBeforePresent = 0, presents = 0, lastRender = 0;
    for (int i = 0; i < n; i++) {
        const Ev& e = g_ev[i];
        if (e.type == EV_NEWFRAME) frameCount++;
        if (e.type == EV_RENDER) lastRender = 1;
        if (e.type == EV_PRESENT) { presents++; if (lastRender) renderBeforePresent++; lastRender = 0; }
        if (e.type == EV_BEGIN || e.type == EV_BG || e.type == EV_FG) {
            int k = 0;
            while (k < na && strcmp(agg[k].s, e.script) != 0) k++;
            if (k == na && na < 40) { snprintf(agg[na].s, sizeof(agg[na].s), "%s", e.script); agg[na].begin = agg[na].bg = agg[na].fg = 0; na++; }
            if (k < 40) { if (e.type == EV_BEGIN) agg[k].begin++; else if (e.type == EV_BG) agg[k].bg++; else agg[k].fg++; }
        }
    }
    fprintf(f, "\nframes (NewFrame) %d, presents %d, presents preceded by a Render since the last present: %d\n", frameCount, presents, renderBeforePresent);
    fprintf(f, "ImGui calls per script ('-' = no monetloader pcall/call active => NOT attributable):\n");
    for (int k = 0; k < na; k++) fprintf(f, "  %-36s Begin %d  BackgroundDrawList %d  ForegroundDrawList %d\n", agg[k].s, agg[k].begin, agg[k].bg, agg[k].fg);

    fprintf(f, "\nevent sequence (first 400):\n");
    int64_t t0 = n ? g_ev[0].us : 0;
    static const char* names[] = {"?", "NEWFRAME", "BEGIN", "BGLIST", "FGLIST", "RENDER", "PRESENT", "PCALL"};
    for (int i = 0; i < n && i < 400; i++) {
        const Ev& e = g_ev[i];
        fprintf(f, "%8lld us tid %d %-8s script=%s arg=%s a=%d b=%d\n", (long long)(e.us - t0), e.tid, names[e.type < 8 ? e.type : 0], e.script, e.arg, e.a, e.b);
    }
    fclose(f);
    HLog("probe: wrote %s (%d events)", path, n);
    return true;
}

}
}
