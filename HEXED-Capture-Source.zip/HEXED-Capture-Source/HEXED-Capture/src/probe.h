#pragma once
namespace hexed {
namespace probe {
// Read-only diagnostics for the "hide scripts from the capture only" feature.
// Installed only when hexed_capture.ini has probe=1 (never by default).
bool Install();                 // hooks ImGui 1.72 functions inside libmonetloader + patches its lua_pcall/lua_call GOT slots
bool Run(int frames);           // start logging for N frames, result -> hexed_capture_probe.txt
void OnPresent();               // called from the present hook
bool Installed();
}
}
