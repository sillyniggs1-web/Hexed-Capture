/*
 * Render-thread side: read the finished frame back from the default framebuffer.
 * Cost when idle: two atomic loads per frame (and one EGL size query every 32 frames).
 */
#include "capture.h"
#include "pipeline.h"
#include "state.h"
#include "exclude.h"

#include <GLES2/gl2.h>
#include <stdint.h>

namespace hexed {
namespace capture {

static volatile bool g_ready = false;
static int64_t g_nextDueUs = 0;
static int64_t g_lastPts = -1;
static int g_errCount = 0;

bool Init()
{
    if (g_ready) return true;
    if (!pipe::Init()) return false;
    g_ready = true;
    HLog("capture: ready");
    return true;
}

void Shutdown()
{
    g_ready = false;
    StopRecording();
    pipe::Shutdown();
}

static bool GameSurface(EGLDisplay dpy, EGLSurface surf, EGLDisplay* d, EGLSurface* s, int* w, int* h)
{
    *d = dpy != EGL_NO_DISPLAY ? dpy : eglGetCurrentDisplay();
    *s = eglGetCurrentSurface(EGL_DRAW);
    if (*d == EGL_NO_DISPLAY || *s == EGL_NO_SURFACE) return false;
    // eglSwapBuffers hook: only the surface that is being presented AND current
    if (surf != EGL_NO_SURFACE && surf != *s) return false;
    EGLint ew = 0, eh = 0;
    if (!eglQuerySurface(*d, *s, EGL_WIDTH, &ew) || !eglQuerySurface(*d, *s, EGL_HEIGHT, &eh)) return false;
    if (ew < 64 || eh < 64) return false;   // ignore tiny pbuffers
    *w = ew; *h = eh;
    return true;
}

int PlanProfile()
{
    if (g.wantShot.load(std::memory_order_relaxed)) return 1;
    if (g.recState.load(std::memory_order_relaxed) == REC_RECORDING && NowUs() >= g_nextDueUs) return 2;
    return 0;
}

// Runs on EVERY exit of OnPresent: restores the masked draw data and redraws the excluded overlays
// (after the read-back, before the swap). Does nothing unless the exclusion layer masked this frame.
struct FinishGuard {
    EGLDisplay dpy; EGLSurface surf;
    ~FinishGuard()
    {
        if (!exclude::NeedsFinish()) return;
        EGLDisplay d; EGLSurface s; int w = 0, h = 0;
        bool ok = GameSurface(dpy, surf, &d, &s, &w, &h);
        exclude::FinishPresent(ok, w, h);
    }
};

void OnPresent(EGLDisplay dpy, EGLSurface surf)
{
    if (!g_ready) return;
    FinishGuard guard{dpy, surf};
    exclude::NotePresentThread();
    int n = g.presents.fetch_add(1, std::memory_order_relaxed);

    int w = 0, h = 0;
    EGLDisplay d; EGLSurface s;

    // keep the "last known frame size" fresh without paying for it every frame
    if ((n & 31) == 0 && GameSurface(dpy, surf, &d, &s, &w, &h)) {
        g.srcW.store(w, std::memory_order_relaxed);
        g.srcH.store(h, std::memory_order_relaxed);
    }

    bool shot = g.wantShot.load(std::memory_order_relaxed) != 0;
    bool recDue = false;
    int64_t now = 0;
    if (g.recState.load(std::memory_order_relaxed) == REC_RECORDING) {
        now = NowUs();
        recDue = now >= g_nextDueUs;
    }
    // With exclusion armed a frame serves ONE capture profile (screenshot and recording may exclude
    // different scripts); the recording frame stays due and is taken on the next frame.
    if (shot && recDue && exclude::AnyActive()) recDue = false;
    if (!shot && !recDue) return;

    if (!GameSurface(dpy, surf, &d, &s, &w, &h)) return;
    g.srcW.store(w); g.srcH.store(h);

    // Never capture a frame in which the selected scripts were not masked (fail closed).
    {
        exclude::Gate gt = exclude::GateCapture(shot ? exclude::PROF_SHOT : exclude::PROF_REC);
        if (gt == exclude::GATE_SKIP) return;                         // retry on the next frame
        if (gt == exclude::GATE_BLOCK) {
            char why[240]; exclude::BlockReason(why, sizeof(why));
            SetError("capture blocked: %s", why);
            if (shot) g.wantShot.store(0);
            if (recDue) { g.framesDropped.fetch_add(1); int f = g.fps.load(); g_nextDueUs = now + 1000000LL / (f < 1 ? 30 : f); }
            return;
        }
    }

    int slot = -1;
    uint8_t* buf = pipe::Acquire(w, h, &slot);
    if (!buf) {
        if (recDue) g.framesDropped.fetch_add(1);
        return;
    }

    // --- read back from the default framebuffer, leaving GL state exactly as we found it
    GLint fbo = 0, align = 4;
    glGetIntegerv(GL_FRAMEBUFFER_BINDING, &fbo);
    glGetIntegerv(GL_PACK_ALIGNMENT, &align);
    if (fbo != 0) glBindFramebuffer(GL_FRAMEBUFFER, 0);
    glPixelStorei(GL_PACK_ALIGNMENT, 4);
    glReadPixels(0, 0, w, h, GL_RGBA, GL_UNSIGNED_BYTE, buf);
    glPixelStorei(GL_PACK_ALIGNMENT, align);
    if (fbo != 0) glBindFramebuffer(GL_FRAMEBUFFER, (GLuint)fbo);
    GLenum err = glGetError();
    if (err != GL_NO_ERROR) {
        if (g_errCount++ < 5) HLog("capture: glReadPixels error 0x%x (fbo was %d)", (unsigned)err, (int)fbo);
        pipe::Release(slot);
        return;
    }
    g.framesRead.fetch_add(1);

    int refs = (shot ? 1 : 0) + (recDue ? 1 : 0);
    pipe::SetRefs(slot, refs);

    if (shot) {
        g.wantShot.store(0);
        pipe::SubmitShot(slot, w, h);
    }
    if (recDue) {
        int fps = g.fps.load();
        if (fps < 1) fps = 30;
        int64_t interval = 1000000LL / fps;
        g_nextDueUs += interval;
        if (g_nextDueUs < now) g_nextDueUs = now + interval;   // never burst to catch up

        int64_t pts = now - g.recStartUs.load() - g.pausedTotalUs.load();
        if (pts <= g_lastPts) pts = g_lastPts + 1000;
        g_lastPts = pts;
        pipe::SubmitFrame(slot, w, h, pts);
    }
}

bool StartRecording()
{
    if (!g_ready) { SetError("capture is not active (safe-mode stage)"); return false; }
    if (g.recState.load() != REC_IDLE) return false;
    g.recStartUs.store(NowUs());
    g.pausedTotalUs.store(0);
    g_nextDueUs = 0;
    g_lastPts = -1;
    if (!pipe::StartRecording()) return false;
    g.recState.store(REC_RECORDING);
    HLog("recording started");
    return true;
}

bool StopRecording()
{
    int st = g.recState.load();
    if (st == REC_IDLE) return true;
    g.recState.store(REC_STOPPING);
    bool ok = pipe::StopRecording();
    g.recState.store(REC_IDLE);
    HLog("recording stopped (%s)", ok ? "saved" : "no file");
    return ok;
}

void PauseRecording()
{
    if (g.recState.load() != REC_RECORDING) return;
    g.pauseBeginUs.store(NowUs());
    g.recState.store(REC_PAUSED);
    HLog("recording paused");
}

void ResumeRecording()
{
    if (g.recState.load() != REC_PAUSED) return;
    g.pausedTotalUs.fetch_add(NowUs() - g.pauseBeginUs.load());
    g_nextDueUs = 0;
    g.recState.store(REC_RECORDING);
    HLog("recording resumed");
}

}
}
