#pragma once
#include <stddef.h>
#include <stdint.h>
// Capture-side exclusion of selected Lua scripts' ImGui output (see docs/EXCLUSION.md).
namespace hexed {
namespace exclude {

enum { PROF_NONE = 0, PROF_SHOT = 1, PROF_REC = 2 };
enum Gate { GATE_OPEN = 0, GATE_SKIP = 1, GATE_BLOCK = 2 };

// ---- configuration (any thread)
void SetEnabled(int prof, bool on);
bool Enabled(int prof);
void ClearList(int prof);
bool AddName(int prof, const char* name);
bool DelName(int prof, const char* name);
void GetList(int prof, char* out, size_t n);        // '|' separated
void SetList(int prof, const char* piped);
void SetFailsafeBlock(bool block);
bool FailsafeBlock();

// ---- lifecycle (service thread)
bool WantInstall();                 // exclusion is configured/enabled somewhere (or a self-test was requested)
bool Install();                     // hooks ImGui 1.72 in libmonetloader + lua_pcall/lua_call/lua_resume GOT slots
bool Installed();
void LoadCrashGuard();              // call once at load
void OnSurvived();
void OnGameCrash();
void ResetCrashGuard();

// ---- render / present thread
bool AnyActive();                   // enabled AND non-empty for at least one profile
void OnRenderDone();                // end of ImGui::Render (mask the selected scripts if a capture is due this frame)
Gate GateCapture(int prof);         // present hook: may this frame be captured?
bool NeedsFinish();                 // present hook: something to restore/redraw/verify
void FinishPresent(bool onGameSurface, int fbW, int fbH);   // after the read-back: restore + redraw excluded overlays

// ---- diagnostics
void BlockReason(char* out, size_t n);
void BuildStatus(char* out, size_t n);   // key=value lines (appended to the normal status)
int  BuildInfo(char* out, size_t n);     // "<script>\t<pcalls>\t<windows>\t<bgIdx>\t<fgIdx>\t<maskedIdx>\n"
bool Diag();                             // writes hexed_capture_exclude.txt
void RequestSelfTest();

}
}
