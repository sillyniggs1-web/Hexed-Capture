#pragma once
// Shared runtime state for HEXED Capture. Everything here is either an atomic
// or only touched through the helpers in state.cpp (mutex protected).
#include <atomic>
#include <stdint.h>
#include <stddef.h>

namespace hexed {

enum RecState { REC_IDLE = 0, REC_RECORDING = 1, REC_PAUSED = 2, REC_STOPPING = 3 };
enum ImgFormat { FMT_PNG = 0, FMT_JPG = 1 };
enum HookMode  { HOOK_EGL = 0, HOOK_OS = 1 };

struct Shared {
    std::atomic<int> wantShot{0};
    std::atomic<int> recState{REC_IDLE};

    // user settings (0 for width/height = native size)
    std::atomic<int> fps{30};
    std::atomic<int> bitrateKbps{8000};
    std::atomic<int> outW{0};
    std::atomic<int> outH{0};
    std::atomic<int> jpegQuality{90};
    std::atomic<int> imgFormat{FMT_PNG};
    std::atomic<int> hookMode{HOOK_EGL};
    std::atomic<int> probeOn{0};

    // runtime stats
    std::atomic<int> srcW{0};
    std::atomic<int> srcH{0};
    std::atomic<int> framesRead{0};
    std::atomic<int> framesEncoded{0};
    std::atomic<int> framesDropped{0};
    std::atomic<int> shotsSaved{0};
    std::atomic<int> presents{0};
    std::atomic<int> activeHook{-1};

    // recording clock (microseconds, CLOCK_MONOTONIC)
    std::atomic<int64_t> recStartUs{0};
    std::atomic<int64_t> pausedTotalUs{0};
    std::atomic<int64_t> pauseBeginUs{0};
};

extern Shared g;

int64_t NowUs();

// Mutex protected strings
void SetShotDir(const char* p);
void SetRecDir(const char* p);
void GetShotDir(char* out, size_t n);
void GetRecDir(char* out, size_t n);
void SetLastFile(const char* p);
void GetLastFile(char* out, size_t n);
void SetError(const char* fmt, ...);
void GetError(char* out, size_t n);

// Directory that holds the plugin's own files (config, log, stage). Never null
// after the first successful call; may be "" if nothing was writable.
const char* DataDir();
// Directory MonetLoader scripts live in, derived from DataDir (Android/media/<pkg>/monetloader).
const char* MediaScriptDir();

// recursive mkdir -p
bool MakeDirs(const char* path);

void HLog(const char* fmt, ...);

}
