#pragma once
#include <EGL/egl.h>

namespace hexed {
namespace capture {

bool Init();                 // starts the worker; enables read-back
void Shutdown();

// Render thread, right before the frame is presented.
// dpy/surf may be EGL_NO_* (OS_ScreenSwapBuffers hook): current ones are used.
void OnPresent(EGLDisplay dpy, EGLSurface surf);

// Which capture would be taken on the next presented frame: 0 none, 1 screenshot, 2 recording frame.
// (Screenshot wins; used by the exclusion layer to decide whether the frame has to be masked.)
int PlanProfile();

bool StartRecording();
bool StopRecording();
void PauseRecording();
void ResumeRecording();

}
}
