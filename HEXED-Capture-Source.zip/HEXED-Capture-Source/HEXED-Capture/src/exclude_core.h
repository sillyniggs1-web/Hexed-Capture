#pragma once
// Pure (GL-free, ImGui-free, Android-free) logic of the capture-side exclusion:
// key normalisation, mask / restore of index ranges, and the list of draw items needed to redraw the
// masked parts. Host-tested by tools/test_exclude.cpp.
#include "imgui_abi.h"
#include <ctype.h>
#include <stdio.h>
#include <string.h>

namespace hexed {
namespace xcore {

// "C:/x/monetloader/Hexed_Aim.lua" -> "hexed_aim.lua";  ".../Hud/main.lua" -> "hud/main.lua";  "win:Name" kept verbatim.
inline void NormKey(const char* in, char* out, size_t n)
{
    if (!in) in = "";
    if (!strncmp(in, "win:", 4)) { snprintf(out, n, "%s", in); return; }
    const char* s1 = nullptr; const char* s2 = nullptr;
    for (const char* p = in; *p; p++) if (*p == '/' || *p == '\\') { s2 = s1; s1 = p; }
    const char* base = s1 ? s1 + 1 : in;
    char tmp[160]; snprintf(tmp, sizeof(tmp), "%s", base);
    for (char* c = tmp; *c; c++) *c = (char)tolower((unsigned char)*c);
    if (!strcmp(tmp, "main.lua") && s1) {
        const char* d = s2 ? s2 + 1 : in;
        char dir[96]; snprintf(dir, sizeof(dir), "%.*s", (int)(s1 - d), d);
        for (char* c = dir; *c; c++) *c = (char)tolower((unsigned char)*c);
        snprintf(out, n, "%s/main.lua", dir);
    } else {
        snprintf(out, n, "%s", tmp);
    }
}

// pattern "abc*" = prefix match, otherwise exact
inline bool WinMatch(const char* pattern, const char* name)
{
    size_t l = strlen(pattern);
    if (l && pattern[l - 1] == '*') return !strncmp(pattern, name, l - 1);
    return !strcmp(pattern, name);
}

struct Range { void* list; int a, b; int backupOff; };
struct Plan {
    static const int MAXR = 160;
    Range r[MAXR]; int n; int total; bool overflow;
    void Reset() { n = 0; total = 0; overflow = false; }
    void Add(void* list, int a, int b)
    {
        if (b <= a) return;
        if (n > 0 && r[n - 1].list == list && r[n - 1].b == a) { r[n - 1].b = b; total += b - a; return; }
        if (n >= MAXR) { overflow = true; return; }
        r[n].list = list; r[n].a = a; r[n].b = b; r[n].backupOff = 0; n++; total += b - a;
    }
};

// Replace every index of the ranges by 0 (=> degenerate triangles v0,v0,v0 draw nothing). Originals go to `backup`.
// Cumulative per-command offsets of the renderer are untouched because ElemCount is not modified.
inline bool Mask(Plan* p, uint16_t* backup, int backupCap)
{
    if (p->overflow || p->total > backupCap) return false;
    int off = 0;
    for (int i = 0; i < p->n; i++) {
        Range& r = p->r[i];
        const abi::ListHead* h = (const abi::ListHead*)r.list;
        if (r.b > h->Idx.Size || !h->Idx.Data) return false;
    }
    for (int i = 0; i < p->n; i++) {
        Range& r = p->r[i];
        uint16_t* idx = (uint16_t*)((abi::ListHead*)r.list)->Idx.Data;
        memcpy(backup + off, idx + r.a, (size_t)(r.b - r.a) * 2);
        memset(idx + r.a, 0, (size_t)(r.b - r.a) * 2);
        r.backupOff = off;
        off += r.b - r.a;
    }
    return true;
}

inline void Restore(Plan* p, const uint16_t* backup)
{
    for (int i = 0; i < p->n; i++) {
        Range& r = p->r[i];
        abi::ListHead* h = (abi::ListHead*)r.list;
        if (!h->Idx.Data || r.b > h->Idx.Capacity) continue;
        memcpy((uint16_t*)h->Idx.Data + r.a, backup + r.backupOff, (size_t)(r.b - r.a) * 2);
    }
}

struct Item {
    const abi::Vert* vtx; int vtxCount;
    const uint16_t* idx; int count;
    float clip[4]; uintptr_t tex;
};

// Split the masked ranges along the command boundaries (each command has its own clip rect + texture).
// Call AFTER Restore().
inline int BuildItems(const Plan& p, const abi::CmdLayout& L, Item* out, int cap)
{
    int n = 0;
    for (int i = 0; i < p.n; i++) {
        const Range& r = p.r[i];
        const abi::ListHead* h = (const abi::ListHead*)r.list;
        int off = 0;
        for (int j = 0; j < h->Cmd.Size && off < r.b; j++) {
            const uint8_t* c = abi::CmdAt(h, L, j);
            int elem = (int)abi::CmdElem(c);
            int cs = off, ce = off + elem;
            off = ce;
            int s = cs > r.a ? cs : r.a, e = ce < r.b ? ce : r.b;
            if (e <= s || n >= cap) continue;
            Item& it = out[n++];
            uint32_t vo = abi::CmdVtxOff(c, L);
            it.vtx = (const abi::Vert*)h->Vtx.Data + vo;
            it.vtxCount = h->Vtx.Size - (int)vo;
            it.idx = (const uint16_t*)h->Idx.Data + s;
            it.count = e - s;
            abi::CmdClip(c, it.clip);
            it.tex = abi::CmdTex(c, L);
        }
    }
    return n;
}

}
}
