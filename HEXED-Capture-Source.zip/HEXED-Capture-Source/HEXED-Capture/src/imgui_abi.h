#pragma once
// Minimal ABI view of Dear ImGui 1.72 draw lists (the version found in libmonetloader.so).
// Nothing here calls into ImGui: it only reads/writes the draw-data memory ImGui already produced.
// Everything that depends on the exact struct layout is CALIBRATED at runtime (see CalibrateStride),
// and the code fails closed (no capture) when a layout cannot be confirmed.
#include <stddef.h>
#include <stdint.h>
#include <string.h>

namespace hexed {
namespace abi {

struct RawVec { int Size; int Capacity; void* Data; };           // ImVector<T>
struct ListHead { RawVec Cmd; RawVec Idx; RawVec Vtx; };        // first members of ImDrawList (stable across 1.6x-1.8x)
struct Vert { float x, y, u, v; uint32_t col; };                // ImDrawVert, 20 bytes
static_assert(sizeof(Vert) == 20, "ImDrawVert");

// ImDrawData prefix: bool Valid; ImDrawList** CmdLists; int CmdListsCount; int TotalIdxCount; int TotalVtxCount;
//                    ImVec2 DisplayPos; ImVec2 DisplaySize; ImVec2 FramebufferScale;
struct DrawData {
    bool Valid; void** CmdLists; int CmdListsCount; int TotalIdxCount; int TotalVtxCount;
    float DisplayPosX, DisplayPosY, DisplaySizeX, DisplaySizeY, FbScaleX, FbScaleY;
};

inline int AlignUp(int v, int a) { return (v + a - 1) & ~(a - 1); }

// ImDrawCmd { uint ElemCount; ImVec4 ClipRect; ImTextureID TextureId; [uint VtxOffset; [uint IdxOffset;]] UserCallback; UserCallbackData; }
struct CmdLayout { int stride; int texOff; int vtxOffOff; };    // vtxOffOff = -1 when the field does not exist

inline void Candidates(CmdLayout out[3])
{
    const int P = (int)sizeof(void*);
    const int tex = AlignUp(20, P);
    const int base = tex + P;
    out[0] = { AlignUp(base, P) + 2 * P, tex, -1 };
    out[1] = { AlignUp(base + 4, P) + 2 * P, tex, base };
    out[2] = { AlignUp(base + 8, P) + 2 * P, tex, base };
}

inline const uint8_t* CmdAt(const ListHead* h, const CmdLayout& L, int i) { return (const uint8_t*)h->Cmd.Data + (size_t)i * L.stride; }
inline uint32_t CmdElem(const uint8_t* c) { uint32_t v; memcpy(&v, c, 4); return v; }
inline void CmdClip(const uint8_t* c, float o[4]) { memcpy(o, c + 4, 16); }
inline uintptr_t CmdTex(const uint8_t* c, const CmdLayout& L) { uintptr_t t = 0; memcpy(&t, c + L.texOff, sizeof(void*)); return t; }
inline uint32_t CmdVtxOff(const uint8_t* c, const CmdLayout& L) { uint32_t v = 0; if (L.vtxOffOff >= 0) memcpy(&v, c + L.vtxOffOff, 4); return v; }

// A stride is accepted when, for every list, the sum of ElemCount over its commands equals IdxBuffer.Size.
// Lists with a single command do not discriminate (command 0 is at offset 0 for every stride):
// `multi` reports whether at least one list with >= 2 commands confirmed the choice.
inline bool CalibrateStride(void* const* lists, int n, CmdLayout* out, bool* multi)
{
    CmdLayout cand[3];
    Candidates(cand);
    for (int k = 0; k < 3; k++) {
        bool ok = true, any = false, mul = false;
        for (int i = 0; i < n && ok; i++) {
            const ListHead* h = (const ListHead*)lists[i];
            if (!h || h->Cmd.Size <= 0 || !h->Cmd.Data) continue;
            any = true;
            if (h->Cmd.Size >= 2) mul = true;
            uint64_t sum = 0;
            for (int j = 0; j < h->Cmd.Size; j++) sum += CmdElem(CmdAt(h, cand[k], j));
            if (sum != (uint64_t)h->Idx.Size) ok = false;
        }
        if (ok && any) { *out = cand[k]; *multi = mul; return true; }
    }
    return false;
}

}
}
