/*
 * Capture-side exclusion of selected Lua scripts (HEXED Capture 0.4.0).
 *
 * Idea: the scripts keep running and keep drawing on screen. Only on frames that are captured, the ImGui
 * draw data of the selected scripts is neutralised in place right after ImGui::Render (indices -> 0, i.e.
 * degenerate triangles), the native overlay renderer therefore draws everything else, the capture reads the
 * back buffer, then the indices are restored and the selected overlays are drawn on top with a small GLES2
 * renderer before the swap. The on-screen picture is unchanged (selected overlays are drawn last, i.e. on top).
 *
 * Attribution (which script produced which draw list / index range):
 *   - lua_pcall / lua_call / lua_resume slots in libmonetloader's GOT are patched; thisScript() identifies the script.
 *   - ImGui::Begin(name) while a script is running  -> window name -> script
 *   - shared Background/Foreground draw lists: index ranges produced while a script's pcall is active -> script
 * Anything that cannot be attributed makes the frame un-capturable (fail closed) instead of leaking.
 */
#include "exclude.h"
#include "capture.h"
#include "exclude_core.h"
#include "state.h"

#include <mod/amlmod.h>

#include <GLES2/gl2.h>
#include <atomic>
#include <ctype.h>
#include <dlfcn.h>
#include <elf.h>
#include <link.h>
#include <pthread.h>
#include <stdarg.h>
#include <time.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <sys/syscall.h>
#include <unistd.h>

namespace hexed {
namespace exclude {

// ===================================================================== configuration
static pthread_mutex_t g_mu = PTHREAD_MUTEX_INITIALIZER;
struct Lock { Lock() { pthread_mutex_lock(&g_mu); } ~Lock() { pthread_mutex_unlock(&g_mu); } };

struct ProfSet { char e[48][72]; int n; bool on; };
static ProfSet g_ps[3];
static bool g_failBlock = true;

static void NormKey(const char* in, char* out, size_t n) { xcore::NormKey(in, out, n); }

static bool Valid(int p) { return p == PROF_SHOT || p == PROF_REC; }
void SetEnabled(int p, bool on) { if (!Valid(p)) return; Lock l; g_ps[p].on = on; }
bool Enabled(int p) { return Valid(p) && g_ps[p].on; }
void ClearList(int p) { if (!Valid(p)) return; Lock l; g_ps[p].n = 0; }
bool AddName(int p, const char* name)
{
    if (!Valid(p) || !name || !name[0]) return false;
    char k[72]; NormKey(name, k, sizeof(k));
    Lock l;
    ProfSet& s = g_ps[p];
    for (int i = 0; i < s.n; i++) if (!strcmp(s.e[i], k)) return true;
    if (s.n >= 48) return false;
    snprintf(s.e[s.n++], 72, "%s", k);
    return true;
}
bool DelName(int p, const char* name)
{
    if (!Valid(p) || !name) return false;
    char k[72]; NormKey(name, k, sizeof(k));
    Lock l;
    ProfSet& s = g_ps[p];
    for (int i = 0; i < s.n; i++) if (!strcmp(s.e[i], k)) { memmove(s.e[i], s.e[s.n - 1], 72); s.n--; return true; }
    return false;
}
void GetList(int p, char* out, size_t n)
{
    if (!out || !n) return;
    out[0] = 0;
    if (!Valid(p)) return;
    Lock l;
    size_t used = 0;
    for (int i = 0; i < g_ps[p].n; i++) {
        int w = snprintf(out + used, n - used, "%s%s", i ? "|" : "", g_ps[p].e[i]);
        if (w < 0 || (size_t)w >= n - used) break;
        used += (size_t)w;
    }
}
void SetList(int p, const char* piped)
{
    if (!Valid(p)) return;
    ClearList(p);
    if (!piped) return;
    char buf[2400]; snprintf(buf, sizeof(buf), "%s", piped);
    for (char* t = strtok(buf, "|"); t; t = strtok(nullptr, "|")) AddName(p, t);
}
void SetFailsafeBlock(bool b) { g_failBlock = b; }
bool FailsafeBlock() { return g_failBlock; }

static bool Active(int p) { return Valid(p) && g_ps[p].on && g_ps[p].n > 0; }
bool AnyActive() { return Active(PROF_SHOT) || Active(PROF_REC); }

// ===================================================================== state
static std::atomic<bool> g_installed{false};
static volatile bool g_dead = false;            // permanent failure (reason in g_deadWhy)
static char g_deadWhy[200];
static char g_frameWhy[200];                    // transient reason (this frame could not be masked)
static std::atomic<int> g_frame{0};
static std::atomic<int> g_selfTest{0};          // 0 none, 1 request, 2 phase1 (reference frame), 3 phase2 (masked frame)
static char g_testResult[300] = "none";
static std::atomic<int> g_maskedFrames{0}, g_skips{0}, g_blocked{0}, g_leaked{0};
static std::atomic<int> g_attribMode{0};        // bit0: pcall seen, bit1: window attributed, bit2: bg/fg segment attributed

static void Die(const char* why) { if (g_dead) return; snprintf(g_deadWhy, sizeof(g_deadWhy), "%s", why); g_dead = true; HLog("exclude: UNAVAILABLE: %s", why); }

// ===================================================================== script registry
struct Script { char key[72]; int pcalls; int wins; int bgIdx, fgIdx; int maskedIdx; uint8_t ex[3]; };
static Script g_sc[64];
static int g_nsc = 0;
static pthread_mutex_t g_scMu = PTHREAD_MUTEX_INITIALIZER;

static bool KeyInSet(int p, const char* key)
{
    for (int i = 0; i < g_ps[p].n; i++) if (!strcmp(g_ps[p].e[i], key)) return true;
    return false;
}
static void FlagsFor(Script& s)
{
    Lock l;
    s.ex[PROF_SHOT] = g_ps[PROF_SHOT].on && KeyInSet(PROF_SHOT, s.key);
    s.ex[PROF_REC] = g_ps[PROF_REC].on && KeyInSet(PROF_REC, s.key);
}
static int RegisterScript(const char* path)
{
    char k[72]; NormKey(path, k, sizeof(k));
    pthread_mutex_lock(&g_scMu);
    int id = -1;
    for (int i = 0; i < g_nsc; i++) if (!strcmp(g_sc[i].key, k)) { id = i; break; }
    if (id < 0 && g_nsc < 64) {
        id = g_nsc++;
        memset(&g_sc[id], 0, sizeof(Script));
        snprintf(g_sc[id].key, sizeof(g_sc[id].key), "%s", k);
        FlagsFor(g_sc[id]);
    }
    pthread_mutex_unlock(&g_scMu);
    return id;
}
static void RefreshFlags() { for (int i = 0; i < g_nsc; i++) FlagsFor(g_sc[i]); }

// ===================================================================== LuaJIT access
struct lua_State;
static const int GLOBALSINDEX = -10002;
static int  (*lj_gettop)(lua_State*) = nullptr;
static void (*lj_settop)(lua_State*, int) = nullptr;
static void (*lj_getfield)(lua_State*, int, const char*) = nullptr;
static int  (*lj_type)(lua_State*, int) = nullptr;
static const char* (*lj_tolstring)(lua_State*, int, size_t*) = nullptr;
typedef int (*pcall_t)(lua_State*, int, int, int);
typedef void (*call_t)(lua_State*, int, int);
typedef int (*resume_t)(lua_State*, int);
static pcall_t orig_pcall = nullptr;
static call_t orig_call = nullptr;
static resume_t orig_resume = nullptr;

static __thread int t_cur = -1;                 // script id currently running on this thread (-1 unknown/native)

struct LC { lua_State* L; int id; int frame; };
static LC g_lc[256];
static pthread_mutex_t g_lcMu = PTHREAD_MUTEX_INITIALIZER;

static int Resolve(lua_State* L)    // L is RUNNING (inside lua_pcall/lua_call): safe to use the C API on it
{
    if (!lj_gettop || !orig_pcall) return -1;
    int top = lj_gettop(L);
    int id = -1;
    lj_getfield(L, GLOBALSINDEX, "thisScript");
    if (lj_type(L, -1) == 6 && orig_pcall(L, 0, 1, 0) == 0) {
        static const char* fields[] = {"path", "filename", "name", nullptr};
        for (int f = 0; fields[f] && id < 0; f++) {
            lj_getfield(L, -1, fields[f]);
            const char* s = lj_tolstring(L, -1, nullptr);
            if (s && *s) id = RegisterScript(s);
            lj_settop(L, -2);
        }
    }
    lj_settop(L, top);
    return id;
}

static int CachedId(lua_State* L, bool allowResolve)
{
    int fr = g_frame.load(std::memory_order_relaxed);
    unsigned h = (unsigned)(((uintptr_t)L) >> 4) & 255;
    pthread_mutex_lock(&g_lcMu);
    for (int i = 0; i < 8; i++) {
        LC& c = g_lc[(h + i) & 255];
        if (c.L == L && fr - c.frame < 120 && fr >= c.frame) { int id = c.id; pthread_mutex_unlock(&g_lcMu); return id; }
    }
    pthread_mutex_unlock(&g_lcMu);
    if (!allowResolve) return -2;
    int id = Resolve(L);
    pthread_mutex_lock(&g_lcMu);
    LC* slot = &g_lc[h];
    for (int i = 0; i < 8; i++) { LC& c = g_lc[(h + i) & 255]; if (c.L == L || c.L == nullptr || fr - c.frame >= 120) { slot = &c; break; } }
    slot->L = L; slot->id = id; slot->frame = fr;
    pthread_mutex_unlock(&g_lcMu);
    return id;
}

// ===================================================================== window table + list tracking
struct Win { uint32_t h; int script; int frame; char name[72]; };
static Win g_win[512];
static pthread_mutex_t g_winMu = PTHREAD_MUTEX_INITIALIZER;
static uint32_t Fnv(const char* s) { uint32_t h = 2166136261u; while (*s) { h ^= (uint8_t)*s++; h *= 16777619u; } return h ? h : 1; }

static void NoteWindow(const char* name, int script)
{
    if (!name) return;
    uint32_t h = Fnv(name);
    pthread_mutex_lock(&g_winMu);
    for (int i = 0; i < 512; i++) {
        Win& w = g_win[(h + i) & 511];
        if (w.h == 0) { w.h = h; w.script = script; snprintf(w.name, sizeof(w.name), "%s", name); w.frame = g_frame.load(); break; }
        if (w.h == h && !strcmp(w.name, name)) { if (script >= 0 || w.script < 0) w.script = script; w.frame = g_frame.load(); break; }
    }
    pthread_mutex_unlock(&g_winMu);
    if (script >= 0) { g_sc[script].wins++; g_attribMode |= 2; }
}
static bool FindWindow(const char* name, int* script)
{
    uint32_t h = Fnv(name);
    bool found = false;
    pthread_mutex_lock(&g_winMu);
    for (int i = 0; i < 512; i++) {
        Win& w = g_win[(h + i) & 511];
        if (w.h == 0) break;
        if (w.h == h && !strcmp(w.name, name)) { *script = w.script; found = true; break; }
    }
    pthread_mutex_unlock(&g_winMu);
    return found;
}

struct Seg { int script, a, b; };
struct Track { void* list; Seg seg[256]; int n; };
static Track g_bg, g_fg;
static inline int IdxSize(void* l) { return l ? ((abi::ListHead*)l)->Idx.Size : 0; }
static void AddSeg(Track& t, int script, int a, int b)
{
    if (b <= a || script < 0) return;
    if (t.n > 0 && t.seg[t.n - 1].script == script && t.seg[t.n - 1].b == a) { t.seg[t.n - 1].b = b; return; }
    if (t.n < 256) { t.seg[t.n++] = {script, a, b}; g_attribMode |= 4; }
}

// ===================================================================== ImGui + Lua hooks
static bool (*orig_Begin)(const char*, bool*, int) = nullptr;
static void (*orig_NewFrame)() = nullptr;
static void (*orig_Render)() = nullptr;
static void* (*fn_GetDrawData)() = nullptr;

static xcore::Plan g_plan;
static uint16_t* g_backup = nullptr;
static const int BACKUP_CAP = 1 << 20;
static bool g_planMasked = false;
static int  g_planProf = 0;
static int  g_planTid = 0;
static float g_planBox[4];                      // x0,y0,x1,y1 of the masked vertices (ImGui space)
static bool g_planBoxValid = false;
static abi::CmdLayout g_layout; static bool g_layoutOk = false;
static float g_dispPos[2], g_dispSize[2], g_fbScale[2];
static int g_selfPhase1Pending = 0;
// threading: ImGui is built on the game thread, drawn + presented on the render thread. The mask is applied on the
// RENDER thread at the moment the renderer fetches the draw data (igGetDrawData) and a lock is held until the present.
static std::atomic<int> g_tidPresent{0}, g_tidRender{0}, g_tidGetDD{0};
static std::atomic<int> g_getddCalls{0}, g_getddOnPresent{0};
static pthread_mutex_t g_planMu = PTHREAD_MUTEX_INITIALIZER;
static bool g_held = false;                      // this (render) thread holds g_planMu until FinishPresent
static std::atomic<bool> g_abandon{false};       // game thread had to give up waiting: do not touch the lists any more
static int g_lastFinishedFrame = -1, g_maskedFrameNo = -1;
static void* (*orig_GetDrawData)() = nullptr;

static inline int Tid() { return (int)syscall(SYS_gettid); }

static void RestoreMask()
{
    if (!g_planMasked) return;
    xcore::Restore(&g_plan, g_backup);
    // (g_planMasked stays true until the redraw ran: FinishPresent clears it)
}

static int hk_pcall(lua_State* L, int a, int b, int c)
{
    int prev = t_cur;
    int id = CachedId(L, true);
    t_cur = id;
    bool boundary = (id != prev);
    int s0 = 0, s1 = 0;
    if (boundary && id >= 0) { s0 = IdxSize(g_bg.list); s1 = IdxSize(g_fg.list); g_sc[id].pcalls++; g_attribMode |= 1; }
    int r = orig_pcall(L, a, b, c);
    if (boundary && id >= 0) {
        int e0 = IdxSize(g_bg.list), e1 = IdxSize(g_fg.list);
        if (e0 > s0) { AddSeg(g_bg, id, s0, e0); g_sc[id].bgIdx += e0 - s0; }
        if (e1 > s1) { AddSeg(g_fg, id, s1, e1); g_sc[id].fgIdx += e1 - s1; }
    }
    t_cur = prev;
    return r;
}
static void hk_call(lua_State* L, int a, int b)
{
    int prev = t_cur;
    int id = CachedId(L, true);
    t_cur = id;
    bool boundary = (id != prev);
    int s0 = 0, s1 = 0;
    if (boundary && id >= 0) { s0 = IdxSize(g_bg.list); s1 = IdxSize(g_fg.list); g_sc[id].pcalls++; }
    orig_call(L, a, b);
    if (boundary && id >= 0) {
        int e0 = IdxSize(g_bg.list), e1 = IdxSize(g_fg.list);
        if (e0 > s0) { AddSeg(g_bg, id, s0, e0); g_sc[id].bgIdx += e0 - s0; }
        if (e1 > s1) { AddSeg(g_fg, id, s1, e1); g_sc[id].fgIdx += e1 - s1; }
    }
    t_cur = prev;
}
static int hk_resume(lua_State* L, int n)
{
    // L is a suspended coroutine here: never touch its stack, only use an already known identity
    int prev = t_cur;
    int id = CachedId(L, false);
    if (id >= 0) t_cur = id;
    int r = orig_resume(L, n);
    t_cur = prev;
    return r;
}
static bool hk_Begin(const char* name, bool* open, int flags)
{
    NoteWindow(name, t_cur);
    return orig_Begin(name, open, flags);
}
static bool Split() { int pt = g_tidPresent.load(); return pt != 0 && pt != g_tidRender.load(); }

static void hk_NewFrame()
{
    g_tidRender.store(Tid());
    if (Split()) {
        // the render thread may still own the masked lists of the previous frame: wait for its present (bounded)
        struct timespec ts; clock_gettime(CLOCK_REALTIME, &ts);
        ts.tv_nsec += 200 * 1000000L; if (ts.tv_nsec >= 1000000000L) { ts.tv_sec++; ts.tv_nsec -= 1000000000L; }
        if (pthread_mutex_timedlock(&g_planMu, &ts) == 0) {
            if (g_planMasked) { RestoreMask(); g_planMasked = false; g_leaked++; }
            pthread_mutex_unlock(&g_planMu);
        } else { g_abandon.store(true); g_leaked++; HLog("exclude: render thread held the mask for >200 ms; abandoning it"); }
    } else if (g_planMasked) {
        RestoreMask(); g_planMasked = false; g_leaked++;
        HLog("exclude: frame ended without a present on the game surface; mask restored (excluded overlays missed one frame)");
    }
    g_frame.fetch_add(1);
    g_bg.n = 0; g_fg.n = 0;
    orig_NewFrame();
}
static void hk_Render()
{
    orig_Render();
    OnRenderDone();
}

// ===================================================================== safe string read
static bool SafeStr(const void* p, char* out, size_t n)
{
    if (!p || ((uintptr_t)p) < 4096) return false;
    uintptr_t a = (uintptr_t)p & ~(uintptr_t)4095;
    unsigned char vec[2];
    if (mincore((void*)a, 4096, vec) != 0) return false;
    size_t room = 4096 - ((uintptr_t)p - a);
    if (room < n) { if (mincore((void*)(a + 4096), 4096, vec) != 0) n = room; }
    size_t i = 0;
    for (; i + 1 < n; i++) { char c = ((const char*)p)[i]; out[i] = c; if (!c) return i > 0; if ((unsigned char)c < 32) return false; }
    out[i] = 0;
    return true;
}
static bool OwnerOf(void* list, char* out, size_t n)
{
    // ImDrawList: ListHead, int Flags, const ImDrawListSharedData* _Data, const char* _OwnerName
    const int P = (int)sizeof(void*);
    size_t off = sizeof(abi::ListHead) + (size_t)abi::AlignUp(4, P) + (size_t)P;
    const void* s = nullptr;
    memcpy(&s, (const uint8_t*)list + off, sizeof(void*));
    return SafeStr(s, out, n);
}

// ===================================================================== plan building (render thread, ImGui::Render hook)
static void FrameFail(const char* fmt, ...) __attribute__((format(printf, 1, 2)));
static void FrameFail(const char* fmt, ...)
{
    va_list ap; va_start(ap, fmt); vsnprintf(g_frameWhy, sizeof(g_frameWhy), fmt, ap); va_end(ap);
}

static bool WinExcluded(int prof, const char* name)
{
    Lock l;
    for (int i = 0; i < g_ps[prof].n; i++)
        if (!strncmp(g_ps[prof].e[i], "win:", 4) && xcore::WinMatch(g_ps[prof].e[i] + 4, name)) return true;
    return false;
}

static void FindSharedLists(abi::DrawData* dd)
{
    for (int i = 0; i < dd->CmdListsCount; i++) {
        char nm[64];
        if (!OwnerOf(dd->CmdLists[i], nm, sizeof(nm))) continue;
        if (!strcmp(nm, "##Background")) g_bg.list = dd->CmdLists[i];
        else if (!strcmp(nm, "##Foreground")) g_fg.list = dd->CmdLists[i];
    }
}

static bool BuildPlan(int prof, abi::DrawData* dd)
{
    g_plan.Reset();
    g_planBoxValid = false;
    if (!dd->Valid || dd->CmdListsCount <= 0 || dd->CmdListsCount > 256 || !dd->CmdLists) { FrameFail("no valid draw data"); return false; }

    // layout of ImDrawCmd (needed only when a list has >= 2 commands)
    bool multi = false;
    for (int i = 0; i < dd->CmdListsCount; i++) if (((abi::ListHead*)dd->CmdLists[i])->Cmd.Size >= 2) multi = true;
    if (!g_layoutOk) {
        abi::CmdLayout L; bool strong = false;
        if (abi::CalibrateStride(dd->CmdLists, dd->CmdListsCount, &L, &strong) && (strong || !multi)) {
            if (strong) { g_layout = L; g_layoutOk = true; HLog("exclude: ImDrawCmd stride %d (VtxOffset %s) confirmed", L.stride, L.vtxOffOff >= 0 ? "yes" : "no"); }
            else g_layout = L;   // no multi-command list this frame: stride irrelevant, keep provisional
        } else if (multi) { FrameFail("ImDrawCmd layout could not be confirmed"); return false; }
    }
    if (multi && !g_layoutOk) { FrameFail("ImDrawCmd layout not confirmed"); return false; }

    FindSharedLists(dd);
    int unresolved = 0; char firstUnres[64] = "";
    for (int i = 0; i < dd->CmdListsCount; i++) {
        void* list = dd->CmdLists[i];
        abi::ListHead* h = (abi::ListHead*)list;
        if (h->Idx.Size <= 0) continue;
        char nm[64];
        if (!OwnerOf(list, nm, sizeof(nm))) { unresolved++; continue; }
        bool shared = !strcmp(nm, "##Background") || !strcmp(nm, "##Foreground");
        if (shared) {
            Track& t = !strcmp(nm, "##Background") ? g_bg : g_fg;
            for (int s = 0; s < t.n; s++) if (g_sc[t.seg[s].script].ex[prof]) { g_plan.Add(list, t.seg[s].a, t.seg[s].b); g_sc[t.seg[s].script].maskedIdx += t.seg[s].b - t.seg[s].a; }
            continue;
        }
        int sc = -1;
        if (!FindWindow(nm, &sc)) { unresolved++; if (!firstUnres[0]) snprintf(firstUnres, sizeof(firstUnres), "%s", nm); continue; }
        bool ex = (sc >= 0 && g_sc[sc].ex[prof]) || WinExcluded(prof, nm);
        if (ex) { g_plan.Add(list, 0, h->Idx.Size); if (sc >= 0) g_sc[sc].maskedIdx += h->Idx.Size; }
    }
    if (unresolved) { FrameFail("%d draw list(s) could not be attributed (first: '%s')", unresolved, firstUnres); return false; }
    if (g_plan.overflow) { FrameFail("too many excluded ranges"); return false; }

    // sanity: indices must fit 16 bit and point inside their vertex buffer (otherwise ImDrawIdx is not 16 bit)
    for (int i = 0; i < g_plan.n; i++) {
        abi::ListHead* h = (abi::ListHead*)g_plan.r[i].list;
        if (h->Vtx.Size > 65535) { FrameFail("ImDrawIdx is not 16 bit"); return false; }
        const uint16_t* idx = (const uint16_t*)h->Idx.Data;
        for (int k = g_plan.r[i].a; k < g_plan.r[i].b; k++) if (idx[k] >= h->Vtx.Size) { FrameFail("index out of range (ImDrawIdx not 16 bit?)"); return false; }
    }

    // bounding box of what will be removed (used by the self-test)
    float bx0 = 1e30f, by0 = 1e30f, bx1 = -1e30f, by1 = -1e30f; bool any = false;
    for (int i = 0; i < g_plan.n; i++) {
        abi::ListHead* h = (abi::ListHead*)g_plan.r[i].list;
        const uint16_t* idx = (const uint16_t*)h->Idx.Data; const abi::Vert* v = (const abi::Vert*)h->Vtx.Data;
        for (int k = g_plan.r[i].a; k < g_plan.r[i].b; k++) {
            const abi::Vert& p = v[idx[k]];
            if (p.x < bx0) bx0 = p.x; if (p.y < by0) by0 = p.y; if (p.x > bx1) bx1 = p.x; if (p.y > by1) by1 = p.y; any = true;
        }
    }
    if (any) { g_planBox[0] = bx0; g_planBox[1] = by0; g_planBox[2] = bx1; g_planBox[3] = by1; g_planBoxValid = true; }
    return true;
}

static bool PlanAndMask(abi::DrawData* dd)
{
    int prof = capture::PlanProfile();
    int test = g_selfTest.load();
    if (test == 1) { g_selfTest = 2; test = 2; g_selfPhase1Pending = 1; }
    else if (test == 2 && !g_selfPhase1Pending) { g_selfTest = 3; test = 3; }
    bool testMask = (test == 3);
    if (testMask) prof = PROF_SHOT;
    if (!prof || !dd) return false;
    if (!testMask && !Active(prof)) return false;
    if (testMask && !Active(PROF_SHOT)) { snprintf(g_testResult, sizeof(g_testResult), "FAIL: select at least one script and enable exclusion for screenshots first"); g_selfTest = 0; return false; }

    RefreshFlags();
    g_frameWhy[0] = 0;
    if (!BuildPlan(prof, dd)) return false;
    if (!g_backup) g_backup = (uint16_t*)malloc((size_t)BACKUP_CAP * 2);
    if (!g_backup) { FrameFail("out of memory"); return false; }
    if (!xcore::Mask(&g_plan, g_backup, BACKUP_CAP)) { FrameFail("could not mask (range check)"); return false; }
    g_dispPos[0] = dd->DisplayPosX; g_dispPos[1] = dd->DisplayPosY;
    g_dispSize[0] = dd->DisplaySizeX; g_dispSize[1] = dd->DisplaySizeY;
    g_fbScale[0] = dd->FbScaleX > 0 ? dd->FbScaleX : 1.f; g_fbScale[1] = dd->FbScaleY > 0 ? dd->FbScaleY : 1.f;
    g_planProf = prof; g_planTid = Tid(); g_planMasked = true;
    g_maskedFrameNo = g_frame.load();
    g_maskedFrames++;
    return true;
}

// Called by the renderer (render thread) every time it fetches the draw data. Masks at most once per frame, and only
// on the thread that presents; the lock stays held until FinishPresent() so the game thread cannot touch the lists.
static void* hk_GetDrawData()
{
    void* r = orig_GetDrawData();
    int me = Tid();
    g_getddCalls++;
    if (!g_tidGetDD.load()) g_tidGetDD.store(me);
    if (me != g_tidPresent.load() || !g_installed.load() || g_dead || !r) return r;
    g_getddOnPresent++;
    int fr = g_frame.load();
    if (g_held || fr == g_maskedFrameNo || fr == g_lastFinishedFrame) return r;
    if (g_abandon.load() && !g_held) g_abandon.store(false);     // stale flag from a previous give-up
    if (!Split()) return r;                                       // same thread: OnRenderDone masks
    if (!AnyActive() && g_selfTest.load() == 0) return r;
    pthread_mutex_lock(&g_planMu);
    if (PlanAndMask((abi::DrawData*)r)) { g_held = true; }       // keep the lock until FinishPresent
    else pthread_mutex_unlock(&g_planMu);
    return r;
}

void OnRenderDone()
{
    if (!g_installed.load(std::memory_order_relaxed) || g_dead) return;
    g_tidRender.store(Tid());
    if (g_planMasked && !Split()) { RestoreMask(); g_planMasked = false; }    // never stack two masks (single-thread mode)
    if (!fn_GetDrawData) return;
    abi::DrawData* dd = (abi::DrawData*)fn_GetDrawData();
    static int s_tick = 0;
    if (dd && AnyActive() && ((s_tick++ & 31) == 0 || !g_bg.list)) FindSharedLists(dd);
    // single-thread mode: Render, renderer and present share a thread -> mask right here
    int pt = g_tidPresent.load();
    if (pt != 0 && pt == Tid() && dd) PlanAndMask(dd);
}

// ===================================================================== gate
void BlockReason(char* out, size_t n)
{
    if (g_dead) snprintf(out, n, "exclusion unavailable: %s", g_deadWhy);
    else if (!g_installed.load()) snprintf(out, n, "exclusion hooks not installed yet (they install ~25 s after start, once MonetLoader is up)");
    else snprintf(out, n, "exclusion could not mask this frame: %s", g_frameWhy[0] ? g_frameWhy : "render hook not reached");
}

Gate GateCapture(int prof)
{
    if (!Active(prof)) return GATE_OPEN;
    if (g_planMasked && g_planProf == prof && g_planTid == Tid()) { g_skips = 0; return GATE_OPEN; }
    if (!g_failBlock) {
        if (g_leaked++ < 3) HLog("exclude: failsafe=allow -> capture proceeds WITHOUT exclusion (%s)", g_dead ? g_deadWhy : g_frameWhy);
        return GATE_OPEN;
    }
    if (g_dead) { g_blocked++; return GATE_BLOCK; }
    if (++g_skips > 90) {
        if (Split() && g_getddOnPresent.load() == 0 && !g_frameWhy[0])
            snprintf(g_frameWhy, sizeof(g_frameWhy), "the render thread never fetches the draw data through igGetDrawData (render=%d present=%d getdd=%d)", g_tidRender.load(), g_tidPresent.load(), g_tidGetDD.load());
        g_skips = 0; g_blocked++; return GATE_BLOCK;
    }
    return GATE_SKIP;
}

bool NeedsFinish() { return g_planMasked || g_selfPhase1Pending || g_held; }
void NotePresentThread() { static __thread int me = 0; if (!me) me = Tid(); g_tidPresent.store(me); }

// ===================================================================== GLES2 redraw of the excluded parts
static GLuint g_prog = 0, g_locProj = -1, g_locTex = -1, g_aPos = 0, g_aUV = 0, g_aCol = 0;
static bool g_glFailed = false;

static GLuint Compile(GLenum type, const char* src)
{
    GLuint s = glCreateShader(type);
    glShaderSource(s, 1, &src, nullptr);
    glCompileShader(s);
    GLint ok = 0; glGetShaderiv(s, GL_COMPILE_STATUS, &ok);
    if (!ok) { glDeleteShader(s); return 0; }
    return s;
}
static bool EnsureProgram()
{
    if (g_prog) return true;
    if (g_glFailed) return false;
    static const char* vs = "uniform mat4 ProjMtx;attribute vec2 Position;attribute vec2 UV;attribute vec4 Color;"
                            "varying vec2 Frag_UV;varying vec4 Frag_Color;void main(){Frag_UV=UV;Frag_Color=Color;gl_Position=ProjMtx*vec4(Position.xy,0.0,1.0);}";
    static const char* fs = "precision mediump float;uniform sampler2D Texture;varying vec2 Frag_UV;varying vec4 Frag_Color;"
                            "void main(){gl_FragColor=Frag_Color*texture2D(Texture,Frag_UV.st);}";
    GLuint v = Compile(GL_VERTEX_SHADER, vs), f = Compile(GL_FRAGMENT_SHADER, fs);
    if (!v || !f) { g_glFailed = true; Die("overlay shader failed to compile"); return false; }
    GLuint p = glCreateProgram();
    glAttachShader(p, v); glAttachShader(p, f); glLinkProgram(p);
    GLint ok = 0; glGetProgramiv(p, GL_LINK_STATUS, &ok);
    if (!ok) { g_glFailed = true; Die("overlay shader failed to link"); return false; }
    g_locProj = glGetUniformLocation(p, "ProjMtx"); g_locTex = glGetUniformLocation(p, "Texture");
    g_aPos = (GLuint)glGetAttribLocation(p, "Position"); g_aUV = (GLuint)glGetAttribLocation(p, "UV"); g_aCol = (GLuint)glGetAttribLocation(p, "Color");
    g_prog = p;
    return true;
}

struct GlState {
    GLint prog, abuf, ebuf, atex, tex, vp[4], sc[4], fbo;
    GLboolean blend, cull, depth, scissor, stencil, cmask[4];
    GLint beqRGB, beqA, bsrcRGB, bdstRGB, bsrcA, bdstA;
    struct Attr { GLint en, size, type, norm, stride, buf; void* ptr; } at[4];
};
static void SaveGl(GlState& s)
{
    glGetIntegerv(GL_CURRENT_PROGRAM, &s.prog); glGetIntegerv(GL_ARRAY_BUFFER_BINDING, &s.abuf); glGetIntegerv(GL_ELEMENT_ARRAY_BUFFER_BINDING, &s.ebuf);
    glGetIntegerv(GL_ACTIVE_TEXTURE, &s.atex); glGetIntegerv(GL_TEXTURE_BINDING_2D, &s.tex);
    glGetIntegerv(GL_VIEWPORT, s.vp); glGetIntegerv(GL_SCISSOR_BOX, s.sc); glGetIntegerv(GL_FRAMEBUFFER_BINDING, &s.fbo);
    s.blend = glIsEnabled(GL_BLEND); s.cull = glIsEnabled(GL_CULL_FACE); s.depth = glIsEnabled(GL_DEPTH_TEST);
    s.scissor = glIsEnabled(GL_SCISSOR_TEST); s.stencil = glIsEnabled(GL_STENCIL_TEST); glGetBooleanv(GL_COLOR_WRITEMASK, s.cmask);
    glGetIntegerv(GL_BLEND_EQUATION_RGB, &s.beqRGB); glGetIntegerv(GL_BLEND_EQUATION_ALPHA, &s.beqA);
    glGetIntegerv(GL_BLEND_SRC_RGB, &s.bsrcRGB); glGetIntegerv(GL_BLEND_DST_RGB, &s.bdstRGB);
    glGetIntegerv(GL_BLEND_SRC_ALPHA, &s.bsrcA); glGetIntegerv(GL_BLEND_DST_ALPHA, &s.bdstA);
    for (int i = 0; i < 4; i++) {
        glGetVertexAttribiv(i, GL_VERTEX_ATTRIB_ARRAY_ENABLED, &s.at[i].en);
        glGetVertexAttribiv(i, GL_VERTEX_ATTRIB_ARRAY_SIZE, &s.at[i].size);
        glGetVertexAttribiv(i, GL_VERTEX_ATTRIB_ARRAY_TYPE, &s.at[i].type);
        glGetVertexAttribiv(i, GL_VERTEX_ATTRIB_ARRAY_NORMALIZED, &s.at[i].norm);
        glGetVertexAttribiv(i, GL_VERTEX_ATTRIB_ARRAY_STRIDE, &s.at[i].stride);
        glGetVertexAttribiv(i, GL_VERTEX_ATTRIB_ARRAY_BUFFER_BINDING, &s.at[i].buf);
        glGetVertexAttribPointerv(i, GL_VERTEX_ATTRIB_ARRAY_POINTER, &s.at[i].ptr);
    }
    while (glGetError() != GL_NO_ERROR) {}
}
static void LoadGl(const GlState& s)
{
    glUseProgram(s.prog);
    glBindFramebuffer(GL_FRAMEBUFFER, (GLuint)s.fbo);
    for (int i = 0; i < 4; i++) {
        glBindBuffer(GL_ARRAY_BUFFER, (GLuint)s.at[i].buf);
        glVertexAttribPointer(i, s.at[i].size, (GLenum)s.at[i].type, (GLboolean)s.at[i].norm, s.at[i].stride, s.at[i].ptr);
        if (s.at[i].en) glEnableVertexAttribArray(i); else glDisableVertexAttribArray(i);
    }
    glBindBuffer(GL_ARRAY_BUFFER, (GLuint)s.abuf); glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, (GLuint)s.ebuf);
    glActiveTexture((GLenum)s.atex); glBindTexture(GL_TEXTURE_2D, (GLuint)s.tex);
    glViewport(s.vp[0], s.vp[1], s.vp[2], s.vp[3]); glScissor(s.sc[0], s.sc[1], s.sc[2], s.sc[3]);
    glBlendEquationSeparate((GLenum)s.beqRGB, (GLenum)s.beqA);
    glBlendFuncSeparate((GLenum)s.bsrcRGB, (GLenum)s.bdstRGB, (GLenum)s.bsrcA, (GLenum)s.bdstA);
    glColorMask(s.cmask[0], s.cmask[1], s.cmask[2], s.cmask[3]);
    (s.blend ? glEnable : glDisable)(GL_BLEND); (s.cull ? glEnable : glDisable)(GL_CULL_FACE);
    (s.depth ? glEnable : glDisable)(GL_DEPTH_TEST); (s.scissor ? glEnable : glDisable)(GL_SCISSOR_TEST);
    (s.stencil ? glEnable : glDisable)(GL_STENCIL_TEST);
}

static bool Redraw(int fbW, int fbH)
{
    static xcore::Item items[1024];
    int n = xcore::BuildItems(g_plan, g_layout, items, 1024);
    if (n == 0) return true;
    if (!EnsureProgram()) return false;
    GlState st; SaveGl(st);
    glBindFramebuffer(GL_FRAMEBUFFER, 0);
    glViewport(0, 0, fbW, fbH);
    glEnable(GL_BLEND); glBlendEquation(GL_FUNC_ADD);
    glBlendFuncSeparate(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA, GL_ONE, GL_ONE_MINUS_SRC_ALPHA);
    glDisable(GL_CULL_FACE); glDisable(GL_DEPTH_TEST); glDisable(GL_STENCIL_TEST); glEnable(GL_SCISSOR_TEST);
    glColorMask(GL_TRUE, GL_TRUE, GL_TRUE, GL_TRUE);
    float L = g_dispPos[0], R = L + g_dispSize[0], T = g_dispPos[1], B = T + g_dispSize[1];
    const float m[16] = {2.f / (R - L), 0, 0, 0, 0, 2.f / (T - B), 0, 0, 0, 0, -1.f, 0, (R + L) / (L - R), (T + B) / (B - T), 0, 1.f};
    glUseProgram(g_prog);
    glUniform1i(g_locTex, 0); glUniformMatrix4fv(g_locProj, 1, GL_FALSE, m);
    glActiveTexture(GL_TEXTURE0);
    glBindBuffer(GL_ARRAY_BUFFER, 0); glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, 0);
    glEnableVertexAttribArray(g_aPos); glEnableVertexAttribArray(g_aUV); glEnableVertexAttribArray(g_aCol);
    bool ok = true;
    for (int i = 0; i < n; i++) {
        const xcore::Item& it = items[i];
        float cx0 = (it.clip[0] - g_dispPos[0]) * g_fbScale[0], cy0 = (it.clip[1] - g_dispPos[1]) * g_fbScale[1];
        float cx1 = (it.clip[2] - g_dispPos[0]) * g_fbScale[0], cy1 = (it.clip[3] - g_dispPos[1]) * g_fbScale[1];
        if (cx1 <= cx0 || cy1 <= cy0 || cx1 < 0 || cy1 < 0 || cx0 > fbW || cy0 > fbH) continue;
        GLuint tex = (GLuint)it.tex;
        if (!glIsTexture(tex)) { ok = false; continue; }
        glBindTexture(GL_TEXTURE_2D, tex);
        glScissor((GLint)cx0, (GLint)(fbH - cy1), (GLsizei)(cx1 - cx0), (GLsizei)(cy1 - cy0));
        const abi::Vert* v = it.vtx;
        glVertexAttribPointer(g_aPos, 2, GL_FLOAT, GL_FALSE, sizeof(abi::Vert), &v->x);
        glVertexAttribPointer(g_aUV, 2, GL_FLOAT, GL_FALSE, sizeof(abi::Vert), &v->u);
        glVertexAttribPointer(g_aCol, 4, GL_UNSIGNED_BYTE, GL_TRUE, sizeof(abi::Vert), &v->col);
        glDrawElements(GL_TRIANGLES, it.count, GL_UNSIGNED_SHORT, it.idx);
    }
    glDisableVertexAttribArray(g_aPos); glDisableVertexAttribArray(g_aUV); glDisableVertexAttribArray(g_aCol);
    LoadGl(st);
    return ok;
}

// ===================================================================== self-test
static uint8_t* g_tA = nullptr; static uint8_t* g_tC = nullptr; static uint8_t* g_tS = nullptr; static size_t g_tCap = 0;
static void ReadFb(uint8_t* dst, int w, int h)
{
    GLint fbo = 0, al = 4;
    glGetIntegerv(GL_FRAMEBUFFER_BINDING, &fbo); glGetIntegerv(GL_PACK_ALIGNMENT, &al);
    if (fbo) glBindFramebuffer(GL_FRAMEBUFFER, 0);
    glPixelStorei(GL_PACK_ALIGNMENT, 4);
    glReadPixels(0, 0, w, h, GL_RGBA, GL_UNSIGNED_BYTE, dst);
    glPixelStorei(GL_PACK_ALIGNMENT, al);
    if (fbo) glBindFramebuffer(GL_FRAMEBUFFER, (GLuint)fbo);
}
static bool TestBuffers(int w, int h)
{
    size_t need = (size_t)w * h * 4;
    if (need > g_tCap) {
        free(g_tA); free(g_tC); free(g_tS);
        g_tA = (uint8_t*)malloc(need); g_tC = (uint8_t*)malloc(need); g_tS = (uint8_t*)malloc(need);
        g_tCap = (g_tA && g_tC && g_tS) ? need : 0;
    }
    return g_tCap >= need;
}
static inline bool Differs(const uint8_t* a, const uint8_t* b)
{
    return abs(a[0] - b[0]) > 24 || abs(a[1] - b[1]) > 24 || abs(a[2] - b[2]) > 24;
}

static void SelfTestPhase1(int w, int h)
{
    if (!TestBuffers(w, h)) { snprintf(g_testResult, sizeof(g_testResult), "FAIL: out of memory"); g_selfTest = 0; g_selfPhase1Pending = 0; return; }
    ReadFb(g_tA, w, h);          // reference frame: nothing masked, everything native
    g_selfPhase1Pending = 0;
}
static void SelfTestPhase2(int w, int h, bool redrawOk)
{
    if (!TestBuffers(w, h)) { snprintf(g_testResult, sizeof(g_testResult), "FAIL: out of memory"); g_selfTest = 0; return; }
    // the capture-equivalent image was read by the caller into g_tC, the on-screen image is read now into g_tS
    ReadFb(g_tS, w, h);
    int x0 = 0, y0 = 0, x1 = 0, y1 = 0;
    if (g_planBoxValid) {
        float sx = g_fbScale[0], sy = g_fbScale[1];
        x0 = (int)((g_planBox[0] - g_dispPos[0]) * sx); x1 = (int)((g_planBox[2] - g_dispPos[0]) * sx) + 1;
        int ty0 = (int)((g_planBox[1] - g_dispPos[1]) * sy), ty1 = (int)((g_planBox[3] - g_dispPos[1]) * sy) + 1;
        y0 = h - ty1; y1 = h - ty0;
        if (x0 < 0) x0 = 0; if (y0 < 0) y0 = 0; if (x1 > w) x1 = w; if (y1 > h) y1 = h;
    }
    long inDiff = 0, outDiff = 0, inMatch = 0, inCnt = 0;
    for (int y = 0; y < h; y++) for (int x = 0; x < w; x++) {
        size_t o = ((size_t)y * w + x) * 4;
        bool in = x >= x0 && x < x1 && y >= y0 && y < y1;
        bool d = Differs(g_tC + o, g_tS + o);
        if (in) { inCnt++; if (d) inDiff++; if (!Differs(g_tA + o, g_tS + o)) inMatch++; } else if (d) outDiff++;
    }
    long total = (long)w * h;
    bool hidden = inDiff >= 30;
    bool clean = outDiff * 10000 <= total;      // <= 0.01 %
    double match = inCnt ? 100.0 * inMatch / inCnt : 0.0;
    char who[160]; GetList(PROF_SHOT, who, sizeof(who));
    snprintf(g_testResult, sizeof(g_testResult),
             "%s: removed-from-capture=%ld px (need>=30), changed-outside=%ld px (need<=%ld), screen-vs-native-in-box=%.0f%% (advisory, static scene), redraw=%s, box=%dx%d, set=%s",
             (hidden && clean && redrawOk) ? "PASS" : "FAIL", inDiff, outDiff, total / 10000, match, redrawOk ? "ok" : "ERROR", x1 - x0, y1 - y0, who);
    HLog("exclude selftest: %s", g_testResult);
    g_selfTest = 0;
}

void FinishPresent(bool onGame, int w, int h)
{
    if (g_selfPhase1Pending && onGame) SelfTestPhase1(w, h);
    if (!g_planMasked) {
        if (g_held) { g_held = false; pthread_mutex_unlock(&g_planMu); }
        return;
    }
    if (!onGame) return;                 // keep the mask (and the lock) until the game surface is presented
    bool test = (g_selfTest.load() == 3);
    if (g_abandon.load()) {              // the game thread gave up on us: the lists are no longer ours
        g_abandon.store(false); g_planMasked = false;
        if (g_held) { g_held = false; pthread_mutex_unlock(&g_planMu); }
        return;
    }
    if (test && TestBuffers(w, h)) ReadFb(g_tC, w, h);       // identical to what the capture saw
    RestoreMask();
    bool ok = Redraw(w, h);
    if (!ok) { static int bad = 0; if (++bad > 5) Die("redraw of excluded overlays failed repeatedly (texture ids are not GL textures?)"); }
    g_planMasked = false;
    g_lastFinishedFrame = g_frame.load();
    if (g_held) { g_held = false; pthread_mutex_unlock(&g_planMu); }
    if (test) SelfTestPhase2(w, h, ok);
}

void RequestSelfTest()
{
    if (!g_installed.load()) { snprintf(g_testResult, sizeof(g_testResult), "FAIL: hooks not installed (%s)", g_dead ? g_deadWhy : "wait ~25 s after start"); return; }
    snprintf(g_testResult, sizeof(g_testResult), "running");
    g_selfTest = 1;
}

// ===================================================================== install
static uintptr_t FollowStub(uintptr_t exp)
{
    uintptr_t a = exp & ~(uintptr_t)1;
    uint16_t h1 = *(uint16_t*)a, h2 = *(uint16_t*)(a + 2);
    if ((h1 & 0xF800) != 0xF000 || (h2 & 0xD000) != 0x9000) return 0;
    int S = (h1 >> 10) & 1, J1 = (h2 >> 13) & 1, J2 = (h2 >> 11) & 1;
    int I1 = ~(J1 ^ S) & 1, I2 = ~(J2 ^ S) & 1;
    int32_t imm = (S << 24) | (I1 << 23) | (I2 << 22) | ((h1 & 0x3FF) << 12) | ((h2 & 0x7FF) << 1);
    if (S) imm -= (1 << 25);
    return (uintptr_t)((int32_t)(a + 4) + imm) | 1;
}

static bool PatchGot(uintptr_t base, const char* sym, void* fn, void** origOut)
{
    const Elf32_Ehdr* eh = (const Elf32_Ehdr*)base;
    const Elf32_Phdr* ph = (const Elf32_Phdr*)(base + eh->e_phoff);
    const Elf32_Dyn* dyn = nullptr;
    for (int i = 0; i < eh->e_phnum; i++) if (ph[i].p_type == PT_DYNAMIC) dyn = (const Elf32_Dyn*)(base + ph[i].p_vaddr);
    if (!dyn) return false;
    const Elf32_Sym* symtab = nullptr; const char* strtab = nullptr;
    const Elf32_Rel *jmprel = nullptr, *rel = nullptr; size_t jmprelsz = 0, relsz = 0;
    for (const Elf32_Dyn* d = dyn; d->d_tag != DT_NULL; d++) {
        switch (d->d_tag) {
            case DT_SYMTAB: symtab = (const Elf32_Sym*)(base + d->d_un.d_ptr); break;
            case DT_STRTAB: strtab = (const char*)(base + d->d_un.d_ptr); break;
            case DT_JMPREL: jmprel = (const Elf32_Rel*)(base + d->d_un.d_ptr); break;
            case DT_PLTRELSZ: jmprelsz = d->d_un.d_val; break;
            case DT_REL: rel = (const Elf32_Rel*)(base + d->d_un.d_ptr); break;
            case DT_RELSZ: relsz = d->d_un.d_val; break;
        }
    }
    if (!symtab || !strtab) return false;
    const Elf32_Rel* tabs[2] = {jmprel, rel};
    size_t sizes[2] = {jmprelsz, relsz};
    bool done = false;
    for (int t = 0; t < 2; t++)
        for (size_t i = 0; tabs[t] && i < sizes[t] / sizeof(Elf32_Rel); i++) {
            const Elf32_Rel& r = tabs[t][i];
            int type = ELF32_R_TYPE(r.r_info);
            if (type != 22 && type != 21) continue;
            if (strcmp(strtab + symtab[ELF32_R_SYM(r.r_info)].st_name, sym) != 0) continue;
            void** slot = (void**)(base + r.r_offset);
            uintptr_t page = (uintptr_t)slot & ~(uintptr_t)4095;
            if (mprotect((void*)page, 4096, PROT_READ | PROT_WRITE) != 0) return false;
            if (!*origOut) *origOut = *slot;
            *slot = fn;
            done = true;
        }
    return done;
}

bool Installed() { return g_installed.load(); }
bool WantInstall() { return !g_dead && (AnyActive() || g_selfTest.load() != 0 || Enabled(PROF_SHOT) || Enabled(PROF_REC)); }

// ---- crash guard: hooks installed -> marker; crash within 20 s -> exclusion stays disabled until reset
static char* GuardPath(const char* name, char* buf, size_t n) { snprintf(buf, n, "%s/%s", DataDir(), name); return buf; }
static int64_t g_installedUs = 0;
void LoadCrashGuard()
{
    char p[640];
    if (access(GuardPath("hexed_capture.exdisabled", p, sizeof(p)), F_OK) == 0)
        Die("disabled after a crash right after the hooks were installed (use '/hxdcap exreset' or delete hexed_capture.exdisabled, then restart)");
}
void ResetCrashGuard()
{
    char p[640];
    remove(GuardPath("hexed_capture.exdisabled", p, sizeof(p)));
    remove(GuardPath("hexed_capture.exinstalling", p, sizeof(p)));
    HLog("exclude: crash guard reset (restart the game to use exclusion)");
}
void OnSurvived()
{
    char p[640];
    if (g_installedUs && NowUs() - g_installedUs > 20LL * 1000000) remove(GuardPath("hexed_capture.exinstalling", p, sizeof(p)));
}
void OnGameCrash()
{
    char p[640], q[640];
    GuardPath("hexed_capture.exinstalling", p, sizeof(p));
    if (g_installedUs && NowUs() - g_installedUs < 20LL * 1000000) {
        FILE* f = fopen(GuardPath("hexed_capture.exdisabled", q, sizeof(q)), "w");
        if (f) { fputs("crash within 20 s of installing the exclusion hooks\n", f); fclose(f); }
    }
}

bool Install()
{
    if (g_installed.load() || g_dead) return g_installed.load();
    uintptr_t mon = aml->GetLib("libmonetloader.so");
    if (!mon) return false;                                           // MonetLoader not loaded yet: retry later
    void* lj = dlopen("libluajit-5.1.so", RTLD_NOW | RTLD_NOLOAD);
    if (lj) {
        *(void**)&lj_gettop = dlsym(lj, "lua_gettop"); *(void**)&lj_settop = dlsym(lj, "lua_settop");
        *(void**)&lj_getfield = dlsym(lj, "lua_getfield"); *(void**)&lj_type = dlsym(lj, "lua_type");
        *(void**)&lj_tolstring = dlsym(lj, "lua_tolstring");
    }
    if (!lj_getfield || !lj_tolstring || !lj_gettop || !lj_settop || !lj_type) { Die("LuaJIT C API not found (libluajit-5.1.so)"); return false; }

    uintptr_t eBegin = aml->GetSym(mon, "igBegin"), eNew = aml->GetSym(mon, "igNewFrame"), eRender = aml->GetSym(mon, "igRender");
    uintptr_t eGet = aml->GetSym(mon, "igGetDrawData");
    uintptr_t tGet = eGet ? FollowStub(eGet) : 0;
    uintptr_t tBegin = eBegin ? FollowStub(eBegin) : 0, tNew = eNew ? FollowStub(eNew) : 0, tRender = eRender ? FollowStub(eRender) : 0;
    if (!tBegin || !tNew || !tRender || !tGet) { Die("ImGui 1.72 entry points of libmonetloader not found/decodable"); return false; }

    char p[640];
    FILE* mk = fopen(GuardPath("hexed_capture.exinstalling", p, sizeof(p)), "w");
    if (mk) { fputs("installing\n", mk); fclose(mk); }
    g_installedUs = NowUs();

    bool a = aml->Hook((void*)tBegin, (void*)hk_Begin, (void**)&orig_Begin);
    bool b = aml->Hook((void*)tNew, (void*)hk_NewFrame, (void**)&orig_NewFrame);
    bool c = aml->Hook((void*)tRender, (void*)hk_Render, (void**)&orig_Render);
    bool d = aml->Hook((void*)tGet, (void*)hk_GetDrawData, (void**)&orig_GetDrawData);
    fn_GetDrawData = orig_GetDrawData;                     // our own calls must not go through the hook
    if (!a || !b || !c || !d || !orig_Begin || !orig_NewFrame || !orig_Render || !orig_GetDrawData) { Die("ImGui hooks could not be installed"); return false; }
    bool g1 = PatchGot(mon, "lua_pcall", (void*)hk_pcall, (void**)&orig_pcall);
    bool g2 = PatchGot(mon, "lua_call", (void*)hk_call, (void**)&orig_call);
    bool g3 = PatchGot(mon, "lua_resume", (void*)hk_resume, (void**)&orig_resume);
    HLog("exclude: hooks Begin/NewFrame/Render/GetDrawData ok, GOT lua_pcall %d lua_call %d lua_resume %d", (int)g1, (int)g2, (int)g3);
    if (!g1 && !g2) { Die("no Lua entry point of libmonetloader could be hooked: scripts cannot be identified"); return false; }
    g_installed.store(true);
    return true;
}

// ===================================================================== status / info / diag
void BuildStatus(char* out, size_t n)
{
    char sl[500], rl[500]; GetList(PROF_SHOT, sl, sizeof(sl)); GetList(PROF_REC, rl, sizeof(rl));
    const char* state = g_dead ? "unavailable" : (!g_installed.load() ? (WantInstall() ? "waiting" : "off") : (AnyActive() ? "armed" : "idle"));
    snprintf(out, n,
             "exclude=%s\nexclude_why=%s\nexclude_shot_on=%d\nexclude_rec_on=%d\nexclude_shot=%s\nexclude_rec=%s\nexclude_failsafe=%s\n"
             "exclude_threads=render:%d present:%d getdd:%d (getdd calls %d, on present thread %d)\nexclude_masked=%d\nexclude_skips=%d\nexclude_blocked=%d\nexclude_missed=%d\nexclude_attrib=%d\nselftest=%s\n",
             state, g_dead ? g_deadWhy : g_frameWhy, (int)Enabled(PROF_SHOT), (int)Enabled(PROF_REC), sl, rl, g_failBlock ? "block" : "allow",
             g_tidRender.load(), g_tidPresent.load(), g_tidGetDD.load(), g_getddCalls.load(), g_getddOnPresent.load(),
             g_maskedFrames.load(), g_skips.load(), g_blocked.load(), g_leaked.load(), g_attribMode.load(), g_testResult);
}

int BuildInfo(char* out, size_t n)
{
    size_t used = 0; int c = 0;
    out[0] = 0;
    for (int i = 0; i < g_nsc; i++) {
        int w = snprintf(out + used, n - used, "%s\t%d\t%d\t%d\t%d\t%d\n", g_sc[i].key, g_sc[i].pcalls, g_sc[i].wins, g_sc[i].bgIdx, g_sc[i].fgIdx, g_sc[i].maskedIdx);
        if (w < 0 || (size_t)w >= n - used) break;
        used += (size_t)w; c++;
    }
    return c;
}

bool Diag()
{
    char path[640]; snprintf(path, sizeof(path), "%s/hexed_capture_exclude.txt", DataDir());
    FILE* f = fopen(path, "w");
    if (!f) return false;
    char st[1600]; BuildStatus(st, sizeof(st));
    fprintf(f, "HEXED Capture exclusion diagnostics\ninstalled=%d dead=%d (%s)\nframe=%d layout ok=%d stride=%d vtxoff=%d\n\n%s\n", (int)g_installed.load(), (int)g_dead, g_deadWhy,
            g_frame.load(), (int)g_layoutOk, g_layout.stride, g_layout.vtxOffOff, st);
    fprintf(f, "scripts seen via thisScript() (key, pcalls, ImGui windows, bg idx, fg idx, masked idx):\n");
    char buf[6000]; BuildInfo(buf, sizeof(buf)); fputs(buf, f);
    fprintf(f, "\nwindows -> script:\n");
    for (int i = 0; i < 512; i++) if (g_win[i].h) fprintf(f, "  %-48s %s\n", g_win[i].name, g_win[i].script >= 0 ? g_sc[g_win[i].script].key : "(native / unattributed)");
    fclose(f);
    return true;
}

}
}
