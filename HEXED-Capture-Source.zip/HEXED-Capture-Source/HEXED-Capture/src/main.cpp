/*
 * HEXED Capture 0.4.1 - standalone AML plugin: screenshots + screen recording
 * for SA-MP Nezuko (Android, armeabi-v7a).
 *
 * Independent of every other AML mod (own GUID, own files hexed_capture.*,
 * no interfaces published or consumed).
 */
#include <mod/amlmod.h>
#include <mod/logger.h>
#include <mod/config.h>

#include "capture.h"
#include "control.h"
#include "exclude.h"
#include "hook.h"
#include "state.h"

#include <stdio.h>
#include <string.h>
#include <unistd.h>

MYMODCFG(net.hexed.capture, HEXED Capture, 0.4.1, HEXED)

using namespace hexed;

// Safe-stage crash guard: 0 = idle, 1 = files + service only, 2 = + present hook (no read-back), 3 = full.
// A crash during the first 20 s after load lowers the stage for the next launch;
// surviving 20 s restores stage 3.
static int  g_stage = 3;
static char g_stagePath[640];
static int64_t g_loadedUs = 0;

static void SaveStage(int s)
{
    if (!g_stagePath[0]) return;
    FILE* f = fopen(g_stagePath, "w");
    if (f) { fprintf(f, "0.4.1 %d\n", s); fclose(f); }
}

static void LoadStage()
{
    snprintf(g_stagePath, sizeof(g_stagePath), "%s/hexed_capture.stage", DataDir());
    FILE* f = fopen(g_stagePath, "r");
    if (!f) return;
    char ver[32] = {0};
    int s = 3;
    if (fscanf(f, "%31s %d", ver, &s) == 2 && !strcmp(ver, "0.4.1") && s >= 0 && s <= 3) g_stage = s;
    fclose(f);
}

static void OnSurvived()
{
    exclude::OnSurvived();
    if (g_stage < 3) HLog("boot guard: survived, stage restored to 3 for next launch");
    SaveStage(3);
}

ON_MOD_PRELOAD()
{
    logger->SetTag("HEXED_Capture");
}

ON_MOD_LOAD()
{
    g_loadedUs = NowUs();
    HLog("---- HEXED Capture 0.4.1 loading ----");
    const char* dir = DataDir();
    if (!dir || !dir[0]) { HLog("no writable data dir, plugin disabled"); return; }
    HLog("data dir: %s", dir);
    HLog("script dir (derived): %s", MediaScriptDir());

    LoadStage();
    HLog("stage = %d", g_stage);
    if (g_stage <= 0) { control::StartService(OnSurvived); return; }

    control::LoadConfig();
    exclude::LoadCrashGuard();
    control::StartService(OnSurvived);    // command file + status file, works even without hooks

    if (g_stage >= 2) {
        if (!hook::Install(g.hookMode.load())) HLog("no present hook could be installed");
    }
    if (g_stage >= 3 && g.activeHook.load() >= 0) capture::Init();

    HLog("ready (stage %d, hook %d)", g_stage, g.activeHook.load());
}

ON_MOD_UNLOAD()
{
    capture::Shutdown();
}

ON_GAME_CRASH()
{
    exclude::OnGameCrash();
    if (g_loadedUs && NowUs() - g_loadedUs < 20LL * 1000000) {
        HLog("game crash %d within 20 s of load: lowering stage %d -> %d", sig, g_stage, g_stage > 0 ? g_stage - 1 : 0);
        SaveStage(g_stage > 0 ? g_stage - 1 : 0);
    } else {
        HLog("game crash %d (not blamed on the plugin: it had been running for a while)", sig);
    }
}
