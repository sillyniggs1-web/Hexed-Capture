# HEXED Capture 0.4.0

Standalone AML plugin (`libHEXED_Capture.so`) + MonetLoader menu (`lua/hexed_capture.lua`) for
**SA-MP Nezuko 1.0.3 TESTING** (armeabi-v7a). No dependency on any other AML mod.

Not run on a device yet. See `docs/NOTES.md` (what was verified in the APK) and `docs/LIMITATIONS.md`.

## 0.4.0: real selective Lua exclusion
Selected scripts keep running AND stay visible on screen; only the screenshot / recording frames are produced without them
(capture-side masking of their ImGui draw data, see `docs/EXCLUSION.md`). Pause/Reload hiding was removed. **Not yet run on a device.**

## Why 0.1.0 did not work (found by inspecting the APK)
| Problem | Evidence / fix |
|---|---|
| Inline hook on `RQ_Command_rqSwapBuffers` | that function is **4 bytes**; the hook overwrote the next function. Removed. |
| Up to 3 present hooks at once | each fired every frame: 3 read-backs per swap. Now exactly one hook. |
| Lua menu never reached native code | it wrote `hexed_capture.cmd`, nothing read it. Now ffi + a polled command file. |
| Recording file opened write-only | MediaMuxer needs a read/write fd. |
| No end-of-stream, no flip, odd sizes | MP4 unplayable/upside down. Now EOS drain, flip, 16-aligned size. |
| "PNG" without deflate, saved as `.raw` | real zlib PNG (RGB) and baseline JPEG. |
| GL state left modified | pack alignment / FBO now restored. |

## Build
GitHub Actions: push the source ZIP to the repo root (workflow `build.yml`). Local:
`ANDROID_NDK_HOME=<r26d> ./build.sh` -> `libs/armeabi-v7a/libHEXED_Capture.so`.

## Install
1. `libHEXED_Capture.so` -> AML mods folder.
2. `lua/hexed_capture.lua` -> MonetLoader folder (`Android/media/<pkg>/monetloader`).
3. `adb logcat -s HEXED_Capture` -> expect `hook: eglSwapBuffers @ ...` and `ready (stage 3, hook 0)`.

## Use
`/hxdcap` menu | `/hxdcap shot|rec|pause|resume|stop|verify|status`. The menu closes automatically when a
capture starts so it is not in the picture.
Output: `Android/data/<pkg>/files/HEXED_Screenshots|HEXED_Recordings`, log `hexed_capture.log`.

## Beta test checklist (send me the log)
1. Log shows hook + `ready`. Menu opens; Status tab shows backend `ffi` (or `file`).
2. Screenshot with menu open/closed: PNG opens, is upright, shows your HUD/overlays?
3. Switch Status -> hook to `OS_ScreenSwapBuffers`, restart, compare screenshots (are overlays present?).
4. 15 s recording at 30 fps/8000 kbps: plays, right orientation, FPS drop acceptable? Try Pause/Resume.
5. Lua Visuals: Rescan, tick "Exclude unchecked scripts from screenshots/recordings", uncheck one overlay script, press **Verify**
   (expect `selftest=PASS`), then take a screenshot and a 10 s recording: overlay absent in the files, still on screen, script still working.
6. If the game crashed: `hexed_capture.log` and `hexed_capture.stage`.

## Files
`src/hook.cpp` present hook | `capture.cpp` GL read-back | `pipeline.cpp` worker, MediaCodec/MediaMuxer, shots |
`image.cpp` PNG/JPEG/YUV (host-tested) | `exclude.cpp` capture-side exclusion | `scan.cpp` Lua visual detection | `control.cpp` commands/config/status.
