// Host-only syntax stub (NOT used for the device build).
#pragma once
#include <stddef.h>
#include <stdint.h>
typedef unsigned int GLenum; typedef unsigned int GLuint; typedef int GLint; typedef int GLsizei;
typedef unsigned char GLboolean; typedef float GLfloat; typedef char GLchar; typedef unsigned int GLbitfield;
#define GL_FALSE 0
#define GL_TRUE 1
#define GL_NO_ERROR 0
#define GL_FRAMEBUFFER 0x8D40
#define GL_FRAMEBUFFER_BINDING 0x8CA6
#define GL_PACK_ALIGNMENT 0x0D05
#define GL_RGBA 0x1908
#define GL_UNSIGNED_BYTE 0x1401
#define GL_UNSIGNED_SHORT 0x1403
#define GL_FLOAT 0x1406
#define GL_TRIANGLES 4
#define GL_VERTEX_SHADER 0x8B31
#define GL_FRAGMENT_SHADER 0x8B30
#define GL_COMPILE_STATUS 0x8B81
#define GL_LINK_STATUS 0x8B82
#define GL_CURRENT_PROGRAM 0x8B8D
#define GL_ARRAY_BUFFER 0x8892
#define GL_ELEMENT_ARRAY_BUFFER 0x8893
#define GL_ARRAY_BUFFER_BINDING 0x8894
#define GL_ELEMENT_ARRAY_BUFFER_BINDING 0x8895
#define GL_ACTIVE_TEXTURE 0x84E0
#define GL_TEXTURE0 0x84C0
#define GL_TEXTURE_2D 0x0DE1
#define GL_TEXTURE_BINDING_2D 0x8069
#define GL_VIEWPORT 0x0BA2
#define GL_SCISSOR_BOX 0x0C10
#define GL_BLEND 0x0BE2
#define GL_CULL_FACE 0x0B44
#define GL_DEPTH_TEST 0x0B71
#define GL_SCISSOR_TEST 0x0C11
#define GL_STENCIL_TEST 0x0B90
#define GL_COLOR_WRITEMASK 0x0C23
#define GL_BLEND_EQUATION_RGB 0x8009
#define GL_BLEND_EQUATION_ALPHA 0x883D
#define GL_BLEND_SRC_RGB 0x80C9
#define GL_BLEND_DST_RGB 0x80C8
#define GL_BLEND_SRC_ALPHA 0x80CB
#define GL_BLEND_DST_ALPHA 0x80CA
#define GL_FUNC_ADD 0x8006
#define GL_SRC_ALPHA 0x0302
#define GL_ONE_MINUS_SRC_ALPHA 0x0303
#define GL_ONE 1
#define GL_VERTEX_ATTRIB_ARRAY_ENABLED 0x8622
#define GL_VERTEX_ATTRIB_ARRAY_SIZE 0x8623
#define GL_VERTEX_ATTRIB_ARRAY_STRIDE 0x8624
#define GL_VERTEX_ATTRIB_ARRAY_TYPE 0x8625
#define GL_VERTEX_ATTRIB_ARRAY_NORMALIZED 0x886A
#define GL_VERTEX_ATTRIB_ARRAY_POINTER 0x8645
#define GL_VERTEX_ATTRIB_ARRAY_BUFFER_BINDING 0x889F
extern "C" {
void glGetIntegerv(GLenum, GLint*); void glGetBooleanv(GLenum, GLboolean*); GLboolean glIsEnabled(GLenum);
void glBindFramebuffer(GLenum, GLuint); void glPixelStorei(GLenum, GLint);
void glReadPixels(GLint, GLint, GLsizei, GLsizei, GLenum, GLenum, void*); GLenum glGetError(void);
GLuint glCreateShader(GLenum); void glShaderSource(GLuint, GLsizei, const GLchar* const*, const GLint*); void glCompileShader(GLuint);
void glGetShaderiv(GLuint, GLenum, GLint*); void glDeleteShader(GLuint); GLuint glCreateProgram(void);
void glAttachShader(GLuint, GLuint); void glLinkProgram(GLuint); void glGetProgramiv(GLuint, GLenum, GLint*);
GLint glGetUniformLocation(GLuint, const GLchar*); GLint glGetAttribLocation(GLuint, const GLchar*);
void glUseProgram(GLuint); void glBindBuffer(GLenum, GLuint); void glActiveTexture(GLenum); void glBindTexture(GLenum, GLuint);
void glViewport(GLint, GLint, GLsizei, GLsizei); void glScissor(GLint, GLint, GLsizei, GLsizei);
void glBlendEquationSeparate(GLenum, GLenum); void glBlendEquation(GLenum); void glBlendFuncSeparate(GLenum, GLenum, GLenum, GLenum);
void glColorMask(GLboolean, GLboolean, GLboolean, GLboolean); void glEnable(GLenum); void glDisable(GLenum);
void glGetVertexAttribiv(GLuint, GLenum, GLint*); void glGetVertexAttribPointerv(GLuint, GLenum, void**);
void glVertexAttribPointer(GLuint, GLint, GLenum, GLboolean, GLsizei, const void*);
void glEnableVertexAttribArray(GLuint); void glDisableVertexAttribArray(GLuint);
void glUniform1i(GLint, GLint); void glUniformMatrix4fv(GLint, GLsizei, GLboolean, const GLfloat*);
GLboolean glIsTexture(GLuint); void glDrawElements(GLenum, GLsizei, GLenum, const void*);
}
