#pragma once
typedef void* EGLDisplay; typedef void* EGLSurface; typedef int EGLint; typedef unsigned int EGLBoolean;
#define EGL_NO_DISPLAY ((EGLDisplay)0)
#define EGL_NO_SURFACE ((EGLSurface)0)
#define EGL_DRAW 0x3059
#define EGL_WIDTH 0x3057
#define EGL_HEIGHT 0x3056
#define EGL_FALSE 0
extern "C" { EGLDisplay eglGetCurrentDisplay(void); EGLSurface eglGetCurrentSurface(EGLint); EGLBoolean eglQuerySurface(EGLDisplay, EGLSurface, EGLint, EGLint*); }
