// Host-only stub of the AML API surface used by HEXED Capture (syntax/type check; NOT the device build).
#pragma once
#include <stdint.h>
#include <stddef.h>
struct IAML {
    uintptr_t GetLib(const char*); uintptr_t GetSym(uintptr_t, const char*);
    bool Hook(void*, void*, void**);
    const char* GetAndroidDataPath(); const char* GetDataPath();
};
extern IAML* aml;
struct Logger { void SetTag(const char*); };
extern Logger* logger;
#define MYMODCFG(a, b, c, d)
#define ON_MOD_PRELOAD() void OnModPreLoad()
#define ON_MOD_LOAD() void OnModLoad()
#define ON_MOD_UNLOAD() void OnModUnload()
#define ON_GAME_CRASH() void OnGameCrash(int sig)
