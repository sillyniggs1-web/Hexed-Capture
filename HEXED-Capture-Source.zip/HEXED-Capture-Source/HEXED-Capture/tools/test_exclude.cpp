// Host test of the pure exclusion logic (src/exclude_core.h + src/imgui_abi.h) with a software rasterizer
// standing in for the native overlay renderer. It does NOT test GL, hooks or Lua attribution (device only).
#include "exclude_core.h"
#include <stdio.h>
#include <stdlib.h>
#include <vector>
#include <string>
#include <string.h>

using namespace hexed;

static int g_fail = 0;
#define CHECK(c, msg) do { if (!(c)) { printf("FAIL: %s\n", msg); g_fail++; } else printf("ok:   %s\n", msg); } while (0)

static const int W = 96, H = 64;
struct Img { uint32_t px[W * H]; Img() { memset(px, 0, sizeof(px)); } };

// ---- mock ImDrawList with the real memory layout (ListHead first) --------------------------------
struct MockList {
    abi::ListHead head;
    std::vector<uint8_t> cmd; std::vector<uint16_t> idx; std::vector<abi::Vert> vtx;
    abi::CmdLayout L; int ncmd = 0;
    int cmdStart = 0;
    void init(const abi::CmdLayout& l) { L = l; }
    void sync() {
        head.Cmd = {ncmd, ncmd, cmd.data()};
        head.Idx = {(int)idx.size(), (int)idx.capacity(), idx.data()};
        head.Vtx = {(int)vtx.size(), (int)vtx.capacity(), vtx.data()};
    }
    void rect(int x0, int y0, int x1, int y1, uint32_t col) {
        int b = (int)vtx.size();
        vtx.push_back({(float)x0, (float)y0, 0, 0, col}); vtx.push_back({(float)x1, (float)y0, 0, 0, col});
        vtx.push_back({(float)x1, (float)y1, 0, 0, col}); vtx.push_back({(float)x0, (float)y1, 0, 0, col});
        uint16_t t[6] = {(uint16_t)b, (uint16_t)(b + 1), (uint16_t)(b + 2), (uint16_t)b, (uint16_t)(b + 2), (uint16_t)(b + 3)};
        for (uint16_t v : t) idx.push_back(v);
    }
    // close the current command: covers every index added since the previous close
    void closeCmd(float cx0, float cy0, float cx1, float cy1, uintptr_t tex) {
        int cnt = (int)idx.size() - cmdStart;
        cmd.resize((size_t)(ncmd + 1) * L.stride, 0);
        uint8_t* c = cmd.data() + (size_t)ncmd * L.stride;
        uint32_t e = (uint32_t)cnt; memcpy(c, &e, 4);
        float clip[4] = {cx0, cy0, cx1, cy1}; memcpy(c + 4, clip, 16);
        memcpy(c + L.texOff, &tex, sizeof(void*));
        ncmd++; cmdStart = (int)idx.size();
    }
};

// ---- software "native renderer": walks commands with cumulative index offsets like imgui_impl_opengl3 1.72 ----
static void FillTri(Img& im, const abi::Vert& a, const abi::Vert& b, const abi::Vert& c, const float clip[4])
{
    float area = (b.x - a.x) * (c.y - a.y) - (b.y - a.y) * (c.x - a.x);
    if (area == 0) return;                                    // degenerate: draws nothing
    for (int y = 0; y < H; y++) for (int x = 0; x < W; x++) {
        float px = x + 0.5f, py = y + 0.5f;
        if (px < clip[0] || px >= clip[2] || py < clip[1] || py >= clip[3]) continue;
        float w0 = (b.x - a.x) * (py - a.y) - (b.y - a.y) * (px - a.x);
        float w1 = (c.x - b.x) * (py - b.y) - (c.y - b.y) * (px - b.x);
        float w2 = (a.x - c.x) * (py - c.y) - (a.y - c.y) * (px - c.x);
        bool in = area > 0 ? (w0 >= 0 && w1 >= 0 && w2 >= 0) : (w0 <= 0 && w1 <= 0 && w2 <= 0);
        if (in) im.px[y * W + x] = a.col;
    }
}
static void RenderList(Img& im, const abi::ListHead* h, const abi::CmdLayout& L)
{
    int off = 0;
    for (int j = 0; j < h->Cmd.Size; j++) {
        const uint8_t* c = abi::CmdAt(h, L, j);
        float clip[4]; abi::CmdClip(c, clip);
        int n = (int)abi::CmdElem(c);
        const uint16_t* idx = (const uint16_t*)h->Idx.Data + off;
        const abi::Vert* v = (const abi::Vert*)h->Vtx.Data + abi::CmdVtxOff(c, L);
        for (int k = 0; k + 2 < n; k += 3) FillTri(im, v[idx[k]], v[idx[k + 1]], v[idx[k + 2]], clip);
        off += n;
    }
}
static void RenderItems(Img& im, const xcore::Item* it, int n)
{
    for (int i = 0; i < n; i++)
        for (int k = 0; k + 2 < it[i].count; k += 3) FillTri(im, it[i].vtx[it[i].idx[k]], it[i].vtx[it[i].idx[k + 1]], it[i].vtx[it[i].idx[k + 2]], it[i].clip);
}
static bool Same(const Img& a, const Img& b) { return !memcmp(a.px, b.px, sizeof(a.px)); }
static int Count(const Img& a, uint32_t col) { int n = 0; for (int i = 0; i < W * H; i++) n += a.px[i] == col; return n; }

enum : uint32_t { RED = 0xFF0000FF, GREEN = 0xFF00FF00, BLUE = 0xFFFF0000, YEL = 0xFF00FFFF, BG = 0 };

static void Scenario(const abi::CmdLayout& L, bool overlap)
{
    printf("-- scenario: stride %d vtxOff %d overlap=%d\n", L.stride, L.vtxOffOff, (int)overlap);
    // script A (excluded): window list "A" + two index ranges inside the shared Background list
    // script B (kept):     window list "B" + one range in Background (merged into ONE command with A's ranges)
    // native: Foreground list
    MockList winA, winB, bg, fg; winA.init(L); winB.init(L); bg.init(L); fg.init(L);
    winA.rect(4, 4, 30, 20, RED);          winA.closeCmd(0, 0, W, H, 1);
    winB.rect(overlap ? 20 : 40, overlap ? 10 : 4, overlap ? 50 : 70, 20, GREEN); winB.closeCmd(0, 0, W, H, 1);
    int a0 = (int)bg.idx.size(); bg.rect(4, 30, 20, 40, RED);   int a1 = (int)bg.idx.size();   // A
    bg.rect(24, 30, 40, 40, GREEN); int b1 = (int)bg.idx.size();                                  // B
    bg.rect(44, 30, 60, 40, RED);   int c1 = (int)bg.idx.size();                                  // A again
    bg.closeCmd(0, 0, W, H, 1);                                                                    // ONE command for all three
    bg.rect(4, 50, 20, 60, BLUE); bg.closeCmd(0, 0, 30, H, 1);                                    // second command (native)
    fg.rect(70, 30, 90, 60, YEL);  fg.closeCmd(0, 0, W, H, 1);
    MockList* all[4] = {&bg, &winA, &winB, &fg};
    for (auto* l : all) l->sync();
    void* lists[4] = {&bg.head, &winA.head, &winB.head, &fg.head};

    // 1. layout calibration
    abi::CmdLayout cal; bool multi = false;
    CHECK(abi::CalibrateStride(lists, 4, &cal, &multi) && cal.stride == L.stride && multi, "ImDrawCmd stride calibrated from the lists");

    // reference images
    Img full;  for (auto* l : all) RenderList(full, &l->head, L);                  // everything (what the screen shows natively)
    // expected capture = same draw order but WITHOUT script A's primitives
    MockList rbg, rwinB; rbg.init(L); rwinB.init(L);
    rbg.rect(24, 30, 40, 40, GREEN); rbg.closeCmd(0, 0, W, H, 1); rbg.rect(4, 50, 20, 60, BLUE); rbg.closeCmd(0, 0, 30, H, 1);
    rwinB.rect(overlap ? 20 : 40, overlap ? 10 : 4, overlap ? 50 : 70, 20, GREEN); rwinB.closeCmd(0, 0, W, H, 1);
    rbg.sync(); rwinB.sync();
    Img expectCap; RenderList(expectCap, &rbg.head, L); RenderList(expectCap, &rwinB.head, L); RenderList(expectCap, &fg.head, L);
    // ---- the algorithm under test
    std::vector<uint8_t> origIdx[4]; for (int i = 0; i < 4; i++) { origIdx[i].resize(all[i]->idx.size() * 2); memcpy(origIdx[i].data(), all[i]->idx.data(), origIdx[i].size()); }
    xcore::Plan plan; plan.Reset();
    plan.Add(&bg.head, a0, a1); plan.Add(&bg.head, b1, c1);      // A's two ranges in the shared list
    plan.Add(&winA.head, 0, winA.head.Idx.Size);                  // A's whole window list
    std::vector<uint16_t> backup(4096);
    CHECK(xcore::Mask(&plan, backup.data(), (int)backup.size()), "mask applied");
    Img cap; for (auto* l : all) RenderList(cap, &l->head, L);   // native renderer sees the masked data
    CHECK(Same(cap, expectCap), "capture == overlays without script A, everything else bit-identical");
    CHECK(Count(cap, RED) == 0, "no pixel of the excluded script in the capture");
    CHECK(Count(cap, GREEN) > 0 && Count(cap, BLUE) > 0 && Count(cap, YEL) > 0, "unselected scripts / native UI still visible in the capture");

    xcore::Restore(&plan, backup.data());
    bool idxRestored = true; for (int i = 0; i < 4; i++) idxRestored &= !memcmp(origIdx[i].data(), all[i]->idx.data(), origIdx[i].size());
    CHECK(idxRestored, "restore: index buffers byte-identical to the originals (no script state touched)");

    Img screen = cap;
    xcore::Item items[64]; int n = xcore::BuildItems(plan, L, items, 64);
    CHECK(n >= 3, "redraw items follow command boundaries (one command split into separate A ranges)");
    RenderItems(screen, items, n);
    if (!overlap) CHECK(Count(screen, RED) == Count(full, RED), "on screen: all pixels of the excluded script are back");
    else CHECK(Count(screen, RED) >= Count(full, RED), "on screen: excluded script fully visible again (on top of what overlapped it)");
    if (!overlap) CHECK(Same(screen, full), "on screen: identical to the native full render (no overlap -> exact)");
    else {
        int diff = 0; for (int i = 0; i < W * H; i++) diff += screen.px[i] != full.px[i];
        CHECK(diff > 0 && diff < 200, "on screen: differs only inside the overlap (excluded overlays are drawn on top)");
    }
    Img again; for (auto* l : all) RenderList(again, &l->head, L);
    CHECK(Same(again, full), "after restore the native renderer output is again the unmodified full frame");
}

int main()
{
    abi::CmdLayout cand[3]; abi::Candidates(cand);
    for (int k = 0; k < 3; k++) { if (k == 2 && cand[2].stride == cand[1].stride) continue; Scenario(cand[k], false); Scenario(cand[k], true); }

    printf("-- key normalisation / matching\n");
    char k[80];
    xcore::NormKey("/sdcard/Android/media/x/monetloader/Hexed_Aim.lua", k, sizeof(k)); CHECK(!strcmp(k, "hexed_aim.lua"), "path -> lower-case base name");
    xcore::NormKey("C:\\m\\Custom_HUD\\main.lua", k, sizeof(k)); CHECK(!strcmp(k, "custom_hud/main.lua"), "dir/main.lua keeps the folder");
    xcore::NormKey("Player_ESP.lua", k, sizeof(k)); CHECK(!strcmp(k, "player_esp.lua"), "bare file name");
    xcore::NormKey("win:Aim Menu*", k, sizeof(k)); CHECK(!strcmp(k, "win:Aim Menu*"), "window patterns kept verbatim");
    CHECK(xcore::WinMatch("Aim*", "Aim Menu") && !xcore::WinMatch("Aim*", "Menu Aim") && xcore::WinMatch("X", "X") && !xcore::WinMatch("X", "XY"), "window pattern match");

    printf("-- layout calibration must reject a wrong stride\n");
    { MockList l; abi::CmdLayout L = cand[0]; l.init(L); l.rect(0, 0, 5, 5, RED); l.closeCmd(0, 0, 9, 9, 1); l.rect(0, 0, 5, 5, RED); l.closeCmd(0, 0, 9, 9, 1); l.sync();
      void* ls[1] = {&l.head}; abi::CmdLayout out; bool m = false;
      CHECK(abi::CalibrateStride(ls, 1, &out, &m) && out.stride == L.stride, "stride A detected (not B/C)"); }

    printf("-- overflow / capacity guards\n");
    { xcore::Plan p; p.Reset(); MockList l; l.init(cand[0]); for (int i = 0; i < 10; i++) l.rect(0, 0, 4, 4, RED); l.closeCmd(0, 0, 9, 9, 1); l.sync();
      p.Add(&l.head, 0, l.head.Idx.Size); std::vector<uint16_t> b(8);
      CHECK(!xcore::Mask(&p, b.data(), 8), "Mask refuses (and changes nothing) when the backup buffer is too small");
      CHECK(l.idx[5] != 0 || l.idx[6] != 0, "refused mask left the indices untouched"); }
    printf(g_fail ? "\n%d CHECK(S) FAILED\n" : "\nALL CHECKS PASSED\n", g_fail);
    return g_fail ? 1 : 0;
}
