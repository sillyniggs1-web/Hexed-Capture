script_name("Hexed Capture")
script_author("HEXED Studio")
script_version("0.4.0")
require "lib.moonloader"

-- HEXED Capture menu (MonetLoader / mimgui).
-- Talks to libHEXED_Capture.so through ffi.load; if that fails it falls back to a
-- command file that the plugin polls. Nothing in other scripts is modified.

local imgui  = require("mimgui")
local inicfg = require("inicfg")
local ffi    = require("ffi")
local DPI    = MONET_DPI_SCALE or 1

local INI_NAME = "Hexed Capture.ini"
local CMD_FILE, STATUS_FILE, SCAN_FILE = "hexed_capture.cmd", "hexed_capture.status", "hexed_capture.scan"

-- everything lives in S to stay far away from LuaJIT's 200-locals / 60-upvalues limits
local S = {
    lib = nil, libName = nil, backend = "none",
    st = {}, lastPoll = 0,
    mods = {}, scanned = false, scanErr = nil,
    tab = 1, profile = 1,                       -- profile 1 = screenshots, 2 = recordings
    showAll = imgui.new.bool(false),
    menu = imgui.new.bool(false),
    req = nil, busy = false,
    info = {}, infoAt = 0,
    dirty = nil, synced = false, exDirty = nil,
}

local DEFAULTS = {
    main = { hide_shot = false, hide_rec = false, settle_ms = 500 },
    excl = { shot = "", rec = "" },              -- file names excluded from screenshots / recordings (survive a missing rescan)
    shot_off = {},
    rec_off = {},
}
S.ini = inicfg.load(DEFAULTS, INI_NAME)
if type(S.ini.shot_off) ~= "table" then S.ini.shot_off = {} end
if type(S.ini.rec_off) ~= "table" then S.ini.rec_off = {} end
if type(S.ini.excl) ~= "table" then S.ini.excl = { shot = "", rec = "" } end

S.ui = {
    hideShot = imgui.new.bool(S.ini.main.hide_shot and true or false),
    hideRec  = imgui.new.bool(S.ini.main.hide_rec and true or false),
    fps      = imgui.new.int(30),
    bitrate  = imgui.new.int(8000),
    w        = imgui.new.int(0),
    h        = imgui.new.int(0),
    jpeg     = imgui.new.int(90),
    shotDir  = imgui.new.char[256](""),
    recDir   = imgui.new.char[256](""),
    cb       = { {}, {} },                      -- per profile: [key] = imgui bool (checked = visible in capture)
}

-- ------------------------------------------------------------------ helpers
local function wd()
    local ok, d = pcall(getWorkingDirectory)
    if ok and type(d) == "string" and d ~= "" then return d end
    return "."
end

local function say(text)
    pcall(function() sampAddChatMessage("{00B4FF}[HEXED Capture]{FFFFFF} " .. text, -1) end)
end

local function keyOf(file) return (file:gsub("[^%w]", "_")) end
local function truthy(v) return v == true or v == 1 or v == "1" or v == "true" end

local function saveIni()
    S.ini.main.hide_shot = S.ui.hideShot[0]
    S.ini.main.hide_rec = S.ui.hideRec[0]
    for p = 1, 2 do
        local sect = {}
        for key, cb in pairs(S.ui.cb[p]) do
            if not cb[0] then sect[key] = true end
        end
        if p == 1 then S.ini.shot_off = sect else S.ini.rec_off = sect end
        if S.scanned then
            local names = {}
            for _, m in ipairs(S.mods) do
                local cb = S.ui.cb[p][m.key]
                if cb and not cb[0] then names[#names + 1] = m.file end
            end
            S.ini.excl[p == 1 and "shot" or "rec"] = table.concat(names, "|")
        end
    end
    S.exDirty = os.clock()                      -- push the selection to the plugin (debounced in main)
    pcall(inicfg.save, S.ini, INI_NAME)
end

-- ------------------------------------------------------------------ plugin backend
local function connect()
    pcall(ffi.cdef, [[
        int HEXED_Command(const char* line);
        int HEXED_Status(char* buf, int len);
        int HEXED_Scan(const char* dir, char* buf, int len);
        int HEXED_ExcludeInfo(char* buf, int len);
    ]])
    local names = { "libHEXED_Capture.so", "HEXED_Capture" }
    for _, n in ipairs(names) do
        local ok, lib = pcall(ffi.load, n)
        if ok and lib then
            local ok2 = pcall(function() return lib.HEXED_Command, lib.HEXED_Status, lib.HEXED_Scan end)
            if ok2 then S.lib, S.libName, S.backend = lib, n, "ffi"; return end
        end
    end
    S.backend = "file"
end

local function cmd(line)
    if S.lib then
        local ok, r = pcall(function() return S.lib.HEXED_Command(line) end)
        return ok and r == 1
    end
    local f = io.open(wd() .. "/" .. CMD_FILE, "a")
    if not f then return false end
    f:write(line .. "\n")
    f:close()
    return true
end

local function readFile(path)
    local f = io.open(path, "r")
    if not f then return nil end
    local t = f:read("*a")
    f:close()
    return t
end

local function pollStatus()
    local text
    if S.lib then
        local buf = ffi.new("char[3072]")
        local ok = pcall(function() S.lib.HEXED_Status(buf, 3072) end)
        if ok then text = ffi.string(buf) end
    else
        text = readFile(wd() .. "/" .. STATUS_FILE)
    end
    if not text or text == "" then return false end
    local t = {}
    for k, v in text:gmatch("([%w_]+)=([^\n]*)") do t[k] = v end
    S.st = t
    return true
end

local function syncSettingsFromPlugin()
    local st = S.st
    if not st.fps then return end
    S.ui.fps[0] = tonumber(st.fps) or 30
    S.ui.bitrate[0] = tonumber(st.bitrate) or 8000
    S.ui.w[0] = tonumber(st.width) or 0
    S.ui.h[0] = tonumber(st.height) or 0
    S.ui.jpeg[0] = tonumber(st.jpeg) or 90
    if st.shot_dir then ffi.copy(S.ui.shotDir, st.shot_dir, math.min(#st.shot_dir, 255)) end
    if st.rec_dir then ffi.copy(S.ui.recDir, st.rec_dir, math.min(#st.rec_dir, 255)) end
    S.synced = true
end

local function pushSettings()
    cmd("set fps " .. S.ui.fps[0])
    cmd("set bitrate " .. S.ui.bitrate[0])
    cmd("set width " .. S.ui.w[0])
    cmd("set height " .. S.ui.h[0])
    cmd("set jpeg " .. S.ui.jpeg[0])
end

-- ------------------------------------------------------------------ Lua visual-mod detection
local function selfFile()
    local ok, p = pcall(function() return thisScript().filename or thisScript().name end)
    if ok and type(p) == "string" then return p:lower() end
    return "hexed_capture.lua"
end

local function scanScripts()
    S.scanErr = nil
    local text
    if S.lib then
        local buf = ffi.new("char[49152]")
        local ok, c = pcall(function() return S.lib.HEXED_Scan(wd(), buf, 49152) end)
        if ok and c and c >= 0 then text = "count=" .. c .. "\n" .. ffi.string(buf) end
    else
        os.remove(wd() .. "/" .. SCAN_FILE)
        cmd("scan " .. wd())
        for _ = 1, 10 do
            wait(250)
            local t = readFile(wd() .. "/" .. SCAN_FILE)
            if t and t:find("count=") then text = t; break end
        end
    end
    if not text then
        S.scanErr = "plugin did not answer (is libHEXED_Capture.so loaded?)"
        return
    end
    local mods, me = {}, selfFile()
    for line in text:gmatch("[^\n]+") do
        local file, flags = line:match("^(.-)\t(%d+)$")
        if file and file:lower() ~= me and not file:lower():find("hexed_capture", 1, true) then
            mods[#mods + 1] = { file = file, key = keyOf(file), flags = tonumber(flags) or 0 }
        end
    end
    table.sort(mods, function(a, b) return a.file:lower() < b.file:lower() end)
    S.mods = mods
    for p = 1, 2 do
        local offs = (p == 1) and S.ini.shot_off or S.ini.rec_off
        for _, m in ipairs(mods) do
            local old = S.ui.cb[p][m.key]
            local on
            if old then on = old[0] else on = not truthy(offs[m.key]) end
            S.ui.cb[p][m.key] = imgui.new.bool(on)
        end
    end
    S.scanned = true
end

local DIM = imgui.ImVec4(0.55, 0.60, 0.70, 1)
local GOOD = imgui.ImVec4(0.30, 0.90, 0.45, 1)
local BAD = imgui.ImVec4(1.00, 0.35, 0.35, 1)

-- ------------------------------------------------------------------ capture-side exclusion
-- The selected (unchecked) scripts are NOT paused, unloaded or touched in any way. The plugin removes their
-- ImGui output from the captured frames only (see docs/EXCLUSION.md). This menu only sends the selection.
local PROFS = { "shot", "rec" }

local function pushExclusion()
    for p, name in ipairs(PROFS) do
        local on = (p == 1) and S.ui.hideShot[0] or S.ui.hideRec[0]
        cmd("exclude clear " .. name)
        local list = {}
        if S.scanned then
            for _, m in ipairs(S.mods) do
                local cb = S.ui.cb[p][m.key]
                if cb and not cb[0] then list[#list + 1] = m.file end
            end
        else
            for f in tostring(S.ini.excl[name] or ""):gmatch("[^|]+") do list[#list + 1] = f end
        end
        for _, f in ipairs(list) do cmd("exclude add " .. name .. " " .. f) end
        cmd((on and "exclude on " or "exclude off ") .. name)
    end
end

local function pollExcludeInfo()
    if not S.lib then return end
    local buf = ffi.new("char[6144]")
    local ok, c = pcall(function() return S.lib.HEXED_ExcludeInfo(buf, 6144) end)
    if not ok or not c or c < 0 then return end
    local t = {}
    for line in ffi.string(buf):gmatch("[^\n]+") do
        local k, pc, w, bg, fg, mk = line:match("^(.-)\t(%d+)\t(%d+)\t(%d+)\t(%d+)\t(%d+)$")
        if k then t[k] = { pcalls = tonumber(pc), wins = tonumber(w), bg = tonumber(bg), fg = tonumber(fg), masked = tonumber(mk) } end
    end
    S.info = t
end

local function scriptStatus(m)
    local i = S.info[m.file:lower()]
    if not i then return "not seen running yet", DIM end
    if i.wins == 0 and i.bg == 0 and i.fg == 0 then
        return "running (" .. i.pcalls .. " callbacks), no ImGui output attributed", BAD
    end
    return "running (" .. i.pcalls .. " callbacks), ImGui windows " .. i.wins .. ", draw idx " .. (i.bg + i.fg), GOOD
end

-- ------------------------------------------------------------------ actions (run from main(): they may wait())
local function settle() wait(tonumber(S.ini.main.settle_ms) or 500) end       -- only so this menu is gone from the picture

local function doScreenshot()
    local reopen = S.menu[0]
    S.menu[0] = false                                  -- the menu itself must not be in the picture
    settle()
    pollStatus()
    local before = tonumber(S.st.shots) or 0
    if not cmd("shot") then say("could not reach the plugin"); S.menu[0] = reopen; return end
    local t = os.clock()
    while os.clock() - t < 8 do
        wait(150)
        pollStatus()
        if (tonumber(S.st.shots) or 0) > before then break end
        if tostring(S.st.error or ""):find("capture blocked", 1, true) then break end
    end
    S.menu[0] = reopen
    if (tonumber(S.st.shots) or 0) > before then
        say("screenshot saved: " .. tostring(S.st.last_file))
    else
        say("no screenshot written: " .. ((S.st.error and S.st.error ~= "") and S.st.error or "no frame captured (see hexed_capture.log)"))
    end
end

local function doStart()
    S.menu[0] = false
    settle()
    pushSettings()
    wait(300)
    local ok = cmd("start")
    wait(600)
    pollStatus()
    if ok and S.st.state == "recording" then
        say("recording started - /hxdcap pause | resume | stop")
    else
        say("recording did not start: " .. tostring(S.st.error or "plugin not reachable"))
    end
end

local function doStop()
    cmd("stop")
    wait(800)
    for _ = 1, 20 do
        pollStatus()
        if S.st.state == "idle" then break end
        wait(250)
    end
    local file = (S.st.last_file and S.st.last_file ~= "") and (": " .. S.st.last_file) or ""
    say("recording stopped" .. file)                   -- nothing to restart: no script was ever touched
end

-- Verify the exclusion on THIS device: the plugin captures a reference frame, then a masked frame, and compares
-- them around the selected scripts' overlays (hexed_capture.log has the numbers).
local function doVerify()
    pushExclusion()
    wait(400)
    cmd("exclude test")
    say("verifying... keep a selected script's overlay visible on screen (menu stays as is)")
    local t = os.clock()
    while os.clock() - t < 10 do
        wait(300)
        pollStatus()
        local r = tostring(S.st.selftest or "")
        if r ~= "running" and r ~= "" and r ~= "none" then break end
    end
    say("exclusion self-test: " .. tostring(S.st.selftest or "no answer"))
end

-- ------------------------------------------------------------------ UI
local function button(label, w, h, enabled, active)
    if enabled == nil then enabled = true end
    if not enabled then
        imgui.PushStyleColor(imgui.Col.Button, imgui.ImVec4(0.10, 0.11, 0.16, 1))
        imgui.PushStyleColor(imgui.Col.ButtonHovered, imgui.ImVec4(0.10, 0.11, 0.16, 1))
        imgui.PushStyleColor(imgui.Col.ButtonActive, imgui.ImVec4(0.10, 0.11, 0.16, 1))
        imgui.PushStyleColor(imgui.Col.Text, imgui.ImVec4(0.40, 0.42, 0.50, 1))
        imgui.Button(label, imgui.ImVec2(w, h))
        imgui.PopStyleColor(4)
        return false
    end
    if active then imgui.PushStyleColor(imgui.Col.Button, imgui.ImVec4(0.10, 0.45, 0.95, 1)) end
    local r = imgui.Button(label, imgui.ImVec2(w, h))
    if active then imgui.PopStyleColor() end
    return r
end


local function touchScroll()
    if imgui.IsWindowHovered() and imgui.IsMouseDragging(0, 6 * DPI) then
        imgui.SetScrollY(imgui.GetScrollY() - imgui.GetIO().MouseDelta.y)
    end
end

local function drawCaptureTab()
    local st = S.st
    local state = st.state or "unknown"
    local colour = GOOD
    if state == "recording" then colour = BAD elseif state == "paused" then colour = imgui.ImVec4(1, 0.8, 0.2, 1) end
    imgui.TextColored(colour, "State: " .. state)
    local hookName = "NONE"
    if st.active_hook == "0" then hookName = "eglSwapBuffers" elseif st.active_hook == "1" then hookName = "OS_ScreenSwapBuffers" end
    imgui.TextColored(DIM, string.format("source %sx%s   hook: %s", tostring(st.src_w or "?"), tostring(st.src_h or "?"), hookName))
    if state == "recording" or state == "paused" then
        imgui.Text(string.format("Recorded %ss | encoded %s | dropped %s", tostring(st.rec_seconds or 0),
            tostring(st.frames_encoded or 0), tostring(st.frames_dropped or 0)))
    end
    imgui.Separator()
    imgui.Spacing()
    local bw, bh = 150 * DPI, 44 * DPI
    if button("Screenshot", bw, bh, state ~= "unknown" and not S.busy) then S.req = "shot" end
    imgui.SameLine()
    if button("Start", bw, bh, state == "idle" and not S.busy) then S.req = "start" end
    imgui.Spacing()
    if button("Pause", bw, bh, state == "recording") then S.req = "pause" end
    imgui.SameLine()
    if button("Resume", bw, bh, state == "paused") then S.req = "resume" end
    imgui.SameLine()
    if button("Stop", bw, bh, state == "recording" or state == "paused") then S.req = "stop" end
    imgui.Spacing()
    imgui.TextWrapped("The menu closes when a screenshot/recording starts so it is not in the picture. Reopen with /hxdcap.")
    if st.last_file and st.last_file ~= "" then
        imgui.Spacing()
        imgui.TextColored(DIM, "Last file:")
        imgui.TextWrapped(st.last_file)
    end
    if st.error and st.error ~= "" then
        imgui.Spacing()
        imgui.TextColored(BAD, "Last error: " .. st.error)
    end
end

local function drawSettingsTab()
    local ui, changed = S.ui, false
    imgui.PushItemWidth(260 * DPI)
    if imgui.SliderInt("FPS", ui.fps, 5, 60) then changed = true end
    if imgui.SliderInt("Bitrate (kbps)", ui.bitrate, 1000, 40000) then changed = true end
    if imgui.SliderInt("JPEG quality", ui.jpeg, 40, 100) then changed = true end
    imgui.PopItemWidth()
    imgui.Spacing()
    imgui.Text("Capture resolution (0 x 0 = native; shots and recordings)")
    imgui.PushItemWidth(150 * DPI)
    if imgui.InputInt("Width", ui.w) then changed = true end
    if imgui.InputInt("Height", ui.h) then changed = true end
    imgui.PopItemWidth()
    local presets = { { "Native", 0, 0 }, { "1080p", 1920, 1080 }, { "720p", 1280, 720 }, { "480p", 854, 480 } }
    for i, p in ipairs(presets) do
        if i > 1 then imgui.SameLine() end
        if imgui.Button(p[1], imgui.ImVec2(90 * DPI, 34 * DPI)) then ui.w[0], ui.h[0] = p[2], p[3]; changed = true end
    end
    imgui.TextColored(DIM, "Recording sizes are rounded down to a multiple of 16 for the H.264 encoder.")
    imgui.Spacing()
    imgui.Text("Screenshot format")
    if button("PNG", 90 * DPI, 34 * DPI, true, S.st.format ~= "jpg") then cmd("set format png"); S.st.format = "png" end
    imgui.SameLine()
    if button("JPG", 90 * DPI, 34 * DPI, true, S.st.format == "jpg") then cmd("set format jpg"); S.st.format = "jpg" end
    imgui.Spacing()
    imgui.Text("Screenshot folder")
    imgui.PushItemWidth(-90 * DPI)
    imgui.InputText("##shotdir", ui.shotDir, 256)
    imgui.PopItemWidth()
    imgui.SameLine()
    if imgui.Button("Apply##s", imgui.ImVec2(80 * DPI, 0)) then cmd("dir shot " .. ffi.string(ui.shotDir)); pollStatus() end
    imgui.Text("Recording folder")
    imgui.PushItemWidth(-90 * DPI)
    imgui.InputText("##recdir", ui.recDir, 256)
    imgui.PopItemWidth()
    imgui.SameLine()
    if imgui.Button("Apply##r", imgui.ImVec2(80 * DPI, 0)) then cmd("dir rec " .. ffi.string(ui.recDir)); pollStatus() end
    imgui.TextColored(DIM, "If a folder is not writable the plugin falls back to its own folder.")
    if changed then S.dirty = os.clock() end
end

local function setAll(profile, value)
    for _, m in ipairs(S.mods) do
        local cb = S.ui.cb[profile][m.key]
        if cb then cb[0] = value end
    end
    saveIni()
end

local function drawVisualsTab()
    local p = S.profile
    if button("Screenshot profile", 190 * DPI, 36 * DPI, true, p == 1) then S.profile = 1 end
    imgui.SameLine()
    if button("Recording profile", 190 * DPI, 36 * DPI, true, p == 2) then S.profile = 2 end
    imgui.Spacing()
    if imgui.Checkbox("Exclude unchecked scripts from screenshots", S.ui.hideShot) then saveIni() end
    if imgui.Checkbox("Exclude unchecked scripts from recordings", S.ui.hideRec) then saveIni() end
    imgui.TextColored(DIM, "Capture-side only: the scripts keep running and stay visible on screen.")
    imgui.TextColored(DIM, "Checked = appears in the capture. Unchecked = removed from the capture.")
    local ex = tostring(S.st.exclude or "?")
    local col = (ex == "armed" or ex == "idle") and GOOD or ((ex == "unavailable") and BAD or DIM)
    imgui.TextColored(col, "Exclusion layer: " .. ex .. ((S.st.exclude_why and S.st.exclude_why ~= "") and (" - " .. S.st.exclude_why) or ""))
    imgui.Spacing()
    if imgui.Button("Rescan", imgui.ImVec2(110 * DPI, 34 * DPI)) then S.req = "scan" end
    imgui.SameLine()
    if imgui.Button("Select all", imgui.ImVec2(110 * DPI, 34 * DPI)) then setAll(p, true) end
    imgui.SameLine()
    if imgui.Button("Deselect all", imgui.ImVec2(120 * DPI, 34 * DPI)) then setAll(p, false) end
    imgui.SameLine()
    if imgui.Button("Verify", imgui.ImVec2(110 * DPI, 34 * DPI)) then S.req = "verify" end
    imgui.Checkbox("Show non-visual scripts too", S.showAll)
    if S.scanErr then imgui.TextColored(BAD, S.scanErr) end
    imgui.Separator()
    imgui.BeginChild("modlist", imgui.ImVec2(0, 0), true)
    if not S.scanned then
        imgui.TextColored(DIM, "Press Rescan.")
    else
        local shown = 0
        for _, m in ipairs(S.mods) do
            local visual = m.flags > 0
            if visual or S.showAll[0] then
                shown = shown + 1
                local cb = S.ui.cb[p][m.key]
                if cb and imgui.Checkbox(m.file .. "##" .. m.key, cb) then saveIni() end
                local tag = ""
                if m.flags % 2 == 1 then tag = tag .. " [imgui]" end
                if m.flags >= 2 then tag = tag .. " [render]" end
                imgui.TextColored(DIM, "   " .. (tag == "" and "[no overlay code found]" or tag))
                local txt, c = scriptStatus(m)
                imgui.SameLine()
                imgui.TextColored(c, txt)
            end
        end
        if shown == 0 then imgui.TextColored(DIM, "No visual scripts found in " .. wd()) end
    end
    touchScroll()
    imgui.EndChild()
end

local function drawStatusTab()
    imgui.Text("Backend: " .. S.backend .. (S.libName and (" (" .. S.libName .. ")") or ""))
    if S.backend == "file" then
        imgui.TextColored(BAD, "ffi.load failed: using the command file (status lags ~0.5 s).")
    end
    if imgui.Button("Write exclusion diagnostics", imgui.ImVec2(300 * DPI, 34 * DPI)) then cmd("exclude diag") end
    imgui.SameLine()
    if imgui.Button("Reset crash guard", imgui.ImVec2(200 * DPI, 34 * DPI)) then cmd("exclude reset") end
    imgui.TextColored(DIM, "diagnostics -> hexed_capture_exclude.txt (windows/scripts seen, layout, counters)")
    imgui.Spacing()
    imgui.Text("Present hook (takes effect next launch)")
    if button("eglSwapBuffers", 190 * DPI, 34 * DPI, true, S.st.hook ~= "os") then cmd("set hook egl"); S.st.hook = "egl" end
    imgui.SameLine()
    if button("OS_ScreenSwapBuffers", 230 * DPI, 34 * DPI, true, S.st.hook == "os") then cmd("set hook os"); S.st.hook = "os" end
    imgui.Spacing()
    imgui.BeginChild("stat", imgui.ImVec2(0, 0), true)
    local keys = { "state", "version", "active_hook", "src_w", "src_h", "frames_read", "frames_encoded", "frames_dropped", "shots",
                   "fps", "bitrate", "width", "height", "format", "jpeg", "shot_dir", "rec_dir", "last_file", "error",
                   "exclude", "exclude_why", "exclude_masked", "exclude_skips", "exclude_blocked", "exclude_missed", "exclude_failsafe", "selftest" }
    for _, k in ipairs(keys) do
        imgui.TextWrapped(k .. " = " .. tostring(S.st[k] or ""))
    end
    imgui.TextColored(DIM, "Log: hexed_capture.log in the plugin data folder; adb logcat -s HEXED_Capture")
    touchScroll()
    imgui.EndChild()
end

imgui.OnInitialize(function()
    pcall(function()
        local style = imgui.GetStyle()
        style.WindowRounding = 10
        style.FrameRounding = 6
        style.ChildRounding = 6
        style.WindowBorderSize = 1
        style.FramePadding = imgui.ImVec2(8 * DPI, 6 * DPI)
        style.ItemSpacing = imgui.ImVec2(8 * DPI, 8 * DPI)
        local c = style.Colors
        c[imgui.Col.WindowBg]      = imgui.ImVec4(0.02, 0.03, 0.07, 0.97)
        c[imgui.Col.Border]        = imgui.ImVec4(0.10, 0.35, 0.85, 1)
        c[imgui.Col.ChildBg]       = imgui.ImVec4(0.04, 0.06, 0.12, 1)
        c[imgui.Col.FrameBg]       = imgui.ImVec4(0.08, 0.10, 0.18, 1)
        c[imgui.Col.Button]        = imgui.ImVec4(0.12, 0.14, 0.22, 1)
        c[imgui.Col.ButtonHovered] = imgui.ImVec4(0.14, 0.40, 0.90, 1)
        c[imgui.Col.ButtonActive]  = imgui.ImVec4(0.10, 0.45, 0.95, 1)
        c[imgui.Col.CheckMark]     = imgui.ImVec4(0.20, 0.60, 1.00, 1)
        c[imgui.Col.SliderGrab]    = imgui.ImVec4(0.14, 0.40, 0.90, 1)
    end)
    local gio = imgui.GetIO()
    local fontPath = wd() .. "/HEXED/Fonts/LamarFont.ttf"
    local loaded = false
    local fh = io.open(fontPath, "rb")
    if fh then
        fh:close()
        loaded = pcall(function() gio.Fonts:AddFontFromFileTTF(fontPath, 17 * DPI, nil, gio.Fonts:GetGlyphRangesDefault()) end)
    end
    if not loaded then
        pcall(function() gio.Fonts:AddFontDefault(); gio.FontGlobalScale = 1.25 * DPI end)
    end
end)

imgui.OnFrame(function() return S.menu[0] end, function()
    local gio = imgui.GetIO()
    imgui.SetNextWindowSize(imgui.ImVec2(math.min(760 * DPI, gio.DisplaySize.x * 0.95), math.min(520 * DPI, gio.DisplaySize.y * 0.92)), imgui.Cond.FirstUseEver)
    imgui.SetNextWindowPos(imgui.ImVec2(gio.DisplaySize.x / 2, gio.DisplaySize.y / 2), imgui.Cond.FirstUseEver, imgui.ImVec2(0.5, 0.5))
    imgui.Begin("##hexedcapture", S.menu, imgui.WindowFlags.NoTitleBar + imgui.WindowFlags.NoCollapse)

    local title = "HEXED CAPTURE"
    local tw = imgui.CalcTextSize(title).x
    imgui.SetCursorPosX((imgui.GetWindowWidth() - tw) / 2)
    imgui.TextColored(imgui.ImVec4(0.20, 0.60, 1, 1), title)
    imgui.Separator()

    imgui.BeginChild("tabs", imgui.ImVec2(140 * DPI, 0), false)
    local tabs = { "Capture", "Settings", "Lua Visuals", "Status" }
    for i, name in ipairs(tabs) do
        if button(name, 130 * DPI, 35 * DPI, true, S.tab == i) then S.tab = i end
    end
    imgui.Spacing()
    if imgui.Button("Close", imgui.ImVec2(130 * DPI, 35 * DPI)) then S.menu[0] = false end
    imgui.EndChild()
    imgui.SameLine()
    imgui.BeginChild("content", imgui.ImVec2(0, 0), true)
    if S.tab == 1 then drawCaptureTab()
    elseif S.tab == 2 then drawSettingsTab()
    elseif S.tab == 3 then drawVisualsTab()
    else drawStatusTab() end
    imgui.EndChild()
    imgui.End()
end)

-- ------------------------------------------------------------------ main
local function handleRequest(r)
    if r == "shot" then doScreenshot()
    elseif r == "start" then doStart()
    elseif r == "stop" then doStop()
    elseif r == "pause" then cmd("pause"); wait(300); pollStatus()
    elseif r == "resume" then cmd("resume"); wait(300); pollStatus()
    elseif r == "scan" then scanScripts()
    elseif r == "verify" then doVerify()
    end
end

function main()
    if type(isSampLoaded) == "function" then
        while not isSampLoaded() do wait(200) end
    end
    connect()

    pcall(function()
        sampRegisterChatCommand("hxdcap", function(arg)
            arg = (arg or ""):lower():match("^%s*(.-)%s*$")
            local map = { shot = "shot", screenshot = "shot", rec = "start", record = "start", start = "start",
                          stop = "stop", pause = "pause", resume = "resume", scan = "scan", verify = "verify" }
            if arg == "" then
                S.menu[0] = not S.menu[0]
                if S.menu[0] and not S.scanned then S.req = S.req or "scan" end
            elseif arg == "status" then
                pollStatus()
                say("state " .. tostring(S.st.state) .. ", backend " .. S.backend .. ", hook " .. tostring(S.st.active_hook))
            elseif map[arg] then
                S.req = map[arg]
            else
                say("/hxdcap [shot | rec | stop | pause | resume | verify | status]")
            end
        end)
    end)

    for _ = 1, 20 do
        if pollStatus() then break end
        wait(250)
    end
    syncSettingsFromPlugin()
    pushExclusion()                                  -- saved selection is active before the menu is ever opened
    if S.backend == "file" then say("ffi.load of the plugin failed - using the command file") end
    say("loaded. /hxdcap opens the menu" .. (S.st.state and "" or " (plugin not answering yet - check logcat)"))

    while true do
        wait(0)
        imgui.Process = S.menu[0]
        local now = os.clock()
        if now - S.lastPoll > 0.5 then
            S.lastPoll = now
            pollStatus()
            if not S.synced then syncSettingsFromPlugin() end
        end
        if S.exDirty and now - S.exDirty > 0.4 then
            S.exDirty = nil
            pushExclusion()
        end
        if S.menu[0] and S.tab == 3 and now - S.infoAt > 1.0 then
            S.infoAt = now
            pollExcludeInfo()
        end
        if S.dirty and now - S.dirty > 0.4 then
            S.dirty = nil
            pushSettings()
        end
        if S.req and not S.busy then
            local r = S.req
            S.req = nil
            S.busy = true
            local ok, err = pcall(handleRequest, r)
            S.busy = false
            if not ok then say("error: " .. tostring(err)) end
        end
    end
end

function onScriptTerminate(s, quit)
    if s == thisScript() then
        if S.st.state == "recording" or S.st.state == "paused" then cmd("stop") end
    end
end
