script_name("Hexed Capture")
script_author("HEXED Studio")
script_version("0.3.0")
require "lib.moonloader"

-- HEXED Capture menu (MonetLoader / mimgui).
-- Talks to libHEXED_Capture.so through ffi.load; if that fails it falls back to a
-- command file that the plugin polls. Nothing in other scripts is modified.

local imgui  = require("mimgui")
local inicfg = require("inicfg")
local ffi    = require("ffi")
local DPI    = MONET_DPI_SCALE or 1

local INI_NAME = "Hexed Capture.ini"
local CMD_FILE, STATUS_FILE, SCAN_FILE = "hexed_capture.cmd", "hexed_capture.status", "hexed_capture.scan"

-- everything lives in S to stay far away from LuaJIT's 200-locals / 60-upvalues limits
local S = {
    lib = nil, libName = nil, backend = "none",
    st = {}, lastPoll = 0,
    mods = {}, scanned = false, scanErr = nil,
    tab = 1, profile = 1,                       -- profile 1 = screenshots, 2 = recordings
    showAll = imgui.new.bool(false),
    menu = imgui.new.bool(false),
    req = nil, busy = false,
    paused = {}, objCache = {}, canToggle = nil,
    dirty = nil, synced = false,
}

local DEFAULTS = {
    main = { hide_shot = false, hide_rec = false, settle_ms = 500, hide_mode = "pause" },
    shot_off = {},
    rec_off = {},
}
S.ini = inicfg.load(DEFAULTS, INI_NAME)
if type(S.ini.shot_off) ~= "table" then S.ini.shot_off = {} end
if type(S.ini.rec_off) ~= "table" then S.ini.rec_off = {} end

S.ui = {
    hideShot = imgui.new.bool(S.ini.main.hide_shot and true or false),
    hideRec  = imgui.new.bool(S.ini.main.hide_rec and true or false),
    fps      = imgui.new.int(30),
    bitrate  = imgui.new.int(8000),
    w        = imgui.new.int(0),
    h        = imgui.new.int(0),
    jpeg     = imgui.new.int(90),
    shotDir  = imgui.new.char[256](""),
    recDir   = imgui.new.char[256](""),
    cb       = { {}, {} },                      -- per profile: [key] = imgui bool (checked = visible in capture)
}

-- ------------------------------------------------------------------ helpers
local function wd()
    local ok, d = pcall(getWorkingDirectory)
    if ok and type(d) == "string" and d ~= "" then return d end
    return "."
end

local function say(text)
    pcall(function() sampAddChatMessage("{00B4FF}[HEXED Capture]{FFFFFF} " .. text, -1) end)
end

local function keyOf(file) return (file:gsub("[^%w]", "_")) end
local function truthy(v) return v == true or v == 1 or v == "1" or v == "true" end

local function saveIni()
    S.ini.main.hide_shot = S.ui.hideShot[0]
    S.ini.main.hide_rec = S.ui.hideRec[0]
    for p = 1, 2 do
        local sect = {}
        for key, cb in pairs(S.ui.cb[p]) do
            if not cb[0] then sect[key] = true end
        end
        if p == 1 then S.ini.shot_off = sect else S.ini.rec_off = sect end
    end
    pcall(inicfg.save, S.ini, INI_NAME)
end

-- ------------------------------------------------------------------ plugin backend
local function connect()
    pcall(ffi.cdef, [[
        int HEXED_Command(const char* line);
        int HEXED_Status(char* buf, int len);
        int HEXED_Scan(const char* dir, char* buf, int len);
    ]])
    local names = { "libHEXED_Capture.so", "HEXED_Capture" }
    for _, n in ipairs(names) do
        local ok, lib = pcall(ffi.load, n)
        if ok and lib then
            local ok2 = pcall(function() return lib.HEXED_Command, lib.HEXED_Status, lib.HEXED_Scan end)
            if ok2 then S.lib, S.libName, S.backend = lib, n, "ffi"; return end
        end
    end
    S.backend = "file"
end

local function cmd(line)
    if S.lib then
        local ok, r = pcall(function() return S.lib.HEXED_Command(line) end)
        return ok and r == 1
    end
    local f = io.open(wd() .. "/" .. CMD_FILE, "a")
    if not f then return false end
    f:write(line .. "\n")
    f:close()
    return true
end

local function readFile(path)
    local f = io.open(path, "r")
    if not f then return nil end
    local t = f:read("*a")
    f:close()
    return t
end

local function pollStatus()
    local text
    if S.lib then
        local buf = ffi.new("char[3072]")
        local ok = pcall(function() S.lib.HEXED_Status(buf, 3072) end)
        if ok then text = ffi.string(buf) end
    else
        text = readFile(wd() .. "/" .. STATUS_FILE)
    end
    if not text or text == "" then return false end
    local t = {}
    for k, v in text:gmatch("([%w_]+)=([^\n]*)") do t[k] = v end
    S.st = t
    return true
end

local function syncSettingsFromPlugin()
    local st = S.st
    if not st.fps then return end
    S.ui.fps[0] = tonumber(st.fps) or 30
    S.ui.bitrate[0] = tonumber(st.bitrate) or 8000
    S.ui.w[0] = tonumber(st.width) or 0
    S.ui.h[0] = tonumber(st.height) or 0
    S.ui.jpeg[0] = tonumber(st.jpeg) or 90
    if st.shot_dir then ffi.copy(S.ui.shotDir, st.shot_dir, math.min(#st.shot_dir, 255)) end
    if st.rec_dir then ffi.copy(S.ui.recDir, st.rec_dir, math.min(#st.rec_dir, 255)) end
    S.synced = true
end

local function pushSettings()
    cmd("set fps " .. S.ui.fps[0])
    cmd("set bitrate " .. S.ui.bitrate[0])
    cmd("set width " .. S.ui.w[0])
    cmd("set height " .. S.ui.h[0])
    cmd("set jpeg " .. S.ui.jpeg[0])
end

-- ------------------------------------------------------------------ Lua visual-mod detection
local function selfFile()
    local ok, p = pcall(function() return thisScript().filename or thisScript().name end)
    if ok and type(p) == "string" then return p:lower() end
    return "hexed_capture.lua"
end

local function scanScripts()
    S.scanErr = nil
    local text
    if S.lib then
        local buf = ffi.new("char[49152]")
        local ok, c = pcall(function() return S.lib.HEXED_Scan(wd(), buf, 49152) end)
        if ok and c and c >= 0 then text = "count=" .. c .. "\n" .. ffi.string(buf) end
    else
        os.remove(wd() .. "/" .. SCAN_FILE)
        cmd("scan " .. wd())
        for _ = 1, 10 do
            wait(250)
            local t = readFile(wd() .. "/" .. SCAN_FILE)
            if t and t:find("count=") then text = t; break end
        end
    end
    if not text then
        S.scanErr = "plugin did not answer (is libHEXED_Capture.so loaded?)"
        return
    end
    local mods, me = {}, selfFile()
    for line in text:gmatch("[^\n]+") do
        local file, flags = line:match("^(.-)\t(%d+)$")
        if file and file:lower() ~= me and not file:lower():find("hexed_capture", 1, true) then
            mods[#mods + 1] = { file = file, key = keyOf(file), flags = tonumber(flags) or 0 }
        end
    end
    table.sort(mods, function(a, b) return a.file:lower() < b.file:lower() end)
    S.mods = mods
    for p = 1, 2 do
        local offs = (p == 1) and S.ini.shot_off or S.ini.rec_off
        for _, m in ipairs(mods) do
            local old = S.ui.cb[p][m.key]
            local on
            if old then on = old[0] else on = not truthy(offs[m.key]) end
            S.ui.cb[p][m.key] = imgui.new.bool(on)
        end
    end
    S.scanned = true
end

-- ------------------------------------------------------------------ hiding deselected visuals
-- Two methods (device test 2026-11-10: "pause" does NOT remove mimgui overlays, they keep drawing):
--   pause  : script:pause() / resume()
--   reload : script:unload() before the capture, script.load(path) afterwards (script state is lost!)
-- Every call is probed with pcall; "Probe script API" (Status tab) dumps what this build really has.
local function has(obj, member)
    local ok, v = pcall(function() return obj[member] end)
    return ok and v ~= nil
end

local function findScriptObject(file)
    if S.objCache[file] ~= nil then return S.objCache[file] or nil end
    local base = file:gsub("/main%.lua$", ""):gsub("%.lua$", "")
    local found = nil
    local function try(fn, arg)
        if found or type(fn) ~= "function" then return end
        local ok, r = pcall(fn, arg)
        if ok and r and type(r) ~= "boolean" and type(r) ~= "number" then found = r end
    end
    if type(script) == "table" then
        try(script.get, base)
        try(script.get, file)
        try(script.find, base)
        if not found and type(script.list) == "function" then
            local ok, list = pcall(script.list)
            if ok and type(list) == "table" then
                for _, sc in pairs(list) do
                    local okn, nm = pcall(function() return sc.name end)
                    local okf, fn = pcall(function() return sc.filename or sc.path end)
                    if (okn and nm == base) or (okf and type(fn) == "string" and fn:find(base .. ".lua", 1, true)) then
                        found = sc
                        break
                    end
                end
            end
        end
    end
    S.objCache[file] = found or false
    return found
end

local function scriptPath(obj, file)
    local ok, p = pcall(function() return obj.path end)
    if ok and type(p) == "string" and p ~= "" then return p end
    return wd() .. "/" .. file
end

local function hideMode()
    return S.ini.main.hide_mode == "reload" and "reload" or "pause"
end

local function hideDeselected(profile)
    local mode = hideMode()
    local n, missing = 0, 0
    for _, m in ipairs(S.mods) do
        local cb = S.ui.cb[profile][m.key]
        if cb and not cb[0] then
            local obj = findScriptObject(m.file)
            local done = false
            if obj and mode == "pause" and has(obj, "pause") then
                done = pcall(function() obj:pause() end)
                if done then S.paused[#S.paused + 1] = { mode = "pause", obj = obj, file = m.file } end
            elseif obj and mode == "reload" and has(obj, "unload") and type(script) == "table" and type(script.load) == "function" then
                local path = scriptPath(obj, m.file)
                done = pcall(function() obj:unload() end)
                if done then
                    S.paused[#S.paused + 1] = { mode = "reload", path = path, file = m.file }
                    S.objCache[m.file] = nil
                end
            end
            if done then n = n + 1 else missing = missing + 1 end
        end
    end
    return n, missing
end

local function restoreAll()
    local list = S.paused
    S.paused = {}
    for _, e in ipairs(list) do
        if e.mode == "pause" then
            pcall(function() e.obj:resume() end)
        else
            pcall(function() script.load(e.path) end)
            S.objCache[e.file] = nil
        end
    end
    return #list
end

local function probeApi()
    local out = { "HEXED Capture API probe", "script type: " .. type(script) }
    local function dump(label, t)
        local keys = {}
        pcall(function() for k in pairs(t) do keys[#keys + 1] = tostring(k) end end)
        table.sort(keys)
        out[#out + 1] = label .. ": " .. table.concat(keys, ", ")
    end
    if type(script) == "table" then dump("script", script) end
    local obj
    for _, m in ipairs(S.mods) do
        obj = findScriptObject(m.file)
        if obj then out[#out + 1] = "sample script object for " .. m.file .. ", type " .. type(obj); break end
    end
    if obj then
        local okm, mt = pcall(getmetatable, obj)
        if okm and type(mt) == "table" then
            dump("metatable", mt)
            if type(mt.__index) == "table" then dump("__index", mt.__index) end
        end
        for _, f in ipairs({ "name", "path", "filename", "version", "dead", "frozen" }) do
            local ok, v = pcall(function() return obj[f] end)
            out[#out + 1] = "obj." .. f .. " = " .. tostring(ok and v or "(n/a)")
        end
        for _, f in ipairs({ "pause", "resume", "unload", "reload" }) do
            out[#out + 1] = "has " .. f .. ": " .. tostring(has(obj, f))
        end
    else
        out[#out + 1] = "no script object found (press Rescan first)"
    end
    local path = wd() .. "/hexed_capture_api.txt"
    local f = io.open(path, "w")
    if f then f:write(table.concat(out, "\n"), "\n"); f:close() end
    say("API probe written to " .. path .. " (" .. #out .. " lines)")
end

-- ------------------------------------------------------------------ actions (run from main(): they may wait())
local function settle() wait(tonumber(S.ini.main.settle_ms) or 500) end

local function doScreenshot()
    local reopen = S.menu[0]
    S.menu[0] = false                                  -- the menu itself must not be in the picture
    local missing = 0
    if S.ui.hideShot[0] then local _; _, missing = hideDeselected(1) end
    settle()
    pollStatus()
    local before = tonumber(S.st.shots) or 0
    if not cmd("shot") then say("could not reach the plugin"); restoreAll(); S.menu[0] = reopen; return end
    local t = os.clock()
    while os.clock() - t < 5 do
        wait(150)
        pollStatus()
        if (tonumber(S.st.shots) or 0) > before then break end
    end
    if restoreAll() > 0 and hideMode() == "reload" then wait(800) end
    S.menu[0] = reopen
    if (tonumber(S.st.shots) or 0) > before then
        say("screenshot saved: " .. tostring(S.st.last_file))
    else
        say("no screenshot written: " .. ((S.st.error and S.st.error ~= "") and S.st.error or "no frame captured (see hexed_capture.log)"))
    end
    if missing > 0 then say(missing .. " deselected script(s) could not be paused (not controllable)") end
end

local function doStart()
    S.menu[0] = false
    local missing = 0
    if S.ui.hideRec[0] then local _; _, missing = hideDeselected(2) end
    settle()
    pushSettings()
    wait(300)
    local ok = cmd("start")
    wait(600)
    pollStatus()
    if ok and S.st.state == "recording" then
        say("recording started - /hxdcap pause | resume | stop")
    else
        restoreAll()
        say("recording did not start: " .. tostring(S.st.error or "plugin not reachable"))
    end
    if missing > 0 then say(missing .. " deselected script(s) could not be paused") end
end

local function doStop()
    cmd("stop")
    wait(800)
    for _ = 1, 20 do
        pollStatus()
        if S.st.state == "idle" then break end
        wait(250)
    end
    local n = restoreAll()
    local file = (S.st.last_file and S.st.last_file ~= "") and (": " .. S.st.last_file) or ""
    say("recording stopped" .. file .. (n > 0 and ("  (" .. n .. " script(s) resumed)") or ""))
end

local function doTest()
    local hidden, missing = hideDeselected(S.profile)
    say("test: paused " .. hidden .. " script(s) for 3 s" .. (missing > 0 and (", " .. missing .. " not controllable") or ""))
    wait(3000)
    restoreAll()
    wait(800)
    say("test finished, scripts restored")
end

-- ------------------------------------------------------------------ UI
local function button(label, w, h, enabled, active)
    if enabled == nil then enabled = true end
    if not enabled then
        imgui.PushStyleColor(imgui.Col.Button, imgui.ImVec4(0.10, 0.11, 0.16, 1))
        imgui.PushStyleColor(imgui.Col.ButtonHovered, imgui.ImVec4(0.10, 0.11, 0.16, 1))
        imgui.PushStyleColor(imgui.Col.ButtonActive, imgui.ImVec4(0.10, 0.11, 0.16, 1))
        imgui.PushStyleColor(imgui.Col.Text, imgui.ImVec4(0.40, 0.42, 0.50, 1))
        imgui.Button(label, imgui.ImVec2(w, h))
        imgui.PopStyleColor(4)
        return false
    end
    if active then imgui.PushStyleColor(imgui.Col.Button, imgui.ImVec4(0.10, 0.45, 0.95, 1)) end
    local r = imgui.Button(label, imgui.ImVec2(w, h))
    if active then imgui.PopStyleColor() end
    return r
end

local DIM = imgui.ImVec4(0.55, 0.60, 0.70, 1)
local GOOD = imgui.ImVec4(0.30, 0.90, 0.45, 1)
local BAD = imgui.ImVec4(1.00, 0.35, 0.35, 1)

local function touchScroll()
    if imgui.IsWindowHovered() and imgui.IsMouseDragging(0, 6 * DPI) then
        imgui.SetScrollY(imgui.GetScrollY() - imgui.GetIO().MouseDelta.y)
    end
end

local function drawCaptureTab()
    local st = S.st
    local state = st.state or "unknown"
    local colour = GOOD
    if state == "recording" then colour = BAD elseif state == "paused" then colour = imgui.ImVec4(1, 0.8, 0.2, 1) end
    imgui.TextColored(colour, "State: " .. state)
    local hookName = "NONE"
    if st.active_hook == "0" then hookName = "eglSwapBuffers" elseif st.active_hook == "1" then hookName = "OS_ScreenSwapBuffers" end
    imgui.TextColored(DIM, string.format("source %sx%s   hook: %s", tostring(st.src_w or "?"), tostring(st.src_h or "?"), hookName))
    if state == "recording" or state == "paused" then
        imgui.Text(string.format("Recorded %ss | encoded %s | dropped %s", tostring(st.rec_seconds or 0),
            tostring(st.frames_encoded or 0), tostring(st.frames_dropped or 0)))
    end
    imgui.Separator()
    imgui.Spacing()
    local bw, bh = 150 * DPI, 44 * DPI
    if button("Screenshot", bw, bh, state ~= "unknown" and not S.busy) then S.req = "shot" end
    imgui.SameLine()
    if button("Start", bw, bh, state == "idle" and not S.busy) then S.req = "start" end
    imgui.Spacing()
    if button("Pause", bw, bh, state == "recording") then S.req = "pause" end
    imgui.SameLine()
    if button("Resume", bw, bh, state == "paused") then S.req = "resume" end
    imgui.SameLine()
    if button("Stop", bw, bh, state == "recording" or state == "paused") then S.req = "stop" end
    imgui.Spacing()
    imgui.TextWrapped("The menu closes when a screenshot/recording starts so it is not in the picture. Reopen with /hxdcap.")
    if st.last_file and st.last_file ~= "" then
        imgui.Spacing()
        imgui.TextColored(DIM, "Last file:")
        imgui.TextWrapped(st.last_file)
    end
    if st.error and st.error ~= "" then
        imgui.Spacing()
        imgui.TextColored(BAD, "Last error: " .. st.error)
    end
end

local function drawSettingsTab()
    local ui, changed = S.ui, false
    imgui.PushItemWidth(260 * DPI)
    if imgui.SliderInt("FPS", ui.fps, 5, 60) then changed = true end
    if imgui.SliderInt("Bitrate (kbps)", ui.bitrate, 1000, 40000) then changed = true end
    if imgui.SliderInt("JPEG quality", ui.jpeg, 40, 100) then changed = true end
    imgui.PopItemWidth()
    imgui.Spacing()
    imgui.Text("Capture resolution (0 x 0 = native; shots and recordings)")
    imgui.PushItemWidth(150 * DPI)
    if imgui.InputInt("Width", ui.w) then changed = true end
    if imgui.InputInt("Height", ui.h) then changed = true end
    imgui.PopItemWidth()
    local presets = { { "Native", 0, 0 }, { "1080p", 1920, 1080 }, { "720p", 1280, 720 }, { "480p", 854, 480 } }
    for i, p in ipairs(presets) do
        if i > 1 then imgui.SameLine() end
        if imgui.Button(p[1], imgui.ImVec2(90 * DPI, 34 * DPI)) then ui.w[0], ui.h[0] = p[2], p[3]; changed = true end
    end
    imgui.TextColored(DIM, "Recording sizes are rounded down to a multiple of 16 for the H.264 encoder.")
    imgui.Spacing()
    imgui.Text("Screenshot format")
    if button("PNG", 90 * DPI, 34 * DPI, true, S.st.format ~= "jpg") then cmd("set format png"); S.st.format = "png" end
    imgui.SameLine()
    if button("JPG", 90 * DPI, 34 * DPI, true, S.st.format == "jpg") then cmd("set format jpg"); S.st.format = "jpg" end
    imgui.Spacing()
    imgui.Text("Screenshot folder")
    imgui.PushItemWidth(-90 * DPI)
    imgui.InputText("##shotdir", ui.shotDir, 256)
    imgui.PopItemWidth()
    imgui.SameLine()
    if imgui.Button("Apply##s", imgui.ImVec2(80 * DPI, 0)) then cmd("dir shot " .. ffi.string(ui.shotDir)); pollStatus() end
    imgui.Text("Recording folder")
    imgui.PushItemWidth(-90 * DPI)
    imgui.InputText("##recdir", ui.recDir, 256)
    imgui.PopItemWidth()
    imgui.SameLine()
    if imgui.Button("Apply##r", imgui.ImVec2(80 * DPI, 0)) then cmd("dir rec " .. ffi.string(ui.recDir)); pollStatus() end
    imgui.TextColored(DIM, "If a folder is not writable the plugin falls back to its own folder.")
    if changed then S.dirty = os.clock() end
end

local function setAll(profile, value)
    for _, m in ipairs(S.mods) do
        local cb = S.ui.cb[profile][m.key]
        if cb then cb[0] = value end
    end
    saveIni()
end

local function drawVisualsTab()
    local p = S.profile
    if button("Screenshot profile", 190 * DPI, 36 * DPI, true, p == 1) then S.profile = 1 end
    imgui.SameLine()
    if button("Recording profile", 190 * DPI, 36 * DPI, true, p == 2) then S.profile = 2 end
    imgui.Spacing()
    if imgui.Checkbox("Hide deselected visuals for screenshots", S.ui.hideShot) then saveIni() end
    if imgui.Checkbox("Hide deselected visuals for recordings", S.ui.hideRec) then saveIni() end
    imgui.Text("Hide method:")
    imgui.SameLine()
    if button("Pause", 90 * DPI, 32 * DPI, true, hideMode() == "pause") then S.ini.main.hide_mode = "pause"; saveIni() end
    imgui.SameLine()
    if button("Reload", 90 * DPI, 32 * DPI, true, hideMode() == "reload") then S.ini.main.hide_mode = "reload"; saveIni() end
    if hideMode() == "reload" then
        imgui.TextColored(BAD, "Reload unloads deselected scripts for the capture and loads them again: their state resets.")
    else
        imgui.TextColored(DIM, "Pause freezes the script; on this build it may NOT remove its overlay. Use Test hide.")
    end
    imgui.Spacing()
    if imgui.Button("Rescan", imgui.ImVec2(110 * DPI, 34 * DPI)) then S.req = "scan" end
    imgui.SameLine()
    if imgui.Button("Select all", imgui.ImVec2(110 * DPI, 34 * DPI)) then setAll(p, true) end
    imgui.SameLine()
    if imgui.Button("Deselect all", imgui.ImVec2(120 * DPI, 34 * DPI)) then setAll(p, false) end
    imgui.SameLine()
    if imgui.Button("Test hide", imgui.ImVec2(110 * DPI, 34 * DPI)) then S.req = "test" end
    imgui.Checkbox("Show non-visual scripts too", S.showAll)
    if S.scanErr then imgui.TextColored(BAD, S.scanErr) end
    imgui.Separator()
    imgui.BeginChild("modlist", imgui.ImVec2(0, 0), true)
    if not S.scanned then
        imgui.TextColored(DIM, "Press Rescan.")
    else
        local shown = 0
        for _, m in ipairs(S.mods) do
            local visual = m.flags > 0
            if visual or S.showAll[0] then
                shown = shown + 1
                local cb = S.ui.cb[p][m.key]
                if cb and imgui.Checkbox(m.file .. "##" .. m.key, cb) then saveIni() end
                imgui.SameLine()
                local tag = ""
                if m.flags % 2 == 1 then tag = tag .. " [imgui]" end
                if m.flags >= 2 then tag = tag .. " [render]" end
                imgui.TextColored(DIM, tag == "" and " [no overlay code found]" or tag)
            end
        end
        if shown == 0 then imgui.TextColored(DIM, "No visual scripts found in " .. wd()) end
    end
    touchScroll()
    imgui.EndChild()
end

local function drawStatusTab()
    imgui.Text("Backend: " .. S.backend .. (S.libName and (" (" .. S.libName .. ")") or ""))
    if S.backend == "file" then
        imgui.TextColored(BAD, "ffi.load failed: using the command file (status lags ~0.5 s).")
    end
    local ctl = "not tested yet"
    if S.canToggle == true then ctl = "script pause/resume found" elseif S.canToggle == false then ctl = "NOT available" end
    imgui.Text("Hiding visuals: " .. ctl)
    if imgui.Button("Probe script API", imgui.ImVec2(200 * DPI, 34 * DPI)) then S.req = "probe" end
    imgui.Spacing()
    local pr = tostring(S.st.probe or "0,0")
    if pr:sub(1, 1) ~= "1" then
        if imgui.Button("Enable render probe (restart game)", imgui.ImVec2(320 * DPI, 34 * DPI)) then cmd("set probe 1") end
    else
        imgui.TextColored(DIM, "Render probe enabled (" .. (pr:sub(3, 3) == "1" and "hooks installed" or "waiting for MonetLoader, ~25 s after start") .. ")")
        if pr:sub(3, 3) == "1" and imgui.Button("Run probe now (~3 s, writes hexed_capture_probe.txt)", imgui.ImVec2(420 * DPI, 34 * DPI)) then cmd("probe") end
    end
    imgui.Spacing()
    imgui.Text("Present hook (takes effect next launch)")
    if button("eglSwapBuffers", 190 * DPI, 34 * DPI, true, S.st.hook ~= "os") then cmd("set hook egl"); S.st.hook = "egl" end
    imgui.SameLine()
    if button("OS_ScreenSwapBuffers", 230 * DPI, 34 * DPI, true, S.st.hook == "os") then cmd("set hook os"); S.st.hook = "os" end
    imgui.Spacing()
    imgui.BeginChild("stat", imgui.ImVec2(0, 0), true)
    local keys = { "state", "version", "active_hook", "src_w", "src_h", "frames_read", "frames_encoded", "frames_dropped", "shots",
                   "fps", "bitrate", "width", "height", "format", "jpeg", "shot_dir", "rec_dir", "last_file", "error" }
    for _, k in ipairs(keys) do
        imgui.TextWrapped(k .. " = " .. tostring(S.st[k] or ""))
    end
    imgui.TextColored(DIM, "Log: hexed_capture.log in the plugin data folder; adb logcat -s HEXED_Capture")
    touchScroll()
    imgui.EndChild()
end

imgui.OnInitialize(function()
    pcall(function()
        local style = imgui.GetStyle()
        style.WindowRounding = 10
        style.FrameRounding = 6
        style.ChildRounding = 6
        style.WindowBorderSize = 1
        style.FramePadding = imgui.ImVec2(8 * DPI, 6 * DPI)
        style.ItemSpacing = imgui.ImVec2(8 * DPI, 8 * DPI)
        local c = style.Colors
        c[imgui.Col.WindowBg]      = imgui.ImVec4(0.02, 0.03, 0.07, 0.97)
        c[imgui.Col.Border]        = imgui.ImVec4(0.10, 0.35, 0.85, 1)
        c[imgui.Col.ChildBg]       = imgui.ImVec4(0.04, 0.06, 0.12, 1)
        c[imgui.Col.FrameBg]       = imgui.ImVec4(0.08, 0.10, 0.18, 1)
        c[imgui.Col.Button]        = imgui.ImVec4(0.12, 0.14, 0.22, 1)
        c[imgui.Col.ButtonHovered] = imgui.ImVec4(0.14, 0.40, 0.90, 1)
        c[imgui.Col.ButtonActive]  = imgui.ImVec4(0.10, 0.45, 0.95, 1)
        c[imgui.Col.CheckMark]     = imgui.ImVec4(0.20, 0.60, 1.00, 1)
        c[imgui.Col.SliderGrab]    = imgui.ImVec4(0.14, 0.40, 0.90, 1)
    end)
    local gio = imgui.GetIO()
    local fontPath = wd() .. "/HEXED/Fonts/LamarFont.ttf"
    local loaded = false
    local fh = io.open(fontPath, "rb")
    if fh then
        fh:close()
        loaded = pcall(function() gio.Fonts:AddFontFromFileTTF(fontPath, 17 * DPI, nil, gio.Fonts:GetGlyphRangesDefault()) end)
    end
    if not loaded then
        pcall(function() gio.Fonts:AddFontDefault(); gio.FontGlobalScale = 1.25 * DPI end)
    end
end)

imgui.OnFrame(function() return S.menu[0] end, function()
    local gio = imgui.GetIO()
    imgui.SetNextWindowSize(imgui.ImVec2(math.min(760 * DPI, gio.DisplaySize.x * 0.95), math.min(520 * DPI, gio.DisplaySize.y * 0.92)), imgui.Cond.FirstUseEver)
    imgui.SetNextWindowPos(imgui.ImVec2(gio.DisplaySize.x / 2, gio.DisplaySize.y / 2), imgui.Cond.FirstUseEver, imgui.ImVec2(0.5, 0.5))
    imgui.Begin("##hexedcapture", S.menu, imgui.WindowFlags.NoTitleBar + imgui.WindowFlags.NoCollapse)

    local title = "HEXED CAPTURE"
    local tw = imgui.CalcTextSize(title).x
    imgui.SetCursorPosX((imgui.GetWindowWidth() - tw) / 2)
    imgui.TextColored(imgui.ImVec4(0.20, 0.60, 1, 1), title)
    imgui.Separator()

    imgui.BeginChild("tabs", imgui.ImVec2(140 * DPI, 0), false)
    local tabs = { "Capture", "Settings", "Lua Visuals", "Status" }
    for i, name in ipairs(tabs) do
        if button(name, 130 * DPI, 35 * DPI, true, S.tab == i) then S.tab = i end
    end
    imgui.Spacing()
    if imgui.Button("Close", imgui.ImVec2(130 * DPI, 35 * DPI)) then S.menu[0] = false end
    imgui.EndChild()
    imgui.SameLine()
    imgui.BeginChild("content", imgui.ImVec2(0, 0), true)
    if S.tab == 1 then drawCaptureTab()
    elseif S.tab == 2 then drawSettingsTab()
    elseif S.tab == 3 then drawVisualsTab()
    else drawStatusTab() end
    imgui.EndChild()
    imgui.End()
end)

-- ------------------------------------------------------------------ main
local function handleRequest(r)
    if r == "shot" then doScreenshot()
    elseif r == "start" then doStart()
    elseif r == "stop" then doStop()
    elseif r == "pause" then cmd("pause"); wait(300); pollStatus()
    elseif r == "resume" then cmd("resume"); wait(300); pollStatus()
    elseif r == "scan" then scanScripts()
    elseif r == "test" then doTest()
    elseif r == "probe" then probeApi()
    elseif r == "unhide" then say("resumed " .. restoreAll() .. " script(s)")
    end
end

function main()
    if type(isSampLoaded) == "function" then
        while not isSampLoaded() do wait(200) end
    end
    connect()

    pcall(function()
        sampRegisterChatCommand("hxdcap", function(arg)
            arg = (arg or ""):lower():match("^%s*(.-)%s*$")
            local map = { shot = "shot", screenshot = "shot", rec = "start", record = "start", start = "start",
                          stop = "stop", pause = "pause", resume = "resume", unhide = "unhide", scan = "scan" }
            if arg == "" then
                S.menu[0] = not S.menu[0]
                if S.menu[0] and not S.scanned then S.req = S.req or "scan" end
            elseif arg == "status" then
                pollStatus()
                say("state " .. tostring(S.st.state) .. ", backend " .. S.backend .. ", hook " .. tostring(S.st.active_hook))
            elseif map[arg] then
                S.req = map[arg]
            else
                say("/hxdcap [shot | rec | stop | pause | resume | unhide | status]")
            end
        end)
    end)

    for _ = 1, 20 do
        if pollStatus() then break end
        wait(250)
    end
    syncSettingsFromPlugin()
    if S.backend == "file" then say("ffi.load of the plugin failed - using the command file") end
    say("loaded. /hxdcap opens the menu" .. (S.st.state and "" or " (plugin not answering yet - check logcat)"))

    while true do
        wait(0)
        imgui.Process = S.menu[0]
        local now = os.clock()
        if now - S.lastPoll > 0.5 then
            S.lastPoll = now
            pollStatus()
            if not S.synced then syncSettingsFromPlugin() end
        end
        if S.dirty and now - S.dirty > 0.4 then
            S.dirty = nil
            pushSettings()
        end
        if S.req and not S.busy then
            local r = S.req
            S.req = nil
            S.busy = true
            local ok, err = pcall(handleRequest, r)
            S.busy = false
            if not ok then say("error: " .. tostring(err)) end
        end
        if S.canToggle == nil and S.scanned and #S.mods > 0 then
            local any = false
            for _, m in ipairs(S.mods) do
                local o = findScriptObject(m.file); if o and (has(o, "pause") or has(o, "unload")) then any = true; break end
            end
            S.canToggle = any
        end
    end
end

function onScriptTerminate(s, quit)
    if s == thisScript() then
        restoreAll()
        if S.st.state == "recording" or S.st.state == "paused" then cmd("stop") end
    end
end
