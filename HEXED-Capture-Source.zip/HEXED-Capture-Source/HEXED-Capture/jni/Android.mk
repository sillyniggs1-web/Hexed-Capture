LOCAL_PATH := $(call my-dir)

include $(CLEAR_VARS)
LOCAL_MODULE            := HEXED_Capture
LOCAL_SRC_FILES         := ../src/main.cpp \
                           ../src/state.cpp \
                           ../src/hook.cpp \
                           ../src/capture.cpp \
                           ../src/pipeline.cpp \
                           ../src/image.cpp \
                           ../src/scan.cpp \
                           ../src/control.cpp \
                           ../src/exclude.cpp \
                           ../mod/logger.cpp \
                           ../mod/config.cpp

LOCAL_C_INCLUDES        += $(LOCAL_PATH)/.. $(LOCAL_PATH)/../mod

# log/dl/android: AML + logging, EGL/GLESv2: framebuffer read-back,
# mediandk: MediaCodec + MediaMuxer (API 21+), z: PNG deflate
LOCAL_LDLIBS            := -llog -ldl -landroid -lmediandk -lEGL -lGLESv2 -lz
LOCAL_CFLAGS            += -O2 -fvisibility=hidden -DNDEBUG -Wno-error=format-security
LOCAL_CPPFLAGS          += -std=c++17 -fvisibility=hidden -fno-exceptions -fno-rtti -DNDEBUG -Wno-error=format-security
LOCAL_ARM_MODE          := arm

include $(BUILD_SHARED_LIBRARY)
